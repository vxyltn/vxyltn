"""Shared test harness: isolated data dir, app without background jobs, IPN simulation."""
from __future__ import annotations

import io
import json
import os
import re
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def make_app(**env):
    d = tempfile.mkdtemp(prefix="vxtest-")
    base = {"SECRET_KEY": "t" * 40, "DATA_DIR": d, "DB_PATH": f"{d}/db.sqlite3", "UPLOADS_DIR": f"{d}/up", "BACKUPS_DIR": f"{d}/bk",
            "COOKIE_SECURE": "0", "ADMIN_EMAIL": "admin@vxyltn.com", "ADMIN_PASSWORD": "AdminPassw0rd!", "NOWPAYMENTS_IPN_SECRET": "ipn",
            "LOG_LEVEL": "ERROR", "ADMIN_REQUIRE_2FA": "0", "BASE_URL": "http://testserver"}
    base.update(env)
    os.environ.update(base)
    from app.main import create_app
    return create_app(run_jobs=False), d


def csrf(html: str) -> str:
    m = re.search(r'name="_csrf" value="([^"]+)"', html)
    return m.group(1) if m else ""


class Flow:
    def __init__(self, app, client):
        self.app, self.c, self.db = app, client, app.state.core.db
        self._n = 1000

    def login(self, email, password):
        t = csrf(self.c.get("/login").text)
        return self.c.post("/login", data={"_csrf": t, "email": email, "password": password, "mode": "password"}, follow_redirects=False)

    def signup(self, email, password="Passw0rdXYZ"):
        t = csrf(self.c.get("/signup").text)
        return self.c.post("/signup", data={"_csrf": t, "email": email, "password": password, "dob": "1990-01-01", "adult": "1", "terms": "1"}, follow_redirects=False)

    def token(self, path="/feed"):
        return csrf(self.c.get(path).text)

    def pay(self, pay_url, status="finished"):
        """Simulate a NOWPayments IPN for the next unpaid part of the purchase behind pay_url."""
        from app.nowpayments import sign_ipn
        pub = pay_url.split("/pay/")[1].split("?")[0]
        p = self.db.one("SELECT * FROM purchases WHERE public_id=?", (pub,))
        inv = self.app.state.core.payments.next_invoice(p["id"])
        self._n += 1
        payload = {"payment_id": self._n, "invoice_id": self._n * 7, "payment_status": status, "price_amount": inv["amount_cents"] / 100, "price_currency": "usd",
                   "pay_currency": "btc", "order_id": inv["order_ref"], "actually_paid": 0.5, "pay_amount": 0.5, "payin_hash": "0xhash", "fee": {"currency": "btc", "depositFee": 0.0001}}
        r = self.c.post("/api/nowpayments/ipn", content=json.dumps(payload, separators=(",", ":")), headers={"x-nowpayments-sig": sign_ipn("ipn", payload), "content-type": "application/json"})
        return r.json(), self.db.one("SELECT status FROM purchases WHERE public_id=?", (pub,))["status"]


def jpeg_bytes(w=640, h=480):
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGB", (w, h), (90, 20, 160)).save(buf, "JPEG")
    return buf.getvalue()
