"""Unit tests: money, pricing engine, auth primitives, IPN signatures, language gate."""
import json
import unittest
from datetime import datetime
from zoneinfo import ZoneInfo

from app import auth, money
from app.lang import is_english
from app.nowpayments import sign_ipn, verify_ipn


class MoneyTests(unittest.TestCase):
    def test_usd_format(self):
        self.assertEqual(money.usd(100_000_000), "1,000,000 usdc")
        self.assertEqual(money.usd(1250), "12.50 usdc")
        self.assertEqual(money.usd(-500), "-5 usdc")
        self.assertEqual(money.usd(1250, label=""), "12.50")

    def test_split_and_rounding(self):
        self.assertEqual(money.split_amount(25_000, 10_000), [10_000, 10_000, 5_000])
        self.assertEqual(money.split_amount(25_000, 0), [25_000])
        self.assertEqual(money.ceil_mul(1001, 1.5), 1502)
        self.assertEqual(money.ceil_pct(1000, 15), 1150)
        self.assertEqual(money.round_up_to(1001, 1000), 2000)


class AuthTests(unittest.TestCase):
    def test_password_roundtrip(self):
        h = auth.hash_password("Correct-Horse1")
        self.assertTrue(auth.verify_password("Correct-Horse1", h))
        self.assertFalse(auth.verify_password("wrong", h))
        self.assertIsNotNone(auth.password_problems("short"))
        self.assertIsNone(auth.password_problems("LongEnough123"))

    def test_totp(self):
        secret = auth.totp_new_secret()
        self.assertTrue(auth.totp_verify(secret, auth.totp_code(secret)))
        self.assertFalse(auth.totp_verify(secret, "000000"))

    def test_signing(self):
        signed = auth.sign("k", "value")
        self.assertEqual(auth.unsign("k", signed), "value")
        self.assertIsNone(auth.unsign("other", signed))

    def test_recovery_codes(self):
        codes = auth.recovery_codes(3)
        hashed = auth.hash_codes(codes)
        remaining = auth.use_recovery_code(hashed, codes[0])
        self.assertEqual(len(remaining), 2)
        self.assertIsNone(auth.use_recovery_code(remaining, codes[0]))


class IpnTests(unittest.TestCase):
    def test_signature_variants(self):
        payload = {"payment_id": 1, "payment_status": "finished", "order_id": "PX-1-1", "price_amount": 10.5,
                   "fee": {"currency": "btc", "depositFee": 0.1}, "note": "ünïcode/slash"}
        body = json.dumps(payload, separators=(",", ":")).encode()
        self.assertTrue(verify_ipn("secret", body, sign_ipn("secret", payload)))
        self.assertFalse(verify_ipn("secret", body, "deadbeef"))
        self.assertFalse(verify_ipn("", body, sign_ipn("secret", payload)))
        # a differently formatted body (spaces, unsorted keys) still verifies: candidates are re-serialized
        body2 = json.dumps({"order_id": "PX-1-1", "payment_id": 1, "payment_status": "finished", "price_amount": 10.5,
                            "fee": {"currency": "btc", "depositFee": 0.1}, "note": "ünïcode/slash"}).encode()
        self.assertTrue(verify_ipn("secret", body2, sign_ipn("secret", payload)))


class LangTests(unittest.TestCase):
    def test_english(self):
        self.assertTrue(is_english("please send the video at 4k"))
        self.assertTrue(is_english("VX-2026-000012"))
        self.assertFalse(is_english("merhaba nasılsın"))
        self.assertFalse(is_english("привет как дела"))
        self.assertTrue(is_english("https://example.com ok"))


class RequestPricingTests(unittest.TestCase):
    def setUp(self):
        from tests.helpers import make_app
        self.app, _ = make_app()
        from app.requestsys.pricing import RqPricing
        self.p = RqPricing(self.app.state.core.settings)

    def test_activation_is_minimum(self):
        q = self.p.quote_activation()
        self.assertEqual(q.total, 100_000_000)
        from app.requestsys import catalog
        cheapest = min(self.p.unit_price(o.key) for o in catalog.OFFERS.values() if o.kind == "standard")
        self.assertGreater(cheapest, q.total)

    def test_standard_breakdown_and_surcharges(self):
        from app.requestsys import catalog
        when = datetime(2026, 10, 21, 12, 0, tzinfo=ZoneInfo("Europe/Istanbul"))  # weekday, business hours
        q = self.p.quote_standard(catalog.OFFERS["out_text"], 1, "none", when)
        codes = [ln.code for ln in q.lines]
        self.assertEqual(codes[:2], ["subtotal", "setup"])
        self.assertIn("processing", codes)
        self.assertGreaterEqual(q.total, 100_000_000)
        off = self.p.quote_standard(catalog.OFFERS["out_text"], 1, "urgent", datetime(2026, 10, 24, 23, 0, tzinfo=ZoneInfo("Europe/Istanbul")))
        self.assertIn("offhours", [ln.code for ln in off.lines])
        self.assertIn("weekend", [ln.code for ln in off.lines])
        self.assertGreater(off.total, q.total)

    def test_addon_upgrade_delta(self):
        from app.requestsys import catalog
        when = datetime(2026, 10, 21, 12, 0, tzinfo=ZoneInfo("Europe/Istanbul"))
        base = self.p.quote_standard(catalog.OFFERS["custom_video"], 2, "none", when)
        up = self.p.quote_addon_upgrade(base, "high", "VX-2026-000001")
        expected = self.p.quote_standard(catalog.OFFERS["custom_video"], 2, "high", when, factors=base.factors).total - base.total
        self.assertEqual(up.total, expected)
        with self.assertRaises(ValueError):
            self.p.quote_addon_upgrade(up, "priority", "x")

    def test_contribution_has_no_limit(self):
        self.assertEqual(self.p.quote_contribution(1).total, 1)
        self.assertEqual(self.p.quote_contribution(10 ** 14).total, 10 ** 14)
        with self.assertRaises(ValueError):
            self.p.quote_contribution(0)

    def test_platform_floor(self):
        from app.access import Viewer, apply_floor, price_for
        s = self.app.state.core.settings
        self.assertEqual(apply_floor(s, 500), 100_000)
        self.assertEqual(apply_floor(s, 0), 0)
        self.assertEqual(price_for(s, Viewer(), 500), 100_000 * 1)  # public: 500 x 3 = 1,500 -> floored to 1,000
        p = self.app.state.core.payments.create_purchase(user_id=None, kind="tip", title="t", total_cents=5)
        self.assertEqual(p["total_cents"], 100_000)
        c = self.app.state.core.payments.create_purchase(user_id=None, kind="campaign", title="c", total_cents=5)
        self.assertEqual(c["total_cents"], 5)

    def test_tier_ladder(self):
        from app import members
        names = [t["name"] for t in members.tiers(self.app.state.core.db)]
        self.assertEqual(names[:3], ["base", "v0", "v1"])
        self.assertEqual(names[-1], "v4.4.4.4")
        self.assertEqual(len(names), 18)
        prices = [t["price_month_cents"] for t in members.tiers(self.app.state.core.db)]
        self.assertEqual(prices[0], 100_000)
        self.assertEqual(prices, sorted(prices))
        self.assertLessEqual(prices[-1], 100_000_000)


if __name__ == "__main__":
    unittest.main()
