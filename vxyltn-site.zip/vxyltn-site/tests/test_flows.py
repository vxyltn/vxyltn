"""Integration tests through the web layer with simulated NOWPayments IPNs."""
import json
import re
import unittest

from starlette.testclient import TestClient

from tests.helpers import Flow, csrf, jpeg_bytes, make_app


class RequestSystemFlow(unittest.TestCase):
    def setUp(self):
        self.app, self.dir = make_app()
        self.c = TestClient(self.app, base_url="http://testserver", raise_server_exceptions=False)
        self.f = Flow(self.app, self.c)
        self.assertEqual(self.f.signup("fan@example.com").status_code, 303)

    def test_terms_activation_request_details(self):
        c, f, db = self.c, self.f, self.f.db
        self.assertEqual(c.get("/request/menu", follow_redirects=False).status_code, 303)  # not activated
        t = f.token("/request/terms")
        self.assertEqual(c.post("/request/terms", data={"_csrf": t, "accept": "1"}, follow_redirects=False).headers["location"], "/request/start")
        r = c.post("/request/start", data={"_csrf": f.token("/request/start")}, follow_redirects=False)
        pay_url = r.headers["location"]
        self.assertIn("/pay/PX-", pay_url)
        self.assertIn("1,000,000 usdc", c.get(pay_url).text)
        bad = c.post("/api/nowpayments/ipn", content=b'{"order_id":"x"}', headers={"x-nowpayments-sig": "00", "content-type": "application/json"})
        self.assertEqual(bad.status_code, 400)
        res, status = f.pay(pay_url)
        self.assertTrue(res["ok"])
        self.assertEqual(status, "paid")
        self.assertEqual(c.get("/request/menu").status_code, 200)
        t = f.token("/request/offer/custom_video")
        r = c.post("/request/offer/custom_video", data={"_csrf": t, "units": "2", "priority": "urgent"})
        signed = re.search(r'name="signed" value="([^"]+)"', r.text).group(1)
        r = c.post("/request/confirm", data={"_csrf": t, "signed": signed}, follow_redirects=False)
        order = db.one("SELECT * FROM rq_orders WHERE kind='standard'")
        self.assertEqual(order["status"], "awaiting_payment")
        f.pay(r.headers["location"])
        order = db.get("rq_orders", order["id"])
        self.assertEqual(order["status"], "paid")
        self.assertEqual(order["details_status"], "pending")
        r = c.post("/request/confirm", data={"_csrf": t, "signed": signed[:-3] + "abc"}, follow_redirects=False)
        self.assertEqual(r.headers["location"], "/request/menu")  # tampered quote refused
        t = f.token(f"/request/orders/{order['public_id']}")
        c.post(f"/request/orders/{order['public_id']}", data={"_csrf": t, "action": "add", "text": "merhaba nasılsın"}, follow_redirects=False)
        self.assertEqual(db.count("rq_details"), 0)  # english only
        c.post(f"/request/orders/{order['public_id']}", data={"_csrf": t, "action": "add", "text": "4k please"},
               files={"files": ("ref.jpg", jpeg_bytes(), "image/jpeg")}, follow_redirects=False)
        self.assertEqual(db.count("rq_details"), 2)
        c.post(f"/request/orders/{order['public_id']}", data={"_csrf": t, "action": "done"})
        self.assertEqual(db.get("rq_orders", order["id"])["details_status"], "received")
        self.assertEqual(db.count("media", "folder='invoices'"), 2)  # pdf records for activation + request
        # duplicate IPN is idempotent (same payment id, same part)
        r2 = c.post("/api/nowpayments/ipn", content=b"{}", headers={"content-type": "application/json"})
        self.assertEqual(r2.status_code, 400)
        r = c.get("/request/start")
        self.assertIn("start over", r.text)
        c.post("/request/start", data={"_csrf": csrf(r.text)}, follow_redirects=False)
        self.assertEqual(c.get("/request/menu", follow_redirects=False).status_code, 303)  # new activation required

    def test_cap_exempt_and_platform_cap(self):
        core = self.app.state.core
        from app.payments import CapExceeded
        with self.assertRaises(CapExceeded):
            core.payments.create_purchase(user_id=1, kind="tip", title="big", total_cents=200_000_000)
        p = core.payments.create_purchase(user_id=1, kind="rq_order", title="req", total_cents=5_000_000_000, exempt_cap=True)
        self.assertEqual(p["total_cents"], 5_000_000_000)


class PlatformFlow(unittest.TestCase):
    def setUp(self):
        self.app, self.dir = make_app()
        self.admin = TestClient(self.app, base_url="http://testserver", raise_server_exceptions=False)
        Flow(self.app, self.admin).login("admin@vxyltn.com", "AdminPassw0rd!")
        self.fan = TestClient(self.app, base_url="http://testserver", raise_server_exceptions=False)
        self.f = Flow(self.app, self.fan)
        self.db = self.app.state.core.db
        t = csrf(self.admin.get("/admin/posts/new").text)
        r = self.admin.post("/admin/posts/new", data={"_csrf": t, "type": "photo", "visibility": "ppv", "title": "set one", "body_md": "secret **body**",
                                                      "ppv_price_cents": "1000", "min_tier_rank": "2", "allow_comments": "1", "watermark": "1", "teaser_text": "tease"},
                            files=[("files", ("a.jpg", jpeg_bytes(), "image/jpeg"))], follow_redirects=False)
        self.pid = int(r.headers["location"].split("/")[-1])
        self.admin_tok = t

    def test_audience_pricing_and_unlock(self):
        public_price = re.search(r"unlock — ([\d\.,]+ usdc)", self.fan.get(f"/post/{self.pid}").text).group(1)
        self.assertEqual(public_price, "3,000 usdc")  # 1,000 x public_mult 3
        self.f.signup("fan@example.com")
        follower_price = re.search(r"unlock — ([\d\.,]+ usdc)", self.fan.get(f"/post/{self.pid}").text).group(1)
        self.assertEqual(follower_price, "2,000 usdc")  # 1,000 x follower_mult 2
        r = self.fan.post(f"/post/{self.pid}/unlock", data={"_csrf": self.f.token()}, follow_redirects=False)
        self.f.pay(r.headers["location"])
        self.assertIn("secret <strong>body</strong>", self.fan.get(f"/post/{self.pid}").text)
        mid = self.db.one("SELECT media_id FROM post_media")["media_id"]
        self.assertEqual(self.fan.get(f"/media/{mid}").status_code, 200)
        self.assertEqual(self.db.count("watermark_log"), 1)
        anon = TestClient(self.app, base_url="http://testserver")
        self.assertEqual(anon.get(f"/media/{mid}").status_code, 403)
        self.assertEqual(anon.get(f"/media/{mid}/blur").status_code, 200)

    def test_membership_includes_content_and_dm_pricing(self):
        self.f.signup("fan@example.com")
        tier = self.db.one("SELECT * FROM tiers WHERE rank=2")
        r = self.fan.post("/membership/join", data={"_csrf": self.f.token(), "tier_id": tier["id"], "months": "1"}, follow_redirects=False)
        self.f.pay(r.headers["location"])
        self.assertTrue(self.db.one("SELECT 1 FROM memberships WHERE status='active'"))
        self.assertNotIn("unlock —", self.fan.get(f"/post/{self.pid}").text)
        r = self.fan.post("/messages/send", data={"_csrf": self.f.token("/messages"), "body": "hello there"}, follow_redirects=False)
        self.assertIn("/pay/", r.headers["location"])  # tier dm price 1,000
        self.f.pay(r.headers["location"])
        self.assertEqual(self.db.count("messages", "sender_role='user'"), 1)
        fan_id = self.db.one("SELECT id FROM users WHERE email='fan@example.com'")["id"]
        self.admin.post(f"/admin/messages/{fan_id}", data={"_csrf": csrf(self.admin.get(f"/admin/messages/{fan_id}").text), "body": "paid reply", "price": "1500"})
        locked = self.db.one("SELECT id FROM messages WHERE is_locked=1")
        r = self.fan.post(f"/messages/{locked['id']}/unlock", data={"_csrf": self.f.token("/messages")}, follow_redirects=False)
        self.f.pay(r.headers["location"])
        self.assertEqual(self.db.get("messages", locked["id"])["is_locked"], 0)

    def test_tip_bonus_credit(self):
        self.f.signup("fan@example.com")
        r = self.fan.post("/tips/send", data={"_csrf": self.f.token(), "amount": "20", "context_type": "profile"}, follow_redirects=False)
        self.assertNotIn("/pay/", r.headers["location"])  # below the 1,000 minimum tip
        r = self.fan.post("/tips/send", data={"_csrf": self.f.token(), "amount": "1000", "context_type": "profile"}, follow_redirects=False)
        self.f.pay(r.headers["location"])
        user = self.db.one("SELECT * FROM users WHERE email='fan@example.com'")
        self.assertEqual(user["wallet_cents"], 50_000)  # 50% first-tip bonus
        self.assertEqual(self.db.count("tips"), 1)

    def test_partial_then_finished(self):
        self.f.signup("fan@example.com")
        r = self.fan.post("/tips/send", data={"_csrf": self.f.token(), "amount": "3000"}, follow_redirects=False)
        _, status = self.f.pay(r.headers["location"], status="partially_paid")
        self.assertEqual(status, "partial")
        _, status = self.f.pay(r.headers["location"], status="finished")
        self.assertEqual(status, "paid")

    def test_shop_checkout_with_coa_and_inventory(self):
        t = csrf(self.admin.get("/admin/r/products/new").text)
        self.admin.post("/admin/r/products/new", data={"_csrf": t, "name": "print", "kind": "physical", "price_cents": "1000", "inventory": "2", "coa": "1", "signed": "1", "is_active": "1"}, follow_redirects=False)
        self.f.signup("fan@example.com")
        self.fan.post("/shop/cart/add", data={"_csrf": self.f.token("/shop"), "product_id": "1", "qty": "2"}, follow_redirects=False)
        r = self.fan.post("/shop/cart", data={"_csrf": self.f.token("/shop/cart"), "action": "checkout", "name": "n", "address1": "a", "city": "c", "country": "US"}, follow_redirects=False)
        self.f.pay(r.headers["location"])
        o = self.db.one("SELECT * FROM shop_orders")
        self.assertEqual(o["status"], "fulfilling")
        self.assertEqual(len(json.loads(o["coa_json"])), 2)
        self.assertEqual(self.db.get("products", 1)["inventory"], 0)
        self.assertEqual(self.admin.get("/admin/coa/VX-COA-000001.pdf").headers["content-type"], "application/pdf")

    def test_custom_order_lifecycle(self):
        self.f.signup("fan@example.com")
        tier = self.db.one("SELECT * FROM tiers WHERE rank=1")
        r = self.fan.post("/membership/join", data={"_csrf": self.f.token(), "tier_id": tier["id"], "months": "1"}, follow_redirects=False)
        self.f.pay(r.headers["location"])
        self.fan.post("/customs/new", data={"_csrf": self.f.token("/customs"), "type": "shoutout", "title": "hello sam", "brief": "say hi to sam"}, follow_redirects=False)
        co = self.db.one("SELECT * FROM custom_orders")
        self.admin.post(f"/admin/customs/{co['public_id']}", data={"_csrf": csrf(self.admin.get(f"/admin/customs/{co['public_id']}").text), "action": "quote", "quote": "5000", "deposit_pct": "50", "revisions": "1"})
        r = self.fan.post(f"/customs/{co['public_id']}", data={"_csrf": self.f.token(f"/customs/{co['public_id']}"), "action": "deposit"}, follow_redirects=False)
        self.f.pay(r.headers["location"])
        self.assertEqual(self.db.get("custom_orders", co["id"])["status"], "accepted")
        self.admin.post(f"/admin/customs/{co['public_id']}", data={"_csrf": self.admin_tok, "action": "deliver", "note": "here"}, files=[("files", ("v.jpg", jpeg_bytes(), "image/jpeg"))])
        r = self.fan.post(f"/customs/{co['public_id']}", data={"_csrf": self.f.token(f"/customs/{co['public_id']}"), "action": "balance"}, follow_redirects=False)
        self.f.pay(r.headers["location"])
        self.assertEqual(self.db.get("custom_orders", co["id"])["status"], "completed")
        dl = re.search(r'href="(/dl/[^"]+)"', self.fan.get(f"/customs/{co['public_id']}").text)
        self.assertIsNotNone(dl)
        self.assertEqual(self.fan.get(dl.group(1)).status_code, 200)

    def test_admin_requires_login_and_reports_render(self):
        anon = TestClient(self.app, base_url="http://testserver")
        self.assertEqual(anon.get("/admin", follow_redirects=False).status_code, 303)
        self.assertEqual(self.admin.get("/admin/reports?range=all").status_code, 200)
        self.assertEqual(self.admin.get("/admin/reports?range=all&format=pdf").headers["content-type"], "application/pdf")
        self.assertEqual(self.admin.get("/admin/export/all.json").status_code, 200)

    def test_security_headers_csrf_and_lowercase_title(self):
        r = self.fan.get("/")
        self.assertEqual(r.headers["x-frame-options"], "DENY")
        self.assertIn("default-src 'self'", r.headers["content-security-policy"])
        self.assertEqual(self.fan.post("/tips/send", data={"amount": "5"}).status_code, 403)
        self.assertIn("<title>vxyltn</title>", r.text)


if __name__ == "__main__":
    unittest.main()
