# request.vxyltn.com

VXYLTN's own site: the **request system** (activation-gated, request-only, USDC 1,000,000 minimum) plus the full creator platform
(memberships, pay-per-view feed, vault, paid DMs, livestreams, calls, custom orders, tips & fundraising, private channels, drops,
merch shop) with **audience pricing** for public visitors, followers and subscribers. Payments go through **NOWPayments only**
(main currency USDC ERC-20; the payer may choose any supported coin at checkout). Deployed on **AWS** (one EC2 instance, Docker Compose,
Caddy TLS, S3 backups). Interface: black background, dirty-white text, Cargo-style minimal layout, everything lowercase.

* Stack: Python 3.13 (3.12 works), Starlette + uvicorn, Jinja2, SQLite (WAL + FTS5), reportlab (PDF), Pillow (thumbnails, blurred previews,
  per-viewer watermarks), ffmpeg (video posters, optional), httpx (NOWPayments, Telegram, SMTP-less email adapters).
* No framework magic, no JS build step, no external database. One process, one volume.

---

## 1. quick start (local)

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # edit at least SECRET_KEY, ADMIN_EMAIL, ADMIN_PASSWORD
export $(grep -v '^#' .env | xargs)      # or use direnv / docker compose
COOKIE_SECURE=0 ADMIN_REQUIRE_2FA=0 python -m app.main       # http://127.0.0.1:8080
```

Tests and lint:

```bash
python -m unittest discover -s tests -v     # 24 tests: money, auth, IPN signatures, pricing, every paid flow end to end
python -m pyflakes app tests
```

Without `NOWPAYMENTS_API_KEY` the app runs in **manual mode**: invoices are created but checkout shows the "contact" page instead of
a NOWPayments link. The admin can still mark purchases paid from *admin → contact & manual*.

First login: `ADMIN_EMAIL` / `ADMIN_PASSWORD` → `/login`. Admin routes require 2FA (`ADMIN_REQUIRE_2FA=1`); enrol at
`/account/security` on first login and store the recovery codes.

---

## 2. configuration

All configuration is environment variables (see `.env.example`, every key documented there). Runtime-editable settings
(prices, surcharges, limits, maintenance mode, announcement, age gate, geo-block, watermark text…) live in
*admin → settings* and *admin → request pricing* and override the env defaults without a restart.

Key economics:

| setting | default | meaning |
|---|---|---|
| `PRICE_CURRENCY` | `usdc` | NOWPayments `price_currency`. Verified at startup against `/v1/currencies`; falls back to `usd` (same 1:1 value) with a warning if the ticker is not enabled on the account. |
| `CURRENCY_LABEL` | `usdc` | label rendered everywhere (`1,000 usdc`). |
| `RQ_ACTIVATION_CENTS` | 100,000,000 | activation = 1,000,000 USDC = the minimum price of the request system. |
| `RQ_MIN_TOTAL_CENTS` | 100,000,000 | floor for every standard request total. |
| `MAX_USD_PER_INVOICE_CENTS` | 0 | 0 = one invoice per payment. Set e.g. 100,000,000 to split large request totals into sequential parts. |
| `PLATFORM_MIN_CENTS` | 100,000 | every in-app purchase (memberships, PPV, DMs, tips, tickets, shop…) starts at 1,000 USDC. Contributions and the request system are exempt. |
| `PLATFORM_TX_CAP_CENTS` | 100,000,000 | automated cap per platform purchase; above it the buyer is routed to the manual contact flow. The request system is exempt. |
| `PUBLIC_PRICE_MULT` / `FOLLOWER_PRICE_MULT` | 3.0 / 2.0 | audience pricing multipliers (subscribers pay the base price minus their tier's PPV discount). |

---

## 3. nowpayments setup

1. Create the account, enable the coins you want to accept, and set a **payout wallet** (USDC ERC-20 recommended, since prices are quoted in USDC).
2. *Settings → Payments → API keys*: copy the API key → `NOWPAYMENTS_API_KEY`.
3. *Settings → Payments → Instant Payment Notifications*: generate the IPN secret → `NOWPAYMENTS_IPN_SECRET`; set the callback URL to
   `https://request.vxyltn.com/api/nowpayments/ipn` (the app also sends `ipn_callback_url` on every invoice).
4. Optional: `NOWPAYMENTS_EMAIL` / `NOWPAYMENTS_PASSWORD` let the 5-minute reconciliation job list payments with a JWT and heal missed IPNs.
5. Sandbox: `NOWPAYMENTS_SANDBOX=1` switches the base URL to `api-sandbox.nowpayments.io` (separate API key / IPN secret).

What the app does: `POST /v1/invoice` with `price_amount`, `price_currency=usdc`, `order_id`, `success_url`, `cancel_url`,
`ipn_callback_url`; the payer picks the coin on the hosted page; IPNs are verified with HMAC-SHA512 over the sorted JSON body
(`x-nowpayments-sig`) and then **re-confirmed** by `GET /v1/payment/{id}`; only `finished` (configurable `PAID_STATUSES`) fulfils.
`partially_paid` is recorded and shown; `expired`/`failed` releases the invoice.

---

## 4. aws deployment

Architecture: **one EC2 instance** (t4g.small is enough) · Docker Compose (`app` + `caddy`) · encrypted gp3 EBS volume holding
SQLite, uploads and backups · Elastic IP · Route 53 `A` record · S3 bucket for nightly backup copies · Secrets in SSM Parameter
Store · optional SES SMTP for email.

### 4a. one-shot with cloudformation

```bash
# 1. upload the project bundle somewhere the instance can fetch it
aws s3 mb s3://vxyltn-deploy-$ACCOUNT && aws s3 cp vxyltn-site.zip s3://vxyltn-deploy-$ACCOUNT/vxyltn-site.zip

# 2. secrets (SecureString) — any key from .env.example works, lowercase name after /vxyltn/
for kv in secret_key=$(openssl rand -hex 32) admin_email=you@vxyltn.com admin_password='<strong>' \
          nowpayments_api_key='<key>' nowpayments_ipn_secret='<secret>' smtp_host=email-smtp.eu-central-1.amazonaws.com \
          smtp_user='<ses-smtp-user>' smtp_password='<ses-smtp-pass>' smtp_from='VXYLTN <no-reply@vxyltn.com>'; do
  aws ssm put-parameter --name "/vxyltn/${kv%%=*}" --value "${kv#*=}" --type SecureString --overwrite
done

# 3. stack (grant the deploy bucket to the instance role afterwards, or make the object pre-signed)
aws cloudformation deploy --stack-name vxyltn-request --template-file deploy/aws/cloudformation.yaml \
  --capabilities CAPABILITY_IAM \
  --parameter-overrides BundleUrl=s3://vxyltn-deploy-$ACCOUNT/vxyltn-site.zip HostedZoneId=Z0123456789 DomainName=request.vxyltn.com
aws cloudformation describe-stacks --stack-name vxyltn-request --query 'Stacks[0].Outputs'
```

The instance boots, runs `deploy/aws/user-data.sh`, writes `.env` from SSM, starts the containers, and Caddy obtains the
Let's Encrypt certificate as soon as DNS resolves. `BACKUP_S3_BUCKET` is injected automatically from the stack.

### 4b. by hand

1. Launch Amazon Linux 2023 (or Ubuntu 24.04), 100 GB gp3 encrypted, security group 80/443 (+443/udp for HTTP/3), an IAM role
   with `AmazonSSMManagedInstanceCore` + S3 put/get on your backup bucket + `ssm:GetParametersByPath` on `/vxyltn/*`.
2. Allocate an Elastic IP, attach it, create the Route 53 record `request.vxyltn.com → <eip>` (A; add AAAA if you enable IPv6).
3. `scp` the zip or `git clone`, then `sudo BUNDLE_URL=... bash deploy/aws/user-data.sh` — or just:
   ```bash
   cp .env.example .env && nano .env && docker compose up -d --build
   ```
4. `docker compose logs -f app` — look for `request.vxyltn.com ready (payments on, email on, telegram …)`; a warning `price currency usdc not in NOWPayments currency list` means the account quotes in `usd` instead (same amounts).

### 4c. operations

| task | how |
|---|---|
| update | `cd /opt/vxyltn && git pull` (or unzip the new bundle over it) → `docker compose up -d --build`. The schema is applied idempotently at startup (`CREATE TABLE IF NOT EXISTS`); a release that adds columns ships its `ALTER TABLE` in `db.py`. Take a backup first (`make backup`). |
| logs | `docker compose logs -f --tail=200 app` · Caddy: `docker compose logs caddy` |
| shell | `aws ssm start-session --target <instance-id>` (no SSH port needed) |
| backup now | `make backup` (SQLite online backup into `/data/backups`), nightly at `BACKUP_HOUR_LOCAL` (03:00 local) with S3 upload when `BACKUP_S3_BUCKET` is set; the host cron also syncs `/data/uploads`. |
| restore | stop app → copy the `.sqlite3` file to `/data/vxyltn.sqlite3` → `docker compose up -d`. Uploads restore with `aws s3 sync s3://bucket/uploads <volume>/uploads`. |
| export | *admin → backups & export*: CSV/JSON of every table, zip of the vault, download of the latest backup. |
| rotate secret key | change `SECRET_KEY` and restart: all sessions and signed links are invalidated (DB passwords/2FA are unaffected). |
| admin lockout (lost 2FA) | `docker compose exec app python -c "from app.config import load_config as l;from app.db import Database as D;d=D(l().db_path);d.execute('UPDATE users SET totp_secret=NULL, recovery_codes_json=NULL WHERE email=?',('you@vxyltn.com',))"` then re-enrol. |
| maintenance mode | *admin → settings → maintenance* (admins keep access; everyone else sees the maintenance page). |
| missed ipn | *admin → purchases → (purchase) → poll* re-reads every invoice from NOWPayments, or wait for the 5-minute reconciliation job; *mark paid (manual settlement)* exists for off-platform settlement and is audit-logged. |
| scale | the app is single-instance by design (SQLite + in-process jobs). Vertical scaling (bigger instance, more IOPS) covers a creator site; put CloudFront in front for media if bandwidth matters. |

Email: Amazon SES SMTP credentials go in `SMTP_*`; verify the `vxyltn.com` domain in SES and leave the sandbox. Without SMTP the
app still works: new accounts are treated as verified, every outgoing email is written to the app log (and recorded in the audit
log as `email.queued`), and magic links / password resets are unavailable until SMTP is configured.

---

## 5. the request system (what the money buys)

* **Terms first.** One-click acceptance of the full terms (`/request/terms`, versioned by `RQ_TERMS_VERSION`) before anything else.
* **Activation.** 1,000,000 USDC per session (`RQ_SESSION_HOURS`, default 24 h). It is the only thing that grants anything: the menu.
  Starting a new session discards unpaid items and requires a new activation.
* **Offers** (all request-only, all priced above activation): channel / group / membership subscription requests (1 month = 28 days),
  outgoing text / audio / GIF / photo / video / PDF / other messages, outgoing audio / video calls, custom text / audio / GIF / photo /
  video / PDF / other, custom audio / video calls, livestream, custom livestream, priority / high-priority / urgent add-ons for an
  already-paid request, and **contributions with no limit** (any amount from 0.01 USDC).
* **Pricing pipeline** (admin-editable): unit price × units → volume multiplier (1 / 5 / 10 / 25 / 100 units) → + setup fee →
  × add-on multiplier + add-on fee → + off-hours % → + weekend % → + processing % → + request fee → round up → floor (1,000,000) →
  split into parts when `MAX_USD_PER_INVOICE_CENTS` is set.
* **After payment:** "Payment received. Request logged. Nothing is guaranteed or promised. No refund." → details form (text + files,
  English (US) only, language-gated). Paid units expire after `RQ_UNIT_EXPIRY_DAYS` (56). Paid requests cannot be edited or cancelled.
* **Admin:** every session, order, payment event, detail and file under *admin → request system*; PDF invoice/payment record per order
  (also mirrored to Telegram when `TELEGRAM_*` is set); reports (daily/weekly/monthly/custom, PDF + CSV), analytics and full history.

Subscriptions are requests. Any access that follows is a separate step inside the platform (memberships) with its own payment; the
request system never grants, delivers or refunds it.

---

## 6. platform economics

* **Floor:** 1,000 USDC on every in-app purchase (`PLATFORM_MIN_CENTS`); campaign contributions are the only unlimited-low item.
* **Tier ladder** (seeded once, editable under *admin → tiers*): `base` 1,000 · `v0` 1,500 · `v1` 2,500 · `v2` 5,000 · `v3` 10,000 ·
  `v4` 25,000 · `v4.1` 40,000 · `v4.2` 60,000 · `v4.3` 80,000 · `v4.4` 100,000 · `v4.4.1` 150,000 · `v4.4.2` 200,000 ·
  `v4.4.3` 300,000 · `v4.4.4` 400,000 · `v4.4.4.1` 500,000 · `v4.4.4.2` 650,000 · `v4.4.4.3` 800,000 · `v4.4.4.4` 1,000,000 USDC
  per 28 days. Perks per tier: DM price (free from `v4`), PPV discount 0 → 90 %, early drop access up to 168 h, priority-list
  eligibility, tip minimum. Yearly = 10× where that stays under the automated cap.
* **Audience pricing:** public ×3, follower ×2, subscriber base − tier PPV discount; content at or under the member's tier rank is
  included. Audience products: preview pass, follower badge, message packs, public question, priority DM, comment unlock,
  public / member stream tickets.
* **Caps:** 1,000,000 USDC automated cap per platform purchase (`PLATFORM_TX_CAP_CENTS`); larger amounts go through the contact flow
  and a manual invoice. KYC flag at `KYC_THRESHOLD_CENTS` (100,000) cumulative per user.

---

## 7. feature matrix

Legend: **✔ built** = fully implemented in-stack · **◐ adapter** = implemented end to end, with the vendor-specific part as a
configured integration point (works in manual/embed mode without the vendor).

| spec area | status | where |
|---|---|---|
| accounts: email + password, email verification, magic link, password reset, 2FA (TOTP + recovery codes), session list with per-device revoke, data export | ✔ built | `/signup` `/login` `/verify` `/account/security` `/account/data` |
| social sign-in (Google / Apple) | ◐ adapter | `GOOGLE_CLIENT_ID`, `APPLE_CLIENT_ID` |
| SMS codes | ◐ adapter | `TWILIO_*` |
| memberships: tiers, perks, monthly/yearly, upgrades with proration, bundles, promo codes (percent / fixed / trial), grace period with renewal reminders, cancel/resume, welcome & onboarding sequences, referral rewards | ✔ built | `/membership` · admin tiers / bundles / promos |
| pay-per-view feed: text, photo, photo set, video, audio, poll, story (expiring), scheduled posts, pinned, tags, likes, reactions, comments, comment unlock, blurred previews, per-tier/price gating | ✔ built | `/feed` `/post/{id}` · admin posts |
| vault / media library: upload, derivatives, collections, FTS search, expiry rules, archive, zip export, download tokens, per-viewer watermarks + hidden fingerprint, leak tracing (fingerprint → viewer) | ✔ built | admin vault · `/dl/{token}` · *admin → vault → fingerprint* |
| direct messages: threads, attachments, paid DMs (price by audience/tier), PPV messages, message packs/credits, priority DM, public question, read receipts, blocks, templates, mass messaging to segments with scheduling, typing/SSE live updates | ✔ built | `/messages` · admin messages / mass messages |
| livestreams: schedule, RSVP, tickets (public/member price), live chat (SSE), pinned/highlighted paid chat, goals, viewer count, replays as posts | ✔ built | `/live` · admin live |
| livestream video transport | ◐ adapter | `LIVESTREAM_PROVIDER=embed|livekit|mux|cloudflare` (embed works out of the box) |
| calls: slots, booking with hold/expiry, deposits, reminders, calendar feed (.ics), no-show marking, admin rebooking | ✔ built | `/calls` `/calls/calendar.ics` · admin calls |
| call room | ◐ adapter | `CALL_PROVIDER=link|jitsi|whereby` |
| custom-order marketplace: briefs with files, quotes, deposit → balance, priority fees, deadlines, revisions, delivery, full status lifecycle (pending → quoted → accepted → in progress → delivered → completed / disputed / canceled) | ✔ built | `/customs` · admin custom orders |
| tips: presets, custom amount, first-tip bonus, VIP minimums, tip goals, leaderboard (opt-in) | ✔ built | `/tips` · admin reports |
| fundraising campaigns: goals, perks, contributions (no minimum), progress, deadlines | ✔ built | `/fund/{slug}` · admin campaigns |
| private channels: paid join, tier gating, posts, chat, moderation | ✔ built | `/channels/{slug}` · admin channels |
| drops: limited editions, waitlist, early access by tier, countdown, sell-out | ✔ built | `/drops` · admin drops |
| merch shop: products, variants, inventory, cart, tax rates, shipping rates, orders, fulfilment, certificates of authenticity (PDF + `/coa/{serial}` verification) | ✔ built | `/shop` · admin shop / shop orders |
| Shopify sync | ◐ adapter | `SHOPIFY_STORE` / `SHOPIFY_TOKEN` (`shopify_id` on products) |
| wallet: top-ups, ledger, credits, refunds-as-credit (never as money) | ✔ built | `/wallet/topup` · admin users |
| calendar: events, availability, public `.ics` | ✔ built | `/calendar.ics` · admin calendar |
| automation: triggers (join, renew, lapse, tip, purchase, inactivity) → actions (message, tag, segment, perk) with run log | ✔ built | admin automation |
| segments & tags, CRM notes, custom fields, lifetime value | ✔ built | admin segments / users |
| AI notes (subscriber summaries) | ◐ adapter | `OPENAI_API_KEY` |
| priority (VIP) list: rules, applications, review, perks | ✔ built | `/membership/apply` · admin priority list |
| link hub + click analytics, social counters | ✔ built | home page · `/l/{id}` · admin link hub |
| KYC / age verification flags & thresholds | ✔ built (manual) / ◐ adapter | admin kyc · `KYC_PROVIDER=jumio|onfido|manual` |
| content moderation | ◐ adapter | `MODERATION_PROVIDER=hive|sightengine` |
| DMCA: notice / counter-notice / leak-report intake, status workflow, designated-agent contact | ✔ built | `/dmca` · admin dmca & leaks |
| leak alerts & tracing | ✔ built | watermark log + fingerprint lookup |
| legal: terms, privacy, age gate, geo-block, first-party view counting (no third-party analytics) | ✔ built | `/terms` `/privacy` · settings |
| audit log (every admin action, payment event, security event) | ✔ built | admin audit log |
| reports & analytics: KPIs, daily revenue/purchases/new users/new members, revenue by kind and by tier, top users, top content, audience funnel (seen → followers → members → paid), request-system revenue by offer, PDF/CSV, daily Telegram digest | ✔ built | admin reports · scheduler |
| backups & export: nightly SQLite backup, retention, S3 upload, Telegram mirror, CSV/JSON export | ✔ built | admin backups & export |
| notifications: in-app, email (SMTP), Telegram admin mirror | ✔ built / ◐ SMTP & Telegram configured | `SMTP_*`, `TELEGRAM_*` |
| payments: NOWPayments invoices (any coin), IPN verification, reconciliation, partial payments, expiry, split parts, receipts PDF, manual invoices, cap → contact flow | ✔ built | `/pay/{id}` · admin purchases / contact & manual |
| security: scrypt passwords, signed cookies, server-side sessions, CSRF, rate limits, security headers (CSP, nosniff, HSTS via Caddy), content-hashed uploads served only through controlled routes, admin 2FA | ✔ built | `app/web.py`, `app/auth.py`, `app/media.py` |
| design: black / dirty white, Cargo-style left nav, hairlines, no cards, lowercase everywhere, mobile layout | ✔ built | `app/static/style.css`, `templates/base.html` |

---

## 8. project layout

```
app/
  main.py            create_app(), bootstrap, lifespan (NOWPayments currency check, scheduler)
  config.py          env → Config
  settings.py        runtime-editable settings registry (admin → settings)
  db.py              schema + tiny data layer (sqlite, WAL, FTS5, audit, wallet ledger, backups)
  web.py             templating, auth decorators, CSRF, viewer middleware, rate limits, security headers
  auth.py            passwords, signing, TOTP, recovery codes, email tokens
  payments.py        purchases, invoices, NOWPayments checkout, IPN handling, reconciliation, caps/floors
  nowpayments.py     API client + IPN signature verification
  fulfill.py         what happens when each purchase kind is paid
  access.py          audience pricing & access resolution (public / follower / subscriber / tier)
  members.py         tiers, bundles, promos, memberships, priority list, automation, segments
  content.py media.py messaging.py live.py calls.py customs.py community.py   feature modules
  requestsys/        the request system: catalog, pricing engine, service, routes
  admin/             dashboard, declarative CRUD resources, reports, settings, pricing, backups
  routes/            public, account, checkout, feed, membership, messages, live, calls, customs, community
  templates/ static/ jinja templates (all lowercase copy) and the single stylesheet
tests/               unit + end-to-end flow tests with a NOWPayments IPN simulator
deploy/aws/          user-data.sh (EC2 bootstrap), cloudformation.yaml
deploy/caddy/        Caddyfile (automatic HTTPS, HTTP/3, 2 GB uploads)
Dockerfile docker-compose.yml requirements.txt .env.example Makefile
```

---

## 9. assumptions worth knowing

* 1 USDC is treated as 1 USD everywhere (labels, FX display, NOWPayments `price_currency`). If the NOWPayments account does not
  have `usdc` enabled, startup logs a warning and quotes in `usd`; amounts are identical.
* Tips, DMs and all platform items respect the 1,000 USDC floor; **contributions** (campaigns and the request-system contribution)
  have no floor and no ceiling.
* Yearly membership prices are seeded only where 10× the monthly price stays within the 1,000,000 automated cap; the top tiers are
  monthly-only unless you raise the cap.
* Everything is single-tenant and single-instance: one creator, one box, one SQLite file. That is deliberate.
