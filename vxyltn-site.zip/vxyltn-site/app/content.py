"""Feed content: posts, media attachments, unlocks, likes, reactions, comments, polls, collections, stories, scheduling."""
from __future__ import annotations

import json
import re
import sqlite3

from .access import post_access
from .util import loads, now_ts, slugify

POST_TYPES = ("photo", "video", "carousel", "audio", "text", "poll")
VISIBILITIES = ("public", "follower", "member", "tier", "ppv")
REACTIONS = ("❤️", "🔥", "👏", "😮", "😂", "💎")


# ----------------------------------------------------------------- queries
def feed(db, settings, viewer, limit: int = 20, offset: int = 0, collection_id: int | None = None, only_type: str | None = None,
         include_hidden: bool = False) -> list[dict]:
    ts = now_ts()
    where = ["p.deleted_at IS NULL", "p.is_archived=0"]
    params: list = []
    if not include_hidden:
        where.append("(p.published_at IS NOT NULL AND p.published_at<=?)"); params.append(ts)
        where.append("(p.expires_at IS NULL OR p.expires_at>?)"); params.append(ts)
    if collection_id:
        where.append("p.collection_id=?"); params.append(collection_id)
    if only_type:
        where.append("p.type=?"); params.append(only_type)
    params += [limit, offset]
    rows = db.all(f"SELECT p.* FROM posts p WHERE {' AND '.join(where)} ORDER BY p.is_pinned DESC, p.pin_order, p.published_at DESC, p.id DESC LIMIT ? OFFSET ?", params)
    return [decorate(db, settings, viewer, p) for p in rows]


def stories(db, settings, viewer, limit: int = 20) -> list[dict]:
    ts = now_ts()
    rows = db.all("SELECT * FROM posts WHERE deleted_at IS NULL AND expires_at IS NOT NULL AND expires_at>? AND published_at<=? ORDER BY published_at DESC LIMIT ?",
                  (ts, ts, limit))
    return [decorate(db, settings, viewer, p) for p in rows]


def decorate(db, settings, viewer, post: sqlite3.Row) -> dict:
    acc = post_access(db, settings, viewer, post)
    media = db.all("SELECT m.*, pm.position, pm.is_preview FROM post_media pm JOIN media m ON m.id=pm.media_id WHERE pm.post_id=? ORDER BY pm.position", (post["id"],))
    poll = db.one("SELECT * FROM polls WHERE post_id=?", (post["id"],)) if post["type"] == "poll" else None
    liked = bool(viewer.user_id and db.one("SELECT 1 FROM post_likes WHERE post_id=? AND user_id=?", (post["id"], viewer.user_id)))
    my_reactions = [r["emoji"] for r in db.all("SELECT emoji FROM post_reactions WHERE post_id=? AND user_id=?", (post["id"], viewer.user_id))] if viewer.user_id else []
    reactions = db.all("SELECT emoji, COUNT(*) n FROM post_reactions WHERE post_id=? GROUP BY emoji ORDER BY n DESC", (post["id"],))
    poll_data = None
    if poll:
        options = loads(poll["options_json"], [])
        counts = {int(r["option_idx"]): int(r["n"]) for r in db.all("SELECT option_idx, COUNT(*) n FROM poll_votes WHERE poll_id=? GROUP BY option_idx", (poll["id"],))}
        mine = {int(r["option_idx"]) for r in db.all("SELECT option_idx FROM poll_votes WHERE poll_id=? AND user_id=?", (poll["id"], viewer.user_id))} if viewer.user_id else set()
        total = sum(counts.values())
        poll_data = {"id": poll["id"], "question": poll["question"], "multiple": bool(poll["multiple"]), "closed": bool(poll["closes_at"] and poll["closes_at"] < now_ts()),
                     "closes_at": poll["closes_at"], "total": total,
                     "options": [{"idx": i, "text": o, "votes": counts.get(i, 0), "pct": (100 * counts.get(i, 0) // total) if total else 0, "mine": i in mine}
                                 for i, o in enumerate(options)]}
    return {"post": post, "access": acc, "media": media, "poll": poll_data, "liked": liked, "reactions": reactions, "my_reactions": my_reactions,
            "tags": loads(post["tags_json"], []), "body_html": render_markdown(post["body_md"]) if acc["state"] == "open" else "",
            "teaser_html": render_markdown(post["teaser_text"] or "") if acc["state"] != "open" else ""}


def record_view(db, post_id: int, user_id: int | None, ip: str | None) -> None:
    db.insert("post_views", post_id=post_id, user_id=user_id, ts=now_ts(), ip=ip)
    db.execute("UPDATE posts SET views_count=views_count+1 WHERE id=?", (post_id,))


# ----------------------------------------------------------------- interactions
def toggle_like(db, post_id: int, user_id: int) -> bool:
    if db.one("SELECT 1 FROM post_likes WHERE post_id=? AND user_id=?", (post_id, user_id)):
        db.execute("DELETE FROM post_likes WHERE post_id=? AND user_id=?", (post_id, user_id))
        db.execute("UPDATE posts SET likes_count=MAX(0, likes_count-1) WHERE id=?", (post_id,))
        return False
    db.insert("post_likes", post_id=post_id, user_id=user_id, created_at=now_ts())
    db.execute("UPDATE posts SET likes_count=likes_count+1 WHERE id=?", (post_id,))
    return True


def toggle_reaction(db, post_id: int, user_id: int, emoji: str) -> bool:
    if emoji not in REACTIONS:
        raise ValueError("Unknown reaction")
    if db.one("SELECT 1 FROM post_reactions WHERE post_id=? AND user_id=? AND emoji=?", (post_id, user_id, emoji)):
        db.execute("DELETE FROM post_reactions WHERE post_id=? AND user_id=? AND emoji=?", (post_id, user_id, emoji))
        return False
    db.insert("post_reactions", post_id=post_id, user_id=user_id, emoji=emoji, created_at=now_ts())
    return True


def add_comment(db, post_id: int, user_id: int, body: str, parent_id: int | None, is_private: bool = False) -> int:
    depth = 0
    if parent_id:
        parent = db.get("comments", parent_id)
        if parent is None or parent["post_id"] != post_id:
            raise ValueError("Bad parent")
        depth = min(5, int(parent["depth"]) + 1)
    cid = db.insert("comments", post_id=post_id, user_id=user_id, parent_id=parent_id, depth=depth, body=body[:2000],
                    is_private=1 if is_private else 0, created_at=now_ts())
    db.execute("UPDATE posts SET comments_count=comments_count+1 WHERE id=?", (post_id,))
    return cid


def comments_tree(db, post_id: int, viewer) -> list[dict]:
    rows = db.all("SELECT c.*, u.username, u.display_name, u.role, u.priority_status FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=? AND c.deleted_at IS NULL ORDER BY c.pinned DESC, c.id", (post_id,))
    out, by_id = [], {}
    for r in rows:
        if r["is_private"] and not (viewer.is_admin or viewer.user_id == r["user_id"]):
            continue
        node = {"row": r, "children": []}
        by_id[r["id"]] = node
        if r["parent_id"] and r["parent_id"] in by_id:
            by_id[r["parent_id"]]["children"].append(node)
        else:
            out.append(node)
    return out


def vote(db, poll_id: int, user_id: int, option_idxs: list[int]) -> None:
    poll = db.get("polls", poll_id)
    if poll is None:
        raise ValueError("Poll not found")
    if poll["closes_at"] and poll["closes_at"] < now_ts():
        raise ValueError("Poll closed")
    options = loads(poll["options_json"], [])
    idxs = [i for i in option_idxs if 0 <= i < len(options)]
    if not idxs:
        raise ValueError("Pick an option")
    if not poll["multiple"]:
        idxs = idxs[:1]
    db.execute("DELETE FROM poll_votes WHERE poll_id=? AND user_id=?", (poll_id, user_id))
    for i in idxs:
        db.insert("poll_votes", poll_id=poll_id, user_id=user_id, option_idx=i, created_at=now_ts())


# ----------------------------------------------------------------- unlock fulfilment
def grant_unlock(db, user_id: int, entity_type: str, entity_id: int, purchase_id: int | None, expires_at: int | None = None) -> None:
    if db.one("SELECT 1 FROM unlocks WHERE user_id=? AND entity_type=? AND entity_id=? AND (expires_at IS NULL OR expires_at>?)",
              (user_id, entity_type, entity_id, now_ts())):
        return
    db.insert("unlocks", user_id=user_id, entity_type=entity_type, entity_id=entity_id, purchase_id=purchase_id, created_at=now_ts(), expires_at=expires_at)
    if entity_type == "post":
        p = db.get("purchases", purchase_id) if purchase_id else None
        db.execute("UPDATE posts SET unlocks_count=unlocks_count+1, revenue_cents=revenue_cents+? WHERE id=?", (p["total_cents"] if p else 0, entity_id))


# ----------------------------------------------------------------- authoring (admin)
def create_post(db, settings, data: dict, media_ids: list[int], actor: int) -> int:
    ts = now_ts()
    ptype = data.get("type") if data.get("type") in POST_TYPES else "text"
    vis = data.get("visibility") if data.get("visibility") in VISIBILITIES else "member"
    published_at = data.get("published_at") or ts
    expires_at = data.get("expires_at")
    if data.get("story"):
        expires_at = published_at + settings.int("story_hours") * 3600
    pid = db.insert("posts", type=ptype, title=(data.get("title") or "")[:200], body_md=data.get("body_md") or "", visibility=vis,
                    min_tier_rank=int(data.get("min_tier_rank") or 0), ppv_price_cents=data.get("ppv_price_cents"),
                    public_price_cents=data.get("public_price_cents"), follower_price_cents=data.get("follower_price_cents"),
                    published_at=published_at, scheduled_at=published_at if published_at > ts else None, expires_at=expires_at,
                    collection_id=data.get("collection_id"), series_order=data.get("series_order"),
                    allow_comments=1 if data.get("allow_comments", True) else 0, comments_price_cents=data.get("comments_price_cents"),
                    watermark=1 if data.get("watermark", True) else 0, teaser_text=data.get("teaser_text") or "",
                    tags_json=json.dumps(data.get("tags") or []), created_at=ts, updated_at=ts)
    for i, mid in enumerate(media_ids):
        db.execute("INSERT OR IGNORE INTO post_media(post_id, media_id, position, is_preview) VALUES (?,?,?,?)", (pid, mid, i, 1 if i == 0 else 0))
        db.execute("UPDATE media SET usage_count=usage_count+1 WHERE id=?", (mid,))
    if ptype == "poll":
        options = [o.strip() for o in (data.get("poll_options") or []) if o.strip()][:10]
        db.insert("polls", post_id=pid, question=(data.get("poll_question") or data.get("title") or "Poll")[:300], options_json=json.dumps(options),
                  multiple=1 if data.get("poll_multiple") else 0, anonymous=1 if data.get("poll_anonymous", True) else 0,
                  closes_at=data.get("poll_closes_at"), created_at=ts)
    db.insert("calendar_events", kind="post", ref_type="post", ref_id=pid, title=(data.get("title") or f"Post #{pid}")[:200], start_at=published_at, created_at=ts)
    db.audit("post.created", actor_user_id=actor, actor_role="admin", entity_type="post", entity_id=pid, data={"type": ptype, "visibility": vis})
    return pid


def set_pin(db, settings, post_id: int, pinned: bool) -> str | None:
    if pinned:
        n = db.count("posts", "is_pinned=1 AND deleted_at IS NULL")
        if n >= settings.int("max_pins"):
            return f"Maximum {settings.int('max_pins')} pinned posts."
        db.update("posts", post_id, is_pinned=1, pin_order=n + 1, updated_at=now_ts())
    else:
        db.update("posts", post_id, is_pinned=0, pin_order=None, updated_at=now_ts())
    return None


def collections_list(db) -> list[sqlite3.Row]:
    return db.all("SELECT c.*, (SELECT COUNT(*) FROM posts p WHERE p.collection_id=c.id AND p.deleted_at IS NULL) AS n FROM collections c WHERE c.is_active=1 ORDER BY c.id DESC")


def create_collection(db, name: str, kind: str, description: str, price_cents: int | None, public_price_cents: int | None,
                      min_tier_rank: int, actor: int) -> int:
    cid = db.insert("collections", name=name[:120], slug=slugify(name), description=description, kind=kind, price_cents=price_cents,
                    public_price_cents=public_price_cents, min_tier_rank=min_tier_rank, created_at=now_ts())
    db.audit("collection.created", actor_user_id=actor, actor_role="admin", entity_type="collection", entity_id=cid)
    return cid


# ----------------------------------------------------------------- markdown (small, safe subset)
_md_link = re.compile(r"\[([^\]]+)\]\((https?://[^\s)]+)\)")
_md_bold = re.compile(r"\*\*([^*]+)\*\*")
_md_ital = re.compile(r"(?<!\*)\*([^*]+)\*(?!\*)")
_md_code = re.compile(r"`([^`]+)`")
_url = re.compile(r"(?<![\"'>])(https?://[^\s<]+)")


def render_markdown(text: str | None) -> str:
    from .util import esc
    if not text:
        return ""
    out = []
    for para in text.strip().split("\n\n"):
        lines = para.split("\n")
        if all(l.strip().startswith(("- ", "* ")) for l in lines if l.strip()):
            items = "".join(f"<li>{_inline(esc(l.strip()[2:]))}</li>" for l in lines if l.strip())
            out.append(f"<ul>{items}</ul>")
        elif lines[0].startswith("# "):
            out.append(f"<h2>{_inline(esc(lines[0][2:]))}</h2>" + ("<p>" + _inline(esc("\n".join(lines[1:]))).replace("\n", "<br>") + "</p>" if len(lines) > 1 else ""))
        elif lines[0].startswith("> "):
            out.append("<blockquote>" + _inline(esc("\n".join(l[2:] if l.startswith("> ") else l for l in lines))).replace("\n", "<br>") + "</blockquote>")
        else:
            out.append("<p>" + _inline(esc(para)).replace("\n", "<br>") + "</p>")
    return "\n".join(out)


def _inline(s: str) -> str:
    s = _md_code.sub(r"<code>\1</code>", s)
    s = _md_bold.sub(r"<strong>\1</strong>", s)
    s = _md_ital.sub(r"<em>\1</em>", s)
    s = _md_link.sub(r'<a href="\2" rel="noopener nofollow" target="_blank">\1</a>', s)
    s = _url.sub(r'<a href="\1" rel="noopener nofollow" target="_blank">\1</a>', s)
    return s
