"""ASGI application factory for request.vxyltn.com."""
from __future__ import annotations

import contextlib
import importlib
import logging
import os

from starlette.applications import Starlette
from starlette.exceptions import HTTPException
from starlette.middleware import Middleware
from starlette.requests import Request
from starlette.responses import PlainTextResponse
from starlette.routing import Mount
from starlette.staticfiles import StaticFiles

from . import auth, members
from .config import Config, load_config
from .core import Core, build_core
from .scheduler import Scheduler
from .util import now_ts, token_urlsafe
from .web import ViewerMiddleware, render, setup_templates

log = logging.getLogger("vx")
STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")
ROUTE_MODULES = ("routes.public", "routes.account", "routes.checkout", "requestsys.routes", "routes.feed", "routes.membership",
                 "routes.messages", "routes.live", "routes.calls", "routes.customs", "routes.community", "admin.routes")


def bootstrap(core: Core) -> None:
    """First-run setup: admin account, default tiers, default rates."""
    db, cfg = core.db, core.cfg
    members.ensure_default_tiers(db)
    if cfg.admin_email:
        admin = db.one("SELECT * FROM users WHERE lower(email)=lower(?)", (cfg.admin_email,))
        if admin is None:
            pw = cfg.admin_password or token_urlsafe(12)
            uid = db.insert("users", email=cfg.admin_email.lower(), password_hash=auth.hash_password(pw), role="admin", display_name=cfg.site_name,
                            username="vxyltn", email_verified_at=now_ts(), age_confirmed_at=now_ts(), referral_code=token_urlsafe(6),
                            created_at=now_ts(), is_follower=1, followed_at=now_ts())
            db.audit("bootstrap.admin_created", actor_role="system", entity_type="user", entity_id=uid)
            if not cfg.admin_password:
                log.warning("Admin account %s created with a generated password: %s  (change it after first login)", cfg.admin_email, pw)
        elif admin["role"] != "admin":
            db.update("users", admin["id"], role="admin")
    if not db.count("shipping_rates"):
        db.insert("shipping_rates", zone="world", countries_json="[]", shipping_class="standard", price_cents=10_000, per_item_cents=2_500, label="worldwide tracked")
    if not db.count("message_packs"):
        db.insert("message_packs", name="10 messages", count=10, price_cents=800_000, days_valid=60, created_at=now_ts())
        db.insert("message_packs", name="50 messages", count=50, price_cents=3_500_000, days_valid=90, created_at=now_ts())


def _load_routes() -> list:
    routes: list = []
    for mod_name in ROUTE_MODULES:
        try:
            mod = importlib.import_module(f"app.{mod_name}")
        except ModuleNotFoundError as exc:  # pragma: no cover - during incremental development only
            if exc.name and exc.name.startswith("app."):
                log.warning("route module %s not available: %s", mod_name, exc)
                continue
            raise
        routes.extend(getattr(mod, "routes", []))
    return routes


async def not_found(request: Request, exc: HTTPException):
    if request.url.path.startswith("/api/"):
        return PlainTextResponse("not found", status_code=404)
    return render(request, "error.html", status_code=404, status="not found", message="this page does not exist.")


async def server_error(request: Request, exc: Exception):
    log.exception("unhandled error on %s", request.url.path)
    try:
        return render(request, "error.html", status_code=500, status="error", message="something broke on our side. try again.")
    except Exception:  # pragma: no cover
        return PlainTextResponse("error", status_code=500)


async def http_error(request: Request, exc: HTTPException):
    if exc.status_code == 404:
        return await not_found(request, exc)
    return render(request, "error.html", status_code=exc.status_code, status=str(exc.status_code), message=exc.detail or "request refused.")


def create_app(cfg: Config | None = None, run_jobs: bool = True) -> Starlette:
    cfg = cfg or load_config()
    logging.basicConfig(level=getattr(logging, cfg.log_level, logging.INFO), format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    core = build_core(cfg)
    setup_templates(core)
    bootstrap(core)
    scheduler = Scheduler(core)

    @contextlib.asynccontextmanager
    async def lifespan(app):
        if run_jobs:
            await core.np.verify_price_currency()
            scheduler.start()
        log.info("%s ready (payments %s, email %s, telegram %s)", cfg.site_domain, "on" if core.np.enabled else "OFF",
                 "on" if core.emailer.enabled else "off", "on" if core.notifier.tg_enabled else "off")
        try:
            yield
        finally:
            await scheduler.stop()
            await core.np.close()
            await core.notifier.close()
            core.db.close()

    app = Starlette(
        debug=cfg.debug,
        routes=_load_routes() + [Mount("/static", app=StaticFiles(directory=STATIC_DIR), name="static")],
        middleware=[Middleware(ViewerMiddleware)],
        exception_handlers={404: not_found, 500: server_error, HTTPException: http_error},
        lifespan=lifespan,
        max_body_size=cfg.max_upload_mb * 1024 * 1024 + 1024 * 1024,
    )
    app.state.core = core
    app.state.scheduler = scheduler
    return app


def main() -> None:  # pragma: no cover - entrypoint
    import uvicorn
    cfg = load_config()
    uvicorn.run(create_app(cfg), host="0.0.0.0", port=cfg.port, proxy_headers=cfg.trusted_proxy, forwarded_allow_ips="*", log_level=cfg.log_level.lower())


if __name__ == "__main__":  # pragma: no cover
    main()
