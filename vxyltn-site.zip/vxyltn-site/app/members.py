"""Memberships: tiers, bundles, promo codes, periods, upgrades, priority list, referrals, onboarding automation."""
from __future__ import annotations

import json
import sqlite3

from .access import active_membership, tier_perks
from .money import usd
from .util import loads, now_ts, slugify

MONTH = 28 * 86400
YEAR = 365 * 86400


# ----------------------------------------------------------------- tiers
def tiers(db, active_only: bool = True) -> list[sqlite3.Row]:
    where = "WHERE is_active=1" if active_only else ""
    return db.all(f"SELECT * FROM tiers {where} ORDER BY rank, price_month_cents")


def tier_by_slug(db, slug: str) -> sqlite3.Row | None:
    return db.one("SELECT * FROM tiers WHERE slug=?", (slug,))


def tier_member_count(db, tier_id: int) -> int:
    return db.count("memberships", "tier_id=? AND status IN ('active','grace') AND current_period_end>?", (tier_id, now_ts()))


def tier_full(db, tier) -> bool:
    return bool(tier["max_members"]) and tier_member_count(db, tier["id"]) >= int(tier["max_members"])


def bundles_for(db, tier_id: int | None = None) -> list[sqlite3.Row]:
    ts = now_ts()
    where = ["b.is_active=1", "(b.starts_at IS NULL OR b.starts_at<=?)", "(b.ends_at IS NULL OR b.ends_at>?)"]
    params = [ts, ts]
    if tier_id:
        where.append("b.tier_id=?"); params.append(tier_id)
    return db.all(f"SELECT b.*, t.name AS tier_name, t.rank AS tier_rank FROM bundles b JOIN tiers t ON t.id=b.tier_id WHERE {' AND '.join(where)} ORDER BY b.months", params)


# ----------------------------------------------------------------- promo codes
def promo_lookup(db, code: str | None, applies_to: str, entity_id: int | None, user_id: int | None) -> tuple[sqlite3.Row | None, str | None]:
    if not code:
        return None, None
    row = db.one("SELECT * FROM promo_codes WHERE upper(code)=upper(?) AND is_active=1", (code.strip(),))
    if row is None:
        return None, "Promo code not found."
    ts = now_ts()
    if row["starts_at"] and row["starts_at"] > ts:
        return None, "Promo code not active yet."
    if row["ends_at"] and row["ends_at"] < ts:
        return None, "Promo code expired."
    if row["max_uses"] and row["uses"] >= row["max_uses"]:
        return None, "Promo code fully used."
    if row["applies_to"] not in ("all", applies_to):
        return None, "Promo code does not apply here."
    if row["entity_id"] and entity_id and row["entity_id"] != entity_id:
        return None, "Promo code does not apply to this item."
    if user_id and row["per_user_limit"]:
        used = db.count("promo_redemptions", "promo_id=? AND user_id=?", (row["id"], user_id))
        if used >= row["per_user_limit"]:
            return None, "You already used this code."
    return row, None


def promo_discount(promo: sqlite3.Row | None, amount_cents: int) -> int:
    if promo is None:
        return 0
    if promo["kind"] == "percent":
        return min(amount_cents, (amount_cents * int(promo["value"])) // 100)
    if promo["kind"] == "fixed":
        return min(amount_cents, int(promo["value"]))
    if promo["kind"] == "trial":
        return amount_cents
    return 0


# ----------------------------------------------------------------- pricing of a period
def period_price(db, tier: sqlite3.Row, months: int, yearly: bool, user_id: int | None) -> tuple[int, str]:
    """Price for the requested period; applies intro pricing for first periods."""
    if yearly and tier["price_year_cents"]:
        return int(tier["price_year_cents"]), "1 year"
    base = int(tier["price_month_cents"]) * months
    label = f"{months} month{'s' if months != 1 else ''} (28 days each)"
    if tier["intro_price_cents"] is not None and tier["intro_periods"] and user_id:
        prior = db.count("membership_periods", "membership_id IN (SELECT id FROM memberships WHERE user_id=? AND tier_id=?)", (user_id, tier["id"]))
        intro_left = max(0, int(tier["intro_periods"]) - prior)
        if intro_left:
            intro_months = min(months, intro_left)
            base = int(tier["intro_price_cents"]) * intro_months + int(tier["price_month_cents"]) * (months - intro_months)
            label += f" (intro price on {intro_months})"
    return base, label


def proration_credit(db, settings, user_id: int) -> int:
    """Unused value of the current membership period, credited when upgrading."""
    m, tier = active_membership(db, user_id, settings.int("membership_grace_days"))
    if m is None or tier is None:
        return 0
    ts = now_ts()
    remaining = max(0, int(m["current_period_end"]) - ts)
    period = db.one("SELECT * FROM membership_periods WHERE membership_id=? ORDER BY id DESC LIMIT 1", (m["id"],))
    if period is None or period["end_at"] <= period["start_at"]:
        return 0
    span = int(period["end_at"]) - int(period["start_at"])
    return int(int(period["price_cents"]) * min(remaining, span) / span)


# ----------------------------------------------------------------- grant / extend
def grant_period(core, user_id: int, tier_id: int, seconds: int, price_cents: int, purchase_id: int | None, source: str) -> sqlite3.Row:
    """Create or extend a membership for the tier; downgrade/upgrade handled by caller."""
    db = core.db
    ts = now_ts()
    current = db.one("SELECT * FROM memberships WHERE user_id=? AND tier_id=? AND status IN ('active','grace') ORDER BY current_period_end DESC LIMIT 1", (user_id, tier_id))
    if current and current["current_period_end"] > ts:
        start = int(current["current_period_end"])
        end = start + seconds
        db.update("memberships", current["id"], current_period_end=end, status="active", grace_until=None)
        mid = current["id"]
    else:
        start, end = ts, ts + seconds
        if current:
            db.update("memberships", current["id"], status="active", started_at=ts, current_period_end=end, grace_until=None, canceled_at=None, source=source, purchase_id=purchase_id)
            mid = current["id"]
        else:
            mid = db.insert("memberships", user_id=user_id, tier_id=tier_id, status="active", started_at=ts, current_period_end=end,
                            source=source, purchase_id=purchase_id, created_at=ts)
            _enqueue_onboarding(core, user_id, tier_id)
    db.insert("membership_periods", membership_id=mid, start_at=start, end_at=end, price_cents=price_cents, purchase_id=purchase_id, created_at=ts)
    # End lower/other active tiers (one active tier at a time; highest wins)
    db.execute("UPDATE memberships SET status='superseded' WHERE user_id=? AND tier_id<>? AND status IN ('active','grace')", (user_id, tier_id))
    db.execute("UPDATE users SET is_follower=1, followed_at=COALESCE(followed_at, ?) WHERE id=?", (ts, user_id))
    db.audit("membership.granted", actor_user_id=user_id, entity_type="membership", entity_id=mid,
             data={"tier_id": tier_id, "seconds": seconds, "price_cents": price_cents, "source": source})
    _check_priority_auto(core, user_id)
    _reward_referral(core, user_id)
    return db.get("memberships", mid)


def _enqueue_onboarding(core, user_id: int, tier_id: int) -> None:
    db = core.db
    ts = now_ts()
    rules = db.all("SELECT * FROM automation_rules WHERE is_active=1 AND kind IN ('welcome','followup','drip','upsell','first_tip_incentive')"
                   " AND (tier_id IS NULL OR tier_id=?)", (tier_id,))
    for r in rules:
        db.insert("automation_runs", rule_id=r["id"], user_id=user_id, due_at=ts + int(r["delay_hours"]) * 3600, created_at=ts)
    # Built-in welcome message from the tier template even without rules
    tier = db.get("tiers", tier_id)
    if tier and tier["welcome_template"]:
        user = db.get("users", user_id)
        body = render_template(tier["welcome_template"], user, tier)
        db.insert("messages", thread_user_id=user_id, sender_role="creator", body=body, created_at=ts)
        db.notify(user_id, "message", "New message", body[:120], "/messages")


def render_template(template: str, user, tier=None) -> str:
    name = (user["display_name"] or user["username"] or (user["email"] or "").split("@")[0]) if user else "there"
    out = template.replace("{name}", name).replace("{tier}", tier["name"] if tier else "")
    return out


def _reward_referral(core, user_id: int) -> None:
    db = core.db
    ref = db.one("SELECT * FROM referrals WHERE referred_id=? AND status='pending'", (user_id,))
    if ref is None:
        return
    reward = core.settings.int("referral_reward_cents")
    if reward > 0:
        db.wallet_apply(ref["referrer_id"], reward, "referral reward", "user", user_id)
        db.notify(ref["referrer_id"], "referral", "Referral reward", f"{usd(reward)} credit added for a referred member.", "/account")
    db.update("referrals", ref["id"], status="rewarded", reward_cents=reward, rewarded_at=now_ts())


# ----------------------------------------------------------------- priority list
def priority_rules(settings) -> dict:
    return {"spend_cents": 2_500_000, "months": 6}


def _check_priority_auto(core, user_id: int) -> None:
    db = core.db
    user = db.get("users", user_id)
    if user is None or user["priority_status"] in ("approved", "revoked"):
        return
    m, tier = active_membership(db, user_id)
    perks = tier_perks(tier)
    rules = priority_rules(core.settings)
    first = db.scalar("SELECT MIN(started_at) FROM memberships WHERE user_id=?", (user_id,), default=None)
    loyal = bool(first) and (now_ts() - int(first)) >= rules["months"] * MONTH
    if perks.get("priority_eligible") or user["total_spent_cents"] >= rules["spend_cents"] or loyal:
        db.update("users", user_id, priority_status="approved", priority_at=now_ts())
        db.audit("priority.auto_approved", actor_user_id=user_id, entity_type="user", entity_id=user_id)
        db.notify(user_id, "priority", "Priority list", "You are on the priority list.", "/account")


def apply_priority(db, user_id: int, text: str) -> int:
    pid = db.insert("priority_applications", user_id=user_id, text=text[:4000], created_at=now_ts())
    db.update("users", user_id, priority_status="applied")
    return pid


def review_priority(db, app_id: int, approve: bool, note: str, actor: int) -> None:
    app = db.get("priority_applications", app_id)
    if app is None:
        return
    db.update("priority_applications", app_id, status="approved" if approve else "declined", reviewer_note=note, reviewed_at=now_ts())
    db.update("users", app["user_id"], priority_status="approved" if approve else "none", priority_at=now_ts() if approve else None)
    db.audit("priority.reviewed", actor_user_id=actor, actor_role="admin", entity_type="user", entity_id=app["user_id"], data={"approve": approve, "note": note})
    db.notify(app["user_id"], "priority", "Priority list", "Approved." if approve else "Not approved at this time.", "/account")


# ----------------------------------------------------------------- segments
def segment_user_ids(db, rules: dict) -> list[int]:
    where, params = ["u.deleted_at IS NULL", "u.blocked=0"], []
    ts = now_ts()
    if rules.get("tier_ranks"):
        where.append("u.id IN (SELECT m.user_id FROM memberships m JOIN tiers t ON t.id=m.tier_id WHERE m.status IN ('active','grace') AND m.current_period_end>? AND t.rank IN (%s))"
                     % ",".join("?" for _ in rules["tier_ranks"]))
        params += [ts, *rules["tier_ranks"]]
    if rules.get("members") is True:
        where.append("u.id IN (SELECT user_id FROM memberships WHERE status IN ('active','grace') AND current_period_end>?)"); params.append(ts)
    if rules.get("members") is False:
        where.append("u.id NOT IN (SELECT user_id FROM memberships WHERE status IN ('active','grace') AND current_period_end>?)"); params.append(ts)
    if rules.get("followers_only"):
        where.append("u.is_follower=1")
    if rules.get("priority"):
        where.append("u.priority_status='approved'")
    if rules.get("min_spend_cents"):
        where.append("u.total_spent_cents>=?"); params.append(int(rules["min_spend_cents"]))
    if rules.get("joined_after"):
        where.append("u.created_at>=?"); params.append(int(rules["joined_after"]))
    if rules.get("inactive_days"):
        where.append("COALESCE(u.last_seen_at,0)<?"); params.append(ts - int(rules["inactive_days"]) * 86400)
    if rules.get("user_ids"):
        where.append("u.id IN (%s)" % ",".join("?" for _ in rules["user_ids"])); params += list(rules["user_ids"])
    return [r["id"] for r in db.all(f"SELECT u.id FROM users u WHERE {' AND '.join(where)}", params)]


# ----------------------------------------------------------------- housekeeping jobs
def run_membership_housekeeping(core) -> dict:
    db = core.db
    ts = now_ts()
    grace = core.settings.int("membership_grace_days") * 86400
    remind = core.settings.int("renewal_reminder_days") * 86400
    out = {"grace": 0, "expired": 0, "reminded": 0}
    for m in db.all("SELECT * FROM memberships WHERE status='active' AND current_period_end<=?", (ts,)):
        db.update("memberships", m["id"], status="grace", grace_until=int(m["current_period_end"]) + grace)
        db.notify(m["user_id"], "membership", "Membership period ended", "Renew to keep access.", "/membership")
        _enqueue_kind(core, m["user_id"], m["tier_id"], "renewal_offer")
        out["grace"] += 1
    for m in db.all("SELECT * FROM memberships WHERE status='grace' AND COALESCE(grace_until,0)<=?", (ts,)):
        db.update("memberships", m["id"], status="expired")
        _enqueue_kind(core, m["user_id"], m["tier_id"], "winback")
        out["expired"] += 1
    if remind:
        for m in db.all("SELECT * FROM memberships WHERE status='active' AND current_period_end BETWEEN ? AND ? AND renewal_reminded_at IS NULL", (ts, ts + remind)):
            db.update("memberships", m["id"], renewal_reminded_at=ts)
            db.notify(m["user_id"], "membership", "Membership renews soon", f"Period ends {core.local(m['current_period_end'])}. Renew to keep access.", "/membership")
            out["reminded"] += 1
    return out


def _enqueue_kind(core, user_id: int, tier_id: int, kind: str) -> None:
    db = core.db
    ts = now_ts()
    for r in db.all("SELECT * FROM automation_rules WHERE is_active=1 AND kind=? AND (tier_id IS NULL OR tier_id=?)", (kind, tier_id)):
        db.insert("automation_runs", rule_id=r["id"], user_id=user_id, due_at=ts + int(r["delay_hours"]) * 3600, created_at=ts)


def run_automation(core, limit: int = 200) -> int:
    db = core.db
    ts = now_ts()
    n = 0
    for run in db.all("SELECT r.*, a.kind, a.template, a.media_id, a.conditions_json FROM automation_runs r JOIN automation_rules a ON a.id=r.rule_id"
                      " WHERE r.status='queued' AND r.due_at<=? ORDER BY r.due_at LIMIT ?", (ts, limit)):
        user = db.get("users", run["user_id"])
        if user is None or user["blocked"]:
            db.update("automation_runs", run["id"], status="skipped", run_at=ts)
            continue
        cond = loads(run["conditions_json"], {})
        if cond.get("if_no_interaction_hours"):
            since = ts - int(cond["if_no_interaction_hours"]) * 3600
            if db.one("SELECT 1 FROM messages WHERE thread_user_id=? AND sender_role='user' AND created_at>?", (user["id"], since)):
                db.update("automation_runs", run["id"], status="skipped", run_at=ts)
                continue
        m, tier = active_membership(db, user["id"])
        body = render_template(run["template"] or "", user, tier)
        if body:
            db.insert("messages", thread_user_id=user["id"], sender_role="creator", body=body, media_id=run["media_id"], created_at=ts)
            db.notify(user["id"], "message", "New message", body[:120], "/messages")
        db.update("automation_runs", run["id"], status="sent", run_at=ts)
        n += 1
    return n


TIER_LADDER = (
    # name, price per 28 days (cents), perks
    ("base", 100_000, {"dm_price_cents": 100_000, "ppv_discount_pct": 0}),
    ("v0", 150_000, {"dm_price_cents": 100_000, "ppv_discount_pct": 5}),
    ("v1", 250_000, {"dm_price_cents": 100_000, "ppv_discount_pct": 10}),
    ("v2", 500_000, {"dm_price_cents": 100_000, "ppv_discount_pct": 15, "early_drop_hours": 6}),
    ("v3", 1_000_000, {"dm_price_cents": 100_000, "ppv_discount_pct": 20, "early_drop_hours": 12}),
    ("v4", 2_500_000, {"dm_price_cents": 0, "ppv_discount_pct": 25, "early_drop_hours": 24, "priority_eligible": True}),
    ("v4.1", 4_000_000, {"dm_price_cents": 0, "ppv_discount_pct": 30, "early_drop_hours": 24, "priority_eligible": True}),
    ("v4.2", 6_000_000, {"dm_price_cents": 0, "ppv_discount_pct": 35, "early_drop_hours": 36, "priority_eligible": True}),
    ("v4.3", 8_000_000, {"dm_price_cents": 0, "ppv_discount_pct": 40, "early_drop_hours": 36, "priority_eligible": True}),
    ("v4.4", 10_000_000, {"dm_price_cents": 0, "ppv_discount_pct": 45, "early_drop_hours": 48, "priority_eligible": True}),
    ("v4.4.1", 15_000_000, {"dm_price_cents": 0, "ppv_discount_pct": 50, "early_drop_hours": 48, "priority_eligible": True}),
    ("v4.4.2", 20_000_000, {"dm_price_cents": 0, "ppv_discount_pct": 55, "early_drop_hours": 72, "priority_eligible": True}),
    ("v4.4.3", 30_000_000, {"dm_price_cents": 0, "ppv_discount_pct": 60, "early_drop_hours": 72, "priority_eligible": True}),
    ("v4.4.4", 40_000_000, {"dm_price_cents": 0, "ppv_discount_pct": 65, "early_drop_hours": 96, "priority_eligible": True}),
    ("v4.4.4.1", 50_000_000, {"dm_price_cents": 0, "ppv_discount_pct": 70, "early_drop_hours": 96, "priority_eligible": True}),
    ("v4.4.4.2", 65_000_000, {"dm_price_cents": 0, "ppv_discount_pct": 75, "early_drop_hours": 120, "priority_eligible": True}),
    ("v4.4.4.3", 80_000_000, {"dm_price_cents": 0, "ppv_discount_pct": 80, "early_drop_hours": 120, "priority_eligible": True}),
    ("v4.4.4.4", 100_000_000, {"dm_price_cents": 0, "ppv_discount_pct": 90, "early_drop_hours": 168, "priority_eligible": True, "tip_min_cents": 250_000}),
)


def ensure_default_tiers(db) -> None:
    """Seed the versioned tier ladder (base -> v4.4.4.4). Prices in cents; yearly = 10x where it stays under the automated cap."""
    if db.count("tiers"):
        return
    ts = now_ts()
    for rank, (name, price, perks) in enumerate(TIER_LADDER, start=1):
        yearly = price * 10 if price * 10 <= 100_000_000 else None
        db.insert("tiers", name=name, slug=slugify(name), description="", price_month_cents=price, price_year_cents=yearly, rank=rank,
                  perks_json=json.dumps(perks), created_at=ts, welcome_template="welcome, {name}. you are in {tier}.")
