"""PDF documents: request-system invoice/payment record, purchase receipt, certificate of authenticity, analytics report."""
from __future__ import annotations

import io
import json
import os
from datetime import datetime, timezone

from reportlab.lib import colors
from reportlab.lib.enums import TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from .money import usd
from .requestsys import catalog as rq_catalog
from .requestsys.pricing import Quote
from .util import esc, fmt_local, fmt_utc, loads

_FONT, _FONT_BOLD, _MONO = "Helvetica", "Helvetica-Bold", "Courier"
for _cand in ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/TTF/DejaVuSans.ttf"):
    if os.path.exists(_cand):
        try:
            pdfmetrics.registerFont(TTFont("DejaVuSans", _cand))
            _FONT = "DejaVuSans"
            _b = _cand.replace("DejaVuSans.ttf", "DejaVuSans-Bold.ttf")
            if os.path.exists(_b):
                pdfmetrics.registerFont(TTFont("DejaVuSans-Bold", _b)); _FONT_BOLD = "DejaVuSans-Bold"
            _m = _cand.replace("DejaVuSans.ttf", "DejaVuSansMono.ttf")
            if os.path.exists(_m):
                pdfmetrics.registerFont(TTFont("DejaVuSansMono", _m)); _MONO = "DejaVuSansMono"
        except Exception:  # pragma: no cover
            pass
        break

INK, MUTED, LINE, HEAD = colors.HexColor("#111111"), colors.HexColor("#555555"), colors.HexColor("#BBBBBB"), colors.HexColor("#EFEFEF")
_ss = getSampleStyleSheet()
S_TITLE = ParagraphStyle("t", parent=_ss["Title"], fontName=_FONT_BOLD, fontSize=18, leading=22, alignment=0)
S_H = ParagraphStyle("h", parent=_ss["Heading2"], fontName=_FONT_BOLD, fontSize=11.5, leading=14, spaceBefore=10, spaceAfter=4, textColor=INK)
S_BODY = ParagraphStyle("b", parent=_ss["BodyText"], fontName=_FONT, fontSize=8.8, leading=11.5, textColor=INK)
S_SMALL = ParagraphStyle("s", parent=S_BODY, fontSize=7.6, leading=9.6, textColor=MUTED)
S_MONO = ParagraphStyle("m", parent=S_BODY, fontName=_MONO, fontSize=7.4, leading=9.2)
S_RIGHT = ParagraphStyle("r", parent=S_BODY, alignment=TA_RIGHT)
S_CELL = ParagraphStyle("c", parent=S_BODY, fontSize=8, leading=10)
S_CELL_B = ParagraphStyle("cb", parent=S_CELL, fontName=_FONT_BOLD)


def P(text, style=S_CELL):
    return Paragraph(esc(text if text is not None else "-").replace("\n", "<br/>"), style)


def _table(rows, widths=None, header=True):
    data = [[c if isinstance(c, Paragraph) else P(c, S_CELL_B if header and i == 0 else S_CELL) for c in row] for i, row in enumerate(rows)]
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0, hAlign="LEFT")
    style = [("GRID", (0, 0), (-1, -1), 0.4, LINE), ("VALIGN", (0, 0), (-1, -1), "TOP"),
             ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
             ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5)]
    if header:
        style.append(("BACKGROUND", (0, 0), (-1, 0), HEAD))
    t.setStyle(TableStyle(style))
    return t


def _kv(pairs, widths=(48 * mm, 122 * mm)):
    t = Table([[P(k, S_CELL_B), P(v)] for k, v in pairs], colWidths=list(widths), hAlign="LEFT")
    t.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, -1), 0.3, LINE), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("LEFTPADDING", (0, 0), (-1, -1), 3), ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
    return t


def _footer(cfg, label):
    def draw(canvas, doc):
        canvas.saveState()
        canvas.setFont(_FONT, 7)
        canvas.setFillColor(MUTED)
        canvas.drawString(15 * mm, 10 * mm, f"{cfg.site_name} | {cfg.creator_handle} | {cfg.site_domain} | {label}")
        canvas.drawRightString(A4[0] - 15 * mm, 10 * mm, f"Page {doc.page}")
        canvas.setStrokeColor(LINE)
        canvas.line(15 * mm, 13 * mm, A4[0] - 15 * mm, 13 * mm)
        canvas.restoreState()
    return draw


def _doc(buf, title, cfg):
    return SimpleDocTemplate(buf, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=14 * mm, bottomMargin=18 * mm,
                             title=title, author=cfg.site_name, subject=title)


def _header(story, cfg, title, subtitle):
    head = Table([[Paragraph(f"<b>{esc(cfg.site_name)}</b>", S_TITLE),
                   Paragraph(f"{esc(cfg.creator_handle)}<br/>{esc(cfg.site_domain)}<br/>{esc(cfg.main_site)}", S_RIGHT)]], colWidths=[110 * mm, 70 * mm])
    head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, 0), 1, INK), ("BOTTOMPADDING", (0, 0), (-1, 0), 6)]))
    story += [head, Spacer(1, 6), Paragraph(esc(title), S_H), Paragraph(esc(subtitle), S_SMALL), Spacer(1, 4)]


def _purchase_block(core, story, purchase):
    db, tz = core.db, core.tz
    if purchase is None:
        story.append(Paragraph("No purchase linked.", S_BODY))
        return
    story.append(Paragraph("Payment (NOWPayments, cryptocurrency)", S_H))
    story.append(_kv([("Purchase", purchase["public_id"]), ("Status", purchase["status"]), ("Total", usd(purchase["total_cents"])),
                      ("Paid", f"{usd(purchase['paid_cents'])} ({purchase['parts_paid']}/{purchase['parts_total']} parts)"),
                      ("Created", f"{fmt_local(purchase['created_at'], tz)} / {fmt_utc(purchase['created_at'])}"),
                      ("Paid at", f"{fmt_local(purchase['paid_at'], tz)} / {fmt_utc(purchase['paid_at'])}" if purchase["paid_at"] else "-"),
                      ("IP", purchase["ip"] or "-")]))
    rows = [["#", "Amount", "Status", "NP invoice", "NP payment", "Pay currency", "Pay amount", "Actually paid", "Outcome", "Tx hash", "Paid at (UTC)"]]
    for inv in db.all("SELECT * FROM invoices WHERE purchase_id=? ORDER BY part_no", (purchase["id"],)):
        rows.append([str(inv["part_no"]), usd(inv["amount_cents"]), f"{inv['status']} / {inv['np_status']}", P(inv["np_invoice_id"] or "-", S_MONO),
                     P(inv["np_payment_id"] or "-", S_MONO), inv["pay_currency"] or "-", inv["pay_amount"] or "-", inv["actually_paid"] or "-",
                     f"{inv['outcome_amount'] or '-'} {inv['outcome_currency'] or ''}", P(inv["payin_hash"] or "-", S_MONO),
                     fmt_utc(inv["paid_at"]) if inv["paid_at"] else "-"])
    story.append(_table(rows, [7 * mm, 18 * mm, 20 * mm, 18 * mm, 18 * mm, 13 * mm, 15 * mm, 15 * mm, 18 * mm, 26 * mm, 24 * mm]))
    events = db.all("SELECT e.* FROM payment_events e JOIN invoices i ON i.id=e.invoice_id WHERE i.purchase_id=? ORDER BY e.id", (purchase["id"],))
    if events:
        rows = [["Received (UTC)", "Source", "Status", "Signature", "NP payment"]]
        for e in events:
            rows.append([fmt_utc(e["received_at"]), e["source"], e["status"], "ok" if e["sig_ok"] else "n/a", P(e["np_payment_id"] or "-", S_MONO)])
        story.append(Spacer(1, 3))
        story.append(_table(rows, [34 * mm, 16 * mm, 24 * mm, 18 * mm, 40 * mm]))


def _user_pairs(core, user):
    tz = core.tz
    if user is None:
        return [("User", "-")]
    return [("User ID", str(user["id"])), ("Email", user["email"] or "-"), ("Username", user["username"] or "-"),
            ("Display name", user["display_name"] or "-"), ("Country / TZ", f"{user['country'] or '-'} / {user['timezone'] or '-'}"),
            ("Email verified", fmt_utc(user["email_verified_at"]) if user["email_verified_at"] else "no"),
            ("Age confirmed", fmt_utc(user["age_confirmed_at"]) if user["age_confirmed_at"] else "no"),
            ("KYC", user["kyc_status"]), ("Priority list", user["priority_status"]),
            ("Created / last seen", f"{fmt_local(user['created_at'], tz)} / {fmt_local(user['last_seen_at'], tz)}"),
            ("Lifetime spent", usd(user["total_spent_cents"])), ("Purchases", str(user["purchases_count"])), ("Admin note", user["admin_note"] or "-")]


# ------------------------------------------------------------------ request invoice
def build_request_pdf(core, order) -> bytes:
    cfg, db, tz = core.cfg, core.db, core.tz
    user = db.get("users", order["user_id"])
    purchase = db.get("purchases", order["purchase_id"]) if order["purchase_id"] else None
    quote = Quote.from_json(order["quote_json"])
    offer = rq_catalog.get_offer(order["offer_key"])
    details = db.all("SELECT d.*, m.filename FROM rq_details d LEFT JOIN media m ON m.id=d.media_id WHERE d.order_id=? ORDER BY d.id", (order["id"],))
    audit = list(reversed(db.all("SELECT * FROM audit_log WHERE entity_type='rq_order' AND entity_id=? ORDER BY id DESC LIMIT 100", (order["public_id"],))))
    terms = db.one("SELECT * FROM rq_terms WHERE user_id=? ORDER BY accepted_at DESC LIMIT 1", (order["user_id"],))
    session = db.get("rq_sessions", order["session_id"]) if order["session_id"] else None
    now = datetime.now(timezone.utc)
    buf = io.BytesIO()
    doc = _doc(buf, f"{order['invoice_no']} {order['public_id']}", cfg)
    story: list = []
    _header(story, cfg, f"Request payment record {order['invoice_no']}",
            f"Request {order['public_id']} | generated {now.strftime('%Y-%m-%d %H:%M:%S')} UTC | {fmt_local(now.timestamp(), tz)}")
    story.append(Paragraph(f"<b>Status:</b> {esc(order['status'].upper())} (admin: {esc(order['admin_status'])}) &nbsp;&nbsp; <b>Total:</b> {usd(order['total_cents'])}", S_BODY))
    story.append(Paragraph("Request", S_H))
    story.append(_kv([("Request ID", order["public_id"]), ("Invoice number", order["invoice_no"]), ("Offer", f"{order['offer_name']} ({order['offer_key']})"),
                      ("Category", rq_catalog.CATEGORY_BY_KEY[order["category"]].name if order["category"] in rq_catalog.CATEGORY_BY_KEY else order["category"]),
                      ("Kind", order["kind"]), ("Units", f"{order['units']:,} {order['unit_label']}"),
                      ("Add-on level", rq_catalog.ADDON_LEVELS.get(order["priority"], {}).get("name", order["priority"])),
                      ("Attached to", order["attached_to"] or "-"),
                      ("Created", f"{fmt_local(order['created_at'], tz)} / {fmt_utc(order['created_at'])}"),
                      ("Paid", f"{fmt_local(order['paid_at'], tz)} / {fmt_utc(order['paid_at'])}" if order["paid_at"] else "-"),
                      ("Units expire", f"{fmt_local(order['expires_at'], tz)} / {fmt_utc(order['expires_at'])}" if order["expires_at"] else "-"),
                      ("Details", f"{order['details_status']} ({order['details_count']} item(s))"),
                      ("Session", f"#{session['id']} {session['status']} activated {fmt_utc(session['activated_at']) if session and session['activated_at'] else '-'}" if session else "-"),
                      ("Terms", f"v{terms['version']} accepted {fmt_utc(terms['accepted_at'])} from {terms['ip'] or '-'}" if terms else "-"),
                      ("Admin note", order["admin_note"] or "-"), ("Offer description", offer.description if offer else "-")]))
    story.append(Paragraph("User", S_H))
    story.append(_kv(_user_pairs(core, user)))
    story.append(Paragraph("Pricing breakdown", S_H))
    rows = [["Step", "Line", "Change", "Running total"]]
    for i, r in enumerate(quote.rows(), start=1):
        rows.append([str(i), r["label"], r["delta"], r["running"]])
    rows.append(["", P("TOTAL", S_CELL_B), "", P(usd(quote.total), S_CELL_B)])
    story.append(_table(rows, [12 * mm, 98 * mm, 30 * mm, 36 * mm]))
    f = quote.factors or {}
    story.append(Spacer(1, 3))
    story.append(Paragraph("Factors at quote time", S_SMALL))
    story.append(_kv([("Unit price / setup fee", f"{usd(f.get('unit_price', 0)) if f.get('unit_price') is not None else '-'} / {usd(f.get('setup_fee', 0)) if f.get('setup_fee') is not None else '-'}"),
                      ("Volume multiplier", str(f.get("volume_mult", "-"))), ("Add-on multiplier / fee", f"{f.get('addon_mult', '-')} / {usd(f.get('addon_fee', 0)) if f.get('addon_fee') is not None else '-'}"),
                      ("Off-hours / weekend", f"{'yes' if f.get('offhours') else 'no'} ({f.get('offhours_pct', 0)}%) / {'yes' if f.get('weekend') else 'no'} ({f.get('weekend_pct', 0)}%)"),
                      ("Processing / request fee", f"{f.get('processing_pct', '-')}% / {usd(f.get('request_fee', 0)) if f.get('request_fee') is not None else '-'}"),
                      ("Rounding / minimum", f"{usd(f.get('rounding', 0)) if f.get('rounding') else '-'} / {usd(f.get('min_total', 0)) if f.get('min_total') else '-'}"),
                      ("Quoted at (local)", str(f.get("quoted_at_local", "-")))]))
    _purchase_block(core, story, purchase)
    story.append(Paragraph("Request details submitted by user", S_H))
    if details:
        rows = [["#", "When (UTC)", "Kind", "Content / file"]]
        for i, d in enumerate(details, start=1):
            rows.append([str(i), fmt_utc(d["created_at"]), d["kind"], P((d["text"] or "") + (f"\nfile: {d['filename']} (media #{d['media_id']})" if d["media_id"] else ""), S_CELL)])
        story.append(_table(rows, [8 * mm, 30 * mm, 18 * mm, 120 * mm]))
    else:
        story.append(Paragraph("None.", S_BODY))
    story.append(Paragraph("Timeline", S_H))
    rows = [["When (UTC)", "Event", "Actor", "Data"]]
    for e in audit:
        rows.append([fmt_utc(e["ts"]), e["action"], f"{e['actor_role'] or '-'} {e['actor_user_id'] or ''}", P(json.dumps(loads(e["data_json"], {}), default=str)[:400], S_MONO)])
    if len(rows) == 1:
        rows.append(["-", "-", "-", "-"])
    story.append(_table(rows, [30 * mm, 34 * mm, 22 * mm, 90 * mm]))
    story.append(Spacer(1, 8))
    story.append(KeepTogether([Paragraph("Terms applied", S_H),
                               Paragraph("Request only. Nothing is guaranteed, approved, delivered, or replied to. No refunds or returns, ever. 1 month = 28 days. "
                                         f"Paid units expire {core.settings.int('rq_unit_expiry_days')} days after payment if unused. Activation is the only thing a payment grants. "
                                         "A paid request cannot be edited or canceled.", S_SMALL),
                               Paragraph(f"Terms version {esc(cfg.rq_terms_version)}. Record generated by {esc(cfg.site_domain)}.", S_SMALL)]))
    doc.build(story, onFirstPage=_footer(cfg, order["invoice_no"]), onLaterPages=_footer(cfg, order["invoice_no"]))
    return buf.getvalue()


# ------------------------------------------------------------------ receipt
def build_receipt_pdf(core, purchase) -> bytes:
    cfg, db, tz = core.cfg, core.db, core.tz
    user = db.get("users", purchase["user_id"]) if purchase["user_id"] else None
    buf = io.BytesIO()
    doc = _doc(buf, f"Receipt {purchase['public_id']}", cfg)
    story: list = []
    _header(story, cfg, f"Receipt {purchase['public_id']}", f"generated {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} UTC")
    story.append(_kv([("Item", purchase["title"]), ("Description", purchase["description"] or "-"), ("Kind", purchase["kind"]),
                      ("Quantity", str(purchase["quantity"])), ("Unit price", usd(purchase["unit_price_cents"])), ("Discount", usd(purchase["discount_cents"])),
                      ("Credit used", usd(purchase["credit_used_cents"])), ("Total", usd(purchase["total_cents"])), ("Status", purchase["status"]),
                      ("Paid at", f"{fmt_local(purchase['paid_at'], tz)} / {fmt_utc(purchase['paid_at'])}" if purchase["paid_at"] else "-"),
                      ("Customer", f"#{user['id']} {user['email'] or ''}" if user else (purchase["guest_email"] or "guest"))]))
    _purchase_block(core, story, purchase)
    story.append(Spacer(1, 6))
    story.append(Paragraph("All sales are final. No refunds or returns. Cryptocurrency payments are irreversible.", S_SMALL))
    doc.build(story, onFirstPage=_footer(cfg, purchase["public_id"]), onLaterPages=_footer(cfg, purchase["public_id"]))
    return buf.getvalue()


# ------------------------------------------------------------------ certificate of authenticity
def build_coa_pdf(core, serial: str, product_name: str, buyer: str, issued_ts: int, order_id: str) -> bytes:
    cfg = core.cfg
    buf = io.BytesIO()
    doc = _doc(buf, f"Certificate {serial}", cfg)
    story: list = []
    _header(story, cfg, "Certificate of authenticity", f"Serial {serial}")
    story += [Spacer(1, 20), Paragraph(esc(product_name), S_TITLE), Spacer(1, 10),
              Paragraph(f"This certifies that the item above is an authentic {esc(cfg.site_name)} piece, issued to {esc(buyer)} "
                        f"on {fmt_utc(issued_ts)} with order {esc(order_id)}.", S_BODY), Spacer(1, 20),
              Paragraph(f"Serial: {esc(serial)}", S_MONO), Paragraph(f"Verify: {esc(cfg.base_url)}/coa/{esc(serial)}", S_MONO), Spacer(1, 40),
              Paragraph(f"{esc(cfg.site_name)} — {esc(cfg.creator_handle)}", S_BODY)]
    doc.build(story, onFirstPage=_footer(cfg, serial), onLaterPages=_footer(cfg, serial))
    return buf.getvalue()


# ------------------------------------------------------------------ analytics report
def build_report_pdf(core, report: dict, title: str) -> bytes:
    cfg, tz = core.cfg, core.tz
    buf = io.BytesIO()
    doc = _doc(buf, title, cfg)
    story: list = []
    rng = report.get("range", {})
    _header(story, cfg, title, f"Range {fmt_local(rng.get('since'), tz)} to {fmt_local(rng.get('until'), tz)} | generated {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} UTC")
    story.append(Paragraph("Key figures", S_H))
    story.append(_kv([(label, value) for label, value in report.get("kpi_rows", [])]))
    for section in ("by_kind", "by_tier", "by_day", "top_users", "funnel", "content_top", "requests_by_offer"):
        block = report.get(section)
        if not block:
            continue
        story.append(Paragraph(block["title"], S_H))
        rows = [block["columns"]] + [[str(c) for c in r] for r in block["rows"]]
        if len(rows) == 1:
            rows.append(["-"] * len(block["columns"]))
        story.append(_table(rows))
        if section == "by_day":
            story.append(PageBreak())
    story.append(Spacer(1, 6))
    story.append(Paragraph(f"Settings snapshot: {esc(json.dumps(core.settings.snapshot(), default=str)[:1500])}", S_SMALL))
    doc.build(story, onFirstPage=_footer(cfg, title), onLaterPages=_footer(cfg, title))
    return buf.getvalue()
