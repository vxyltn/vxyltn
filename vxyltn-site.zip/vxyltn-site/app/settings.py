"""Runtime settings: admin overrides (DB) layered over Config defaults."""
from __future__ import annotations

import json
from typing import Any

from .config import Config

# key -> (type, min, max, group, description). Types: int, cents, pct, float, bool, str, json
EDITABLE: dict[str, tuple] = {
    # request system
    "rq_activation_cents": ("cents", 1, None, "Request system", "Activation price. The minimum price of the request system (USD 1,000,000 default)."),
    "rq_min_total_cents": ("cents", 1, None, "Request system", "Floor for every request except contributions."),
    "rq_session_hours": ("int", 1, 24 * 365, "Request system", "Hours an activation stays valid."),
    "rq_unit_expiry_days": ("int", 1, 3650, "Request system", "Days until paid, unused units expire."),
    "rq_invoice_ttl_hours": ("int", 1, 24 * 30, "Request system", "Hours before an unpaid request invoice is discarded."),
    "rq_processing_pct": ("pct", 0, 1000, "Request system", "Processing fee percent."),
    "rq_request_fee_cents": ("cents", 0, None, "Request system", "Fixed request fee."),
    "rq_offhours_pct": ("pct", 0, 1000, "Request system", "Off-hours surcharge percent (0 disables)."),
    "rq_offhours_start": ("int", 0, 23, "Request system", "Off-hours start hour (local)."),
    "rq_offhours_end": ("int", 0, 23, "Request system", "Off-hours end hour (local)."),
    "rq_weekend_pct": ("pct", 0, 1000, "Request system", "Weekend surcharge percent (0 disables)."),
    "rq_rounding_cents": ("cents", 1, None, "Request system", "Round request totals up to a multiple of this."),
    "rq_contribution_min_cents": ("cents", 1, None, "Request system", "Technical minimum for a contribution (contributions have no limit)."),
    "rq_contribution_max_cents": ("cents", 1, None, "Request system", "Technical maximum for a contribution (contributions have no limit)."),
    "rq_start_confirm_restart": ("bool", None, None, "Request system", "Ask before an active session is restarted."),
    # payments
    "platform_tx_cap_cents": ("cents", 1, None, "Payments", "Automated cap for platform purchases. Above it: manual contact flow."),
    "platform_min_cents": ("cents", 0, None, "Payments", "Minimum price of every in-app purchase (1,000 default). Contributions are exempt."),
    "max_usd_per_invoice_cents": ("cents", 0, None, "Payments", "Split request payments into parts of at most this (0 = no split)."),
    "np_fee_paid_by_user": ("bool", None, None, "Payments", "Network/service fee paid by the user at NOWPayments."),
    "np_fixed_rate": ("bool", None, None, "Payments", "Fixed-rate crypto invoices."),
    "credit_before_payout": ("bool", None, None, "Payments", "Treat 'confirmed' as paid (before NOWPayments 'finished')."),
    # audience pricing
    "public_mult": ("float", 1.0, 100.0, "Audience pricing", "Public (no account) price multiplier on member prices."),
    "follower_mult": ("float", 1.0, 100.0, "Audience pricing", "Follower (free account) price multiplier on member prices."),
    "preview_pass_cents": ("cents", 0, None, "Audience pricing", "Public preview pass price."),
    "preview_pass_hours": ("int", 1, 720, "Audience pricing", "Preview pass duration."),
    "public_question_cents": ("cents", 0, None, "Audience pricing", "Public question (one message, no reply guaranteed)."),
    "follower_badge_cents": ("cents", 0, None, "Audience pricing", "Follower badge price."),
    "priority_dm_cents": ("cents", 0, None, "Audience pricing", "Priority DM add-on per message."),
    "dm_price_public_cents": ("cents", 0, None, "Audience pricing", "DM price for public/guest questions is public_question_cents; this is the follower DM price."),
    "dm_price_member_cents": ("cents", 0, None, "Audience pricing", "Default DM price for members (tier perks can lower it)."),
    "comment_price_cents": ("cents", 0, None, "Audience pricing", "Default price to unlock commenting on a post (0 = free for members)."),
    "tip_min_cents": ("cents", 0, None, "Audience pricing", "Minimum tip."),
    "tip_min_vip_cents": ("cents", 0, None, "Audience pricing", "Minimum tip for priority-list members."),
    "referral_reward_cents": ("cents", 0, None, "Growth", "Credit granted to the referrer on the referred user's first paid membership."),
    "first_tip_bonus_pct": ("pct", 0, 1000, "Growth", "First-tip incentive: credit back this percent of a user's first tip."),
    "kyc_threshold_cents": ("cents", 0, None, "Compliance", "Cumulative spend that flags a user for KYC."),
    "membership_grace_days": ("int", 0, 60, "Memberships", "Grace period after a period ends before access is removed."),
    "renewal_reminder_days": ("int", 0, 60, "Memberships", "Days before period end to send the renewal reminder."),
    "story_hours": ("int", 1, 168, "Content", "Default lifetime of story-style posts."),
    "max_pins": ("int", 0, 10, "Content", "Maximum pinned posts."),
    "maintenance": ("bool", None, None, "Site", "Maintenance mode: non-admins see a pause page."),
    "signups_open": ("bool", None, None, "Site", "Allow new signups."),
    "age_gate": ("bool", None, None, "Site", "Require date of birth and 18+ confirmation at signup."),
    "require_email_verification": ("bool", None, None, "Site", "Block purchases until the email is verified (only when email is configured)."),
    "geo_block_countries": ("str", None, None, "Compliance", "Comma-separated ISO country codes to block."),
    "crypto_warning": ("bool", None, None, "Payments", "Show the crypto volatility warning at checkout."),
    "screenshot_deterrence": ("bool", None, None, "Security", "Enable client-side screenshot deterrence on media."),
    "watermark_text": ("str", None, None, "Security", "Visible watermark text. Empty = '© year VXYLTN'."),
    "watermark_opacity": ("int", 0, 100, "Security", "Watermark opacity percent."),
    "profile_headline": ("str", None, None, "Profile", "One line under the name on the profile."),
    "profile_bio": ("str", None, None, "Profile", "Profile bio (markdown)."),
    "announcement": ("str", None, None, "Site", "Short announcement shown at the top of every page (empty = none)."),
}

DEFAULTS_NOT_IN_CONFIG: dict[str, Any] = {
    "credit_before_payout": False,
    "dm_price_public_cents": 100_000,
    "dm_price_member_cents": 100_000,
    "comment_price_cents": 0,
    "tip_min_cents": 100_000,
    "tip_min_vip_cents": 250_000,
    "referral_reward_cents": 100_000,
    "first_tip_bonus_pct": 50,
    "membership_grace_days": 3,
    "renewal_reminder_days": 3,
    "story_hours": 24,
    "max_pins": 3,
    "maintenance": False,
    "signups_open": True,
    "age_gate": True,
    "require_email_verification": True,
    "geo_block_countries": "",
    "crypto_warning": True,
    "screenshot_deterrence": True,
    "watermark_text": "",
    "watermark_opacity": 35,
    "profile_headline": "",
    "profile_bio": "",
    "announcement": "",
}


class Settings:
    def __init__(self, cfg: Config, db):
        self.cfg = cfg
        self.db = db
        self._cache: dict[str, Any] | None = None

    def invalidate(self) -> None:
        self._cache = None

    def _overrides(self) -> dict[str, Any]:
        if self._cache is None:
            self._cache = self.db.all_settings()
        return self._cache

    def get(self, key: str) -> Any:
        ov = self._overrides()
        if key in ov:
            return ov[key]
        if key in DEFAULTS_NOT_IN_CONFIG:
            return DEFAULTS_NOT_IN_CONFIG[key]
        return getattr(self.cfg, key)

    def int(self, key: str) -> int:
        return int(self.get(key))

    def bool(self, key: str) -> bool:
        v = self.get(key)
        return v if isinstance(v, bool) else str(v).lower() in {"1", "true", "yes", "on"}

    def set(self, key: str, value: Any, actor: int | None = None) -> Any:
        if key not in EDITABLE:
            raise KeyError(key)
        kind, lo, hi, _g, _d = EDITABLE[key]
        if kind in ("int", "cents", "pct"):
            value = int(value)
        elif kind == "float":
            value = float(value)
        elif kind == "bool":
            value = value if isinstance(value, bool) else str(value).lower() in {"1", "true", "yes", "on"}
        elif kind == "json":
            value = json.loads(value) if isinstance(value, str) else value
        else:
            value = str(value)
        if kind in ("int", "cents", "pct", "float"):
            if lo is not None and value < lo:
                raise ValueError(f"{key} must be at least {lo}")
            if hi is not None and value > hi:
                raise ValueError(f"{key} must be at most {hi}")
        self.db.set_setting(key, value, actor)
        self.db.audit("settings.set", actor_user_id=actor, actor_role="admin", entity_type="setting", entity_id=key, data={"value": value})
        self.invalidate()
        return value

    def reset(self, key: str, actor: int | None = None) -> None:
        self.db.delete_setting(key)
        self.db.audit("settings.reset", actor_user_id=actor, actor_role="admin", entity_type="setting", entity_id=key)
        self.invalidate()

    def grouped(self) -> dict[str, list[dict]]:
        out: dict[str, list[dict]] = {}
        ov = self._overrides()
        for key, (kind, lo, hi, group, desc) in EDITABLE.items():
            out.setdefault(group, []).append({"key": key, "kind": kind, "min": lo, "max": hi, "desc": desc,
                                              "value": self.get(key), "overridden": key in ov})
        return out

    def snapshot(self) -> dict[str, Any]:
        return {k: self.get(k) for k in EDITABLE}

    def geo_blocked(self) -> set[str]:
        raw = str(self.get("geo_block_countries") or "")
        codes = {c.strip().upper() for c in raw.replace(";", ",").split(",") if c.strip()}
        return codes | set(self.cfg.allowed_countries_block)

    def paid_statuses(self) -> set[str]:
        s = set(self.cfg.paid_statuses)
        if self.bool("credit_before_payout"):
            s.add("confirmed")
        return s
