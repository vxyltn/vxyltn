"""Email adapter: SMTP when configured, otherwise logged (and surfaced to the admin outbox table).

All sends are queued to a thread so the request never blocks on SMTP.
"""
from __future__ import annotations

import asyncio
import logging
import smtplib
import ssl
from email.message import EmailMessage

from .config import Config

log = logging.getLogger(__name__)


class Emailer:
    def __init__(self, cfg: Config, db):
        self.cfg = cfg
        self.db = db

    @property
    def enabled(self) -> bool:
        return self.cfg.email_enabled

    def _send_sync(self, to: str, subject: str, text: str, html: str | None = None) -> bool:
        msg = EmailMessage()
        msg["From"] = self.cfg.smtp_from
        msg["To"] = to
        msg["Subject"] = subject
        msg.set_content(text)
        if html:
            msg.add_alternative(html, subtype="html")
        try:
            if self.cfg.smtp_tls and self.cfg.smtp_port == 465:
                server = smtplib.SMTP_SSL(self.cfg.smtp_host, self.cfg.smtp_port, timeout=20, context=ssl.create_default_context())
            else:
                server = smtplib.SMTP(self.cfg.smtp_host, self.cfg.smtp_port, timeout=20)
                if self.cfg.smtp_tls:
                    server.starttls(context=ssl.create_default_context())
            with server:
                if self.cfg.smtp_user:
                    server.login(self.cfg.smtp_user, self.cfg.smtp_password)
                server.send_message(msg)
            return True
        except Exception as exc:  # pragma: no cover - network
            log.warning("email send failed to %s: %s", to, exc)
            return False

    async def send(self, to: str, subject: str, text: str, html: str | None = None) -> bool:
        subject = f"[{self.cfg.site_name}] {subject}"
        self.db.audit("email.queued", entity_type="email", entity_id=to, data={"subject": subject, "enabled": self.enabled})
        if not self.enabled:
            log.info("EMAIL (not configured) to=%s subject=%s\n%s", to, subject, text)
            return False
        return await asyncio.to_thread(self._send_sync, to, subject, text, html)

    # ------------------------------------------------------------ templates
    def _footer(self) -> str:
        return f"\n\n{self.cfg.site_name} — {self.cfg.base_url}\nAll payments are final. No refunds or returns."

    async def verify_email(self, to: str, link: str, code: str | None) -> bool:
        body = f"Confirm your email.\n\nOpen this link: {link}\n"
        if code:
            body += f"\nOr enter this code: {code}\n"
        body += "\nThe link and code expire in 24 hours." + self._footer()
        return await self.send(to, "Confirm your email", body)

    async def magic_link(self, to: str, link: str, code: str | None) -> bool:
        body = f"Sign in with this link: {link}\n"
        if code:
            body += f"\nOr enter this code: {code}\n"
        body += "\nExpires in 15 minutes. If you did not request it, ignore this email." + self._footer()
        return await self.send(to, "Your sign-in link", body)

    async def reset_password(self, to: str, link: str) -> bool:
        return await self.send(to, "Reset your password", f"Reset your password: {link}\n\nExpires in 1 hour." + self._footer())

    async def receipt(self, to: str, title: str, total: str, public_id: str, url: str) -> bool:
        return await self.send(to, f"Payment received {public_id}",
                               f"Payment received.\n\n{title}\nTotal: {total}\nReference: {public_id}\n\n{url}" + self._footer())

    async def generic(self, to: str, subject: str, body: str) -> bool:
        return await self.send(to, subject, body + self._footer())
