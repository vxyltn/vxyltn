"""Web helpers: template rendering, flashes, auth guards, forms, viewer middleware, security headers."""
from __future__ import annotations

import json
import logging
import os
from functools import wraps
from urllib.parse import quote, urlencode

from starlette.datastructures import UploadFile
from starlette.exceptions import HTTPException
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from starlette.templating import Jinja2Templates

from . import auth
from .access import Viewer, resolve_viewer
from .money import usd
from .util import client_ip, country_of, dt_input_value, esc, fmt_local, fmt_utc, now_ts

log = logging.getLogger(__name__)
TEMPLATES_DIR = os.path.join(os.path.dirname(__file__), "templates")
FLASH_COOKIE = "vx_flash"
CSRF_EXEMPT_PREFIXES = ("/api/nowpayments/ipn", "/api/kyc/webhook", "/health")

import jinja2

_env = jinja2.Environment(loader=jinja2.FileSystemLoader(TEMPLATES_DIR), autoescape=True, trim_blocks=False, lstrip_blocks=False)
templates = Jinja2Templates(env=_env)


def _rel_time(ts, tz):
    if not ts:
        return "-"
    delta = now_ts() - int(ts)
    if delta < 60:
        return "just now"
    if delta < 3600:
        return f"{delta // 60}m ago"
    if delta < 86400:
        return f"{delta // 3600}h ago"
    if delta < 7 * 86400:
        return f"{delta // 86400}d ago"
    return fmt_local(ts, tz, with_tz=False, fmt="%Y-%m-%d")


def setup_templates(core) -> None:
    env = templates.env
    env.filters["usd"] = usd
    env.filters["local"] = lambda ts, with_tz=True: fmt_local(ts, core.tz, with_tz)
    env.filters["date"] = lambda ts: fmt_local(ts, core.tz, False, "%Y-%m-%d")
    env.filters["utc"] = fmt_utc
    env.filters["rel"] = lambda ts: _rel_time(ts, core.tz)
    env.filters["dtinput"] = lambda ts: dt_input_value(ts, core.tz)
    env.filters["json"] = lambda v: json.dumps(v, default=str)
    env.filters["loads"] = lambda v, d=None: (json.loads(v) if v else (d if d is not None else {}))
    env.filters["nl2br"] = lambda s: esc(s).replace("\n", "<br>")
    env.filters["k"] = lambda n: f"{int(n):,}"
    env.globals["cfg"] = core.cfg
    env.globals["site_name"] = core.cfg.site_name
    env.globals["now_ts"] = now_ts


class AppState:
    """Per-request state attached to request.state."""


def flashes_from(request: Request) -> list[dict]:
    raw = request.cookies.get(FLASH_COOKIE)
    if not raw:
        return []
    value = auth.unsign(request.app.state.core.cfg.secret_key, raw)
    if not value:
        return []
    try:
        return json.loads(value)
    except ValueError:
        return []


def flash(response: Response, request: Request, text: str, kind: str = "info") -> Response:
    core = request.app.state.core
    existing = []
    try:
        existing = getattr(request.state, "pending_flashes", []) or []
    except AttributeError:
        pass
    existing.append({"text": text, "kind": kind})
    request.state.pending_flashes = existing
    response.set_cookie(FLASH_COOKIE, auth.sign(core.cfg.secret_key, json.dumps(existing)), max_age=120, httponly=True,
                        samesite="lax", secure=core.cfg.cookie_secure, path="/")
    return response


def redirect(url: str, request: Request | None = None, message: str | None = None, kind: str = "info", status_code: int = 303) -> Response:
    resp = RedirectResponse(url, status_code=status_code)
    if request is not None and message:
        flash(resp, request, message, kind)
    return resp


def render(request: Request, name: str, status_code: int = 200, **ctx) -> Response:
    core = request.app.state.core
    viewer: Viewer = getattr(request.state, "viewer", Viewer())
    base = {
        "request": request, "viewer": viewer, "user": viewer.user, "csrf": getattr(request.state, "csrf", ""),
        "flashes": flashes_from(request), "settings": core.settings, "announcement": core.settings.get("announcement"),
        "unread": core.db.count("notifications", "user_id=? AND read_at IS NULL", (viewer.user_id,)) if viewer.user_id else 0,
        "unread_dm": core.db.count("messages", "thread_user_id=? AND sender_role='creator' AND read_at IS NULL AND deleted_at IS NULL", (viewer.user_id,)) if viewer.user_id else 0,
        "path": request.url.path,
    }
    base.update(ctx)
    resp = templates.TemplateResponse(request, name, base, status_code=status_code)
    if request.cookies.get(FLASH_COOKIE):
        resp.delete_cookie(FLASH_COOKIE, path="/")
    return resp


def json_error(message: str, status: int = 400) -> JSONResponse:
    return JSONResponse({"ok": False, "error": message}, status_code=status)


# ------------------------------------------------------------------ guards
def login_required(fn):
    @wraps(fn)
    async def wrapper(request: Request, *a, **kw):
        viewer: Viewer = request.state.viewer
        if viewer.user is None:
            nxt = quote(str(request.url.path) + (f"?{request.url.query}" if request.url.query else ""))
            return redirect(f"/login?next={nxt}", request, "Log in to continue.")
        return await fn(request, *a, **kw)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    async def wrapper(request: Request, *a, **kw):
        viewer: Viewer = request.state.viewer
        core = request.app.state.core
        if viewer.user is None:
            return redirect("/login?next=" + quote(str(request.url.path)), request, "Log in to continue.")
        if not viewer.is_admin:
            raise HTTPException(404)
        if core.cfg.admin_require_2fa and not viewer.twofa_ok:
            if viewer.user["totp_enabled_at"]:
                return redirect("/2fa?next=" + quote(str(request.url.path)), request, "Confirm your second factor.")
            return redirect("/account/security?setup2fa=1", request, "Admin accounts require two-factor authentication. Set it up to continue.")
        return await fn(request, *a, **kw)
    return wrapper


# ------------------------------------------------------------------ forms
async def form_data(request: Request) -> dict:
    """Parse a form (urlencoded or multipart) into a plain dict; repeated keys -> list; UploadFiles kept.

    The CSRF middleware may already have parsed the body; it stashes the FormData in the ASGI scope
    because the downstream Request cannot re-read a consumed stream.
    """
    form = request.scope.get("vx_form")
    if form is None:
        form = await request.form()
        request.scope["vx_form"] = form
    out: dict = {}
    for key in form.keys():
        values = form.getlist(key)
        values = [v for v in values if not (isinstance(v, UploadFile) and not v.filename)]
        if not values:
            continue
        out[key] = values if len(values) > 1 or key.endswith("[]") else values[0]
        if key.endswith("[]"):
            out[key[:-2]] = values
    return out


def fval(form: dict, key: str, default: str = "") -> str:
    v = form.get(key, default)
    if isinstance(v, list):
        v = v[0] if v else default
    return v.strip() if isinstance(v, str) else (default if v is None else v)


def fint(form: dict, key: str, default: int | None = None) -> int | None:
    from .util import parse_int
    v = parse_int(fval(form, key, ""))
    return default if v is None else v


def fcents(form: dict, key: str, default: int | None = None) -> int | None:
    from .util import parse_money_cents
    v = parse_money_cents(fval(form, key, ""))
    return default if v is None else v


def fbool(form: dict, key: str) -> bool:
    v = fval(form, key, "")
    return str(v).lower() in {"1", "true", "on", "yes"}


def files_of(form: dict, key: str) -> list[UploadFile]:
    v = form.get(key) or form.get(key + "[]") or []
    if isinstance(v, UploadFile):
        return [v] if v.filename else []
    return [f for f in v if isinstance(f, UploadFile) and f.filename]


def page_args(request: Request, default_size: int = 25) -> tuple[int, int, int]:
    try:
        page = max(1, int(request.query_params.get("page", "1")))
    except ValueError:
        page = 1
    size = default_size
    return page, size, (page - 1) * size


def qs(params: dict) -> str:
    return urlencode({k: v for k, v in params.items() if v not in (None, "")})


# ------------------------------------------------------------------ middleware
class ViewerMiddleware(BaseHTTPMiddleware):
    """Resolve session -> viewer; CSRF for unsafe methods; maintenance/geo/block gates; security headers."""

    async def dispatch(self, request: Request, call_next):
        core = request.app.state.core
        db, cfg, settings = core.db, core.cfg, core.settings
        path = request.url.path
        raw = request.cookies.get(auth.SESSION_COOKIE)
        session = auth.load_session(db, raw)
        user = db.get("users", session["user_id"]) if session else None
        if user is not None and user["deleted_at"]:
            user = None
        viewer = resolve_viewer(db, settings, user, raw if session else None, twofa_ok=bool(session and session["twofa_ok"]))
        request.state.viewer = viewer
        request.state.session_raw = raw if session else None
        request.state.session_row = session
        request.state.csrf = auth.csrf_token(cfg.secret_key, raw if session else None)
        request.state.ip = client_ip(request, cfg.trusted_proxy)
        request.state.country = country_of(request)

        if session is not None and (session["last_seen_at"] or 0) < now_ts() - 300:
            db.execute("UPDATE sessions SET last_seen_at=? WHERE id=?", (now_ts(), session["id"]))
            db.execute("UPDATE users SET last_seen_at=?, last_ip=?, country=COALESCE(?, country) WHERE id=?",
                       (now_ts(), request.state.ip, request.state.country, session["user_id"]))

        if not path.startswith(("/static/", "/health")):
            if user is not None and user["blocked"] and not viewer.is_admin:
                return HTMLResponse("<p style='font-family:sans-serif;padding:2rem'>Access denied.</p>", status_code=403)
            if request.state.country and request.state.country in settings.geo_blocked() and not viewer.is_admin:
                return HTMLResponse("<p style='font-family:sans-serif;padding:2rem'>Not available in your region.</p>", status_code=451)
            if settings.bool("maintenance") and not viewer.is_admin and not path.startswith(("/login", "/2fa", "/api/nowpayments")):
                return HTMLResponse("<p style='font-family:sans-serif;padding:2rem;background:#000;color:#e8e4dc'>Paused. Back soon.</p>", status_code=503)
            if request.method in ("POST", "PUT", "PATCH", "DELETE") and not path.startswith(CSRF_EXEMPT_PREFIXES):
                if db.hit_rate_limit(f"post:{request.state.ip}", cfg.rate_limit_per_minute):
                    return HTMLResponse("Too many requests.", status_code=429)
                token = request.headers.get("x-csrf")
                if token is None:
                    ctype = request.headers.get("content-type", "")
                    if ctype.startswith(("application/x-www-form-urlencoded", "multipart/form-data")):
                        form = await request.form()
                        request.scope["vx_form"] = form
                        token = form.get("_csrf")
                if not auth.csrf_ok(cfg.secret_key, raw if session else None, token):
                    return HTMLResponse("Invalid or expired form. Go back and try again.", status_code=403)
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(self), geolocation=()")
        if not path.startswith("/admin"):
            response.headers.setdefault("Content-Security-Policy",
                                        "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob: https:; frame-src https:; "
                                        "script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; form-action 'self' https://nowpayments.io https://*.nowpayments.io")
        if cfg.cookie_secure:
            response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        return response


def set_session_cookie(response: Response, request: Request, raw: str) -> None:
    cfg = request.app.state.core.cfg
    response.set_cookie(auth.SESSION_COOKIE, raw, max_age=cfg.session_days * 86400, httponly=True, samesite="lax",
                        secure=cfg.cookie_secure, path="/")


def clear_session_cookie(response: Response) -> None:
    response.delete_cookie(auth.SESSION_COOKIE, path="/")
