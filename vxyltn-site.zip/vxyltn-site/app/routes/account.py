"""Accounts: signup, login, logout, email verification, magic link / OTP, password reset, 2FA, profile, security, data rights, notifications, referrals."""
from __future__ import annotations

import json
from urllib.parse import quote

from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from .. import auth
from ..access import active_membership
from ..money import usd
from ..util import now_ts, slugify, token_urlsafe, valid_email
from ..web import (clear_session_cookie, fbool, files_of, form_data, fval, login_required, redirect, render,
                   set_session_cookie)

SAFE_NEXT = ("/",)


def _next(request: Request, default: str = "/account") -> str:
    nxt = request.query_params.get("next") or default
    return nxt if nxt.startswith("/") and not nxt.startswith("//") else default


def _login(request: Request, user, response: Response, twofa_ok: bool) -> Response:
    core = request.app.state.core
    raw = auth.create_session(core.db, user["id"], core.cfg.session_days, request.state.ip, request.headers.get("user-agent", ""), twofa_ok)
    set_session_cookie(response, request, raw)
    core.db.execute("UPDATE users SET last_seen_at=?, last_ip=? WHERE id=?", (now_ts(), request.state.ip, user["id"]))
    core.db.audit("auth.login", actor_user_id=user["id"], actor_role=user["role"], entity_type="user", entity_id=user["id"], ip=request.state.ip)
    return response


# ------------------------------------------------------------------ signup
async def signup(request: Request):
    core = request.app.state.core
    db, s = core.db, core.settings
    if request.state.viewer.user:
        return redirect("/account")
    if not s.bool("signups_open"):
        return render(request, "account/signup.html", closed=True, form={})
    ref = request.query_params.get("ref", "")
    if request.method == "GET":
        return render(request, "account/signup.html", form={"ref": ref}, age_gate=s.bool("age_gate"))
    f = await form_data(request)
    email = fval(f, "email").lower()
    pw = fval(f, "password")
    err = None
    if not valid_email(email):
        err = "enter a valid email."
    elif db.one("SELECT 1 FROM users WHERE lower(email)=?", (email,)):
        err = "an account with this email exists. log in instead."
    else:
        err = auth.password_problems(pw)
    if not err and s.bool("age_gate"):
        dob = fval(f, "dob")
        if not fbool(f, "adult") or not dob:
            err = "confirm you are 18 or older and enter your date of birth."
        else:
            try:
                from datetime import date
                y, m, d = (int(x) for x in dob.split("-"))
                born = date(y, m, d)
                today = date.today()
                age = today.year - born.year - ((today.month, today.day) < (born.month, born.day))
                if age < 18:
                    err = "you must be 18 or older."
            except (ValueError, TypeError):
                err = "enter the date of birth as yyyy-mm-dd."
    if not fbool(f, "terms"):
        err = err or "accept the terms."
    if err:
        return render(request, "account/signup.html", error=err, form=f, age_gate=s.bool("age_gate"))
    ts = now_ts()
    referred_by = None
    if fval(f, "ref"):
        r = db.one("SELECT id FROM users WHERE referral_code=?", (fval(f, "ref"),))
        referred_by = r["id"] if r else None
    uid = db.insert("users", email=email, password_hash=auth.hash_password(pw), display_name=fval(f, "display_name")[:60] or None,
                    dob=fval(f, "dob") or None, age_confirmed_at=ts if s.bool("age_gate") else None, role="user",
                    is_follower=1, followed_at=ts, referral_code=token_urlsafe(6), referred_by=referred_by, country=request.state.country,
                    timezone=fval(f, "timezone")[:60] or None, marketing_opt_in=1 if fbool(f, "marketing") else 0, created_at=ts,
                    last_seen_at=ts, last_ip=request.state.ip,
                    email_verified_at=None if core.emailer.enabled else ts)
    if referred_by:
        db.insert("referrals", referrer_id=referred_by, referred_id=uid, created_at=ts)
    db.audit("auth.signup", actor_user_id=uid, actor_role="user", entity_type="user", entity_id=uid, ip=request.state.ip, data={"referred_by": referred_by})
    user = db.get("users", uid)
    resp = redirect(_next(request, "/account"), request, "account created. you are following as a free follower." if not core.emailer.enabled else "account created. check your email to confirm it.", "ok")
    if core.emailer.enabled:
        await _send_verification(request, user)
    return _login(request, user, resp, twofa_ok=True)


async def _send_verification(request: Request, user) -> None:
    core = request.app.state.core
    raw, code = auth.issue_token(core.db, "verify", user["id"], user["email"], 24 * 3600, with_code=True)
    await core.emailer.verify_email(user["email"], core.url(f"/verify?token={raw}"), code)


async def verify(request: Request):
    core = request.app.state.core
    db = core.db
    viewer = request.state.viewer
    if request.method == "POST":
        f = await form_data(request)
        if fval(f, "resend") and viewer.user:
            await _send_verification(request, viewer.user)
            return redirect("/verify", request, "sent again.", "ok")
        row = auth.consume_token(db, "verify", code=fval(f, "code"), user_id=viewer.user_id)
    else:
        row = auth.consume_token(db, "verify", raw=request.query_params.get("token"))
        if row is None and not request.query_params.get("token"):
            return render(request, "account/verify.html")
    if row is None:
        return render(request, "account/verify.html", error="invalid or expired code.")
    db.update("users", row["user_id"], email_verified_at=now_ts())
    db.audit("auth.email_verified", actor_user_id=row["user_id"], actor_role="user", entity_type="user", entity_id=row["user_id"])
    return redirect("/account", request, "email confirmed.", "ok")


# ------------------------------------------------------------------ login / logout
async def login(request: Request):
    core = request.app.state.core
    db = core.db
    if request.state.viewer.user and request.method == "GET":
        return redirect(_next(request))
    if request.method == "GET":
        return render(request, "account/login.html", form={}, next=_next(request), email_enabled=core.emailer.enabled)
    f = await form_data(request)
    email = fval(f, "email").lower()
    if db.hit_rate_limit(f"login:{request.state.ip}", 15) or db.hit_rate_limit(f"login:{email}", 10):
        return render(request, "account/login.html", error="too many attempts. wait a minute.", form=f, next=_next(request), email_enabled=core.emailer.enabled)
    if fval(f, "mode") == "magic":
        user = db.one("SELECT * FROM users WHERE lower(email)=? AND deleted_at IS NULL", (email,))
        if user and core.emailer.enabled:
            raw, code = auth.issue_token(db, "magic", user["id"], email, 15 * 60, with_code=True)
            await core.emailer.magic_link(email, core.url(f"/magic?token={raw}"), code)
        return redirect(f"/magic?email={quote(email)}", request, "if the account exists, a sign-in link and code were sent.", "ok")
    user = db.one("SELECT * FROM users WHERE lower(email)=? AND deleted_at IS NULL", (email,))
    if user is None or not auth.verify_password(fval(f, "password"), user["password_hash"]):
        db.audit("auth.login_failed", entity_type="user", entity_id=email, ip=request.state.ip)
        return render(request, "account/login.html", error="wrong email or password.", form=f, next=_next(request), email_enabled=core.emailer.enabled)
    if user["totp_enabled_at"]:
        resp = redirect("/2fa?next=" + quote(_next(request)))
        return _login(request, user, resp, twofa_ok=False)
    return _login(request, user, redirect(_next(request)), twofa_ok=True)


async def magic(request: Request):
    core = request.app.state.core
    db = core.db
    if request.method == "POST":
        f = await form_data(request)
        row = auth.consume_token(db, "magic", code=fval(f, "code"), email=fval(f, "email").lower())
    else:
        token = request.query_params.get("token")
        if not token:
            return render(request, "account/magic.html", email=request.query_params.get("email", ""))
        row = auth.consume_token(db, "magic", raw=token)
    if row is None:
        return render(request, "account/magic.html", error="invalid or expired link/code.", email=request.query_params.get("email", ""))
    user = db.get("users", row["user_id"])
    if user is None:
        return redirect("/login")
    if not user["email_verified_at"]:
        db.update("users", user["id"], email_verified_at=now_ts())
    if user["totp_enabled_at"]:
        return _login(request, user, redirect("/2fa?next=/account"), twofa_ok=False)
    return _login(request, user, redirect("/account", request, "signed in.", "ok"), twofa_ok=True)


async def logout(request: Request):
    core = request.app.state.core
    auth.revoke_session(core.db, request.state.session_raw)
    resp = redirect("/", request, "logged out.")
    clear_session_cookie(resp)
    return resp


async def forgot(request: Request):
    core = request.app.state.core
    db = core.db
    if request.method == "GET":
        return render(request, "account/forgot.html", email_enabled=core.emailer.enabled)
    f = await form_data(request)
    email = fval(f, "email").lower()
    user = db.one("SELECT * FROM users WHERE lower(email)=? AND deleted_at IS NULL", (email,))
    if user and core.emailer.enabled:
        raw, _ = auth.issue_token(db, "reset", user["id"], email, 3600)
        await core.emailer.reset_password(email, core.url(f"/reset?token={raw}"))
    return redirect("/login", request, "if the account exists, a reset link was sent.", "ok")


async def reset(request: Request):
    core = request.app.state.core
    db = core.db
    token = request.query_params.get("token", "")
    if request.method == "GET":
        return render(request, "account/reset.html", token=token)
    f = await form_data(request)
    err = auth.password_problems(fval(f, "password"))
    if err:
        return render(request, "account/reset.html", token=fval(f, "token"), error=err)
    row = auth.consume_token(db, "reset", raw=fval(f, "token"))
    if row is None:
        return render(request, "account/reset.html", token="", error="invalid or expired link.")
    db.update("users", row["user_id"], password_hash=auth.hash_password(fval(f, "password")))
    auth.revoke_all_sessions(db, row["user_id"])
    db.audit("auth.password_reset", actor_user_id=row["user_id"], actor_role="user", entity_type="user", entity_id=row["user_id"])
    return redirect("/login", request, "password changed. log in.", "ok")


# ------------------------------------------------------------------ 2FA
async def twofa(request: Request):
    core = request.app.state.core
    db = core.db
    viewer = request.state.viewer
    if viewer.user is None:
        return redirect("/login")
    if request.method == "GET":
        return render(request, "account/twofa.html", next=_next(request))
    f = await form_data(request)
    code = fval(f, "code")
    user = viewer.user
    ok = auth.totp_verify(user["totp_secret"], code)
    if not ok and user["recovery_codes_json"]:
        remaining = auth.use_recovery_code(json.loads(user["recovery_codes_json"]), code)
        if remaining is not None:
            db.update("users", user["id"], recovery_codes_json=json.dumps(remaining))
            ok = True
    if not ok:
        db.audit("auth.2fa_failed", actor_user_id=user["id"], entity_type="user", entity_id=user["id"], ip=request.state.ip)
        return render(request, "account/twofa.html", next=_next(request), error="wrong code.")
    sess = request.state.session_row
    if sess:
        db.execute("UPDATE sessions SET twofa_ok=1 WHERE id=?", (sess["id"],))
    return redirect(_next(request))


# ------------------------------------------------------------------ account pages
@login_required
async def account(request: Request):
    core = request.app.state.core
    db = core.db
    viewer = request.state.viewer
    user = viewer.user
    m, tier = active_membership(db, user["id"], core.settings.int("membership_grace_days"))
    purchases = core.payments.user_purchases(user["id"], 20)
    pending = core.payments.pending_for_user(user["id"])
    notifications = db.all("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 30", (user["id"],))
    db.execute("UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL", (now_ts(), user["id"]))
    referrals = db.count("referrals", "referrer_id=?", (user["id"],))
    return render(request, "account/account.html", membership=m, tier=tier, purchases=purchases, pending=pending, notifications=notifications,
                  referrals=referrals, ref_link=core.url(f"/signup?ref={user['referral_code']}"), wallet=usd(user["wallet_cents"]))


@login_required
async def profile(request: Request):
    core = request.app.state.core
    db = core.db
    user = request.state.viewer.user
    if request.method == "POST":
        f = await form_data(request)
        username = slugify(fval(f, "username"))[:30] if fval(f, "username") else None
        if username and db.one("SELECT 1 FROM users WHERE username=? AND id<>?", (username, user["id"])):
            return render(request, "account/profile.html", error="username taken.")
        fields = dict(username=username, display_name=fval(f, "display_name")[:60] or None, bio=fval(f, "bio")[:2000] or None,
                      timezone=fval(f, "timezone")[:60] or None, marketing_opt_in=1 if fbool(f, "marketing") else 0,
                      custom_fields_json=json.dumps({"birthday": fval(f, "birthday")[:40], "about": fval(f, "about")[:500]}),
                      notif_prefs_json=json.dumps({"email_digest": fbool(f, "email_digest"), "live": fbool(f, "notif_live"), "drops": fbool(f, "notif_drops")}))
        avatars = files_of(f, "avatar")
        if avatars:
            try:
                fields["avatar_media_id"] = await core.media.save_upload(avatars[0], user["id"], folder="avatars", max_bytes=10 * 1024 * 1024)
            except ValueError as exc:
                return render(request, "account/profile.html", error=str(exc))
        db.update("users", user["id"], **fields)
        db.audit("user.profile_updated", actor_user_id=user["id"], actor_role="user", entity_type="user", entity_id=user["id"])
        return redirect("/account/profile", request, "saved.", "ok")
    return render(request, "account/profile.html", custom=json.loads(user["custom_fields_json"] or "{}"), prefs=json.loads(user["notif_prefs_json"] or "{}"))


@login_required
async def security(request: Request):
    core = request.app.state.core
    db = core.db
    user = request.state.viewer.user
    sessions = db.all("SELECT * FROM sessions WHERE user_id=? AND revoked_at IS NULL AND expires_at>? ORDER BY last_seen_at DESC", (user["id"], now_ts()))
    ctx = {"sessions": sessions, "current": auth.sha256(request.state.session_raw) if request.state.session_raw else None}
    if request.method == "POST":
        f = await form_data(request)
        action = fval(f, "action")
        if action == "password":
            if not auth.verify_password(fval(f, "current"), user["password_hash"]):
                return render(request, "account/security.html", error="current password is wrong.", **ctx)
            err = auth.password_problems(fval(f, "password"))
            if err:
                return render(request, "account/security.html", error=err, **ctx)
            db.update("users", user["id"], password_hash=auth.hash_password(fval(f, "password")))
            auth.revoke_all_sessions(db, user["id"], except_raw=request.state.session_raw)
            db.audit("user.password_changed", actor_user_id=user["id"], actor_role="user", entity_type="user", entity_id=user["id"])
            return redirect("/account/security", request, "password changed. other sessions were signed out.", "ok")
        if action == "2fa_start":
            secret = auth.totp_new_secret()
            db.update("users", user["id"], totp_secret=secret)
            return render(request, "account/security.html", setup_secret=secret, setup_uri=auth.totp_uri(secret, user["email"], core.cfg.site_name), **ctx)
        if action == "2fa_confirm":
            fresh = db.get("users", user["id"])
            if not auth.totp_verify(fresh["totp_secret"], fval(f, "code")):
                return render(request, "account/security.html", error="code did not match. try again.", setup_secret=fresh["totp_secret"],
                              setup_uri=auth.totp_uri(fresh["totp_secret"], user["email"], core.cfg.site_name), **ctx)
            codes = auth.recovery_codes()
            db.update("users", user["id"], totp_enabled_at=now_ts(), recovery_codes_json=json.dumps(auth.hash_codes(codes)))
            sess = request.state.session_row
            if sess:
                db.execute("UPDATE sessions SET twofa_ok=1 WHERE id=?", (sess["id"],))
            db.audit("user.2fa_enabled", actor_user_id=user["id"], actor_role="user", entity_type="user", entity_id=user["id"])
            return render(request, "account/security.html", recovery=codes, **ctx)
        if action == "2fa_disable":
            if user["role"] == "admin" and core.cfg.admin_require_2fa:
                return render(request, "account/security.html", error="admin accounts must keep 2fa on.", **ctx)
            if not auth.totp_verify(user["totp_secret"], fval(f, "code")):
                return render(request, "account/security.html", error="code did not match.", **ctx)
            db.update("users", user["id"], totp_enabled_at=None, totp_secret=None, recovery_codes_json=None)
            db.audit("user.2fa_disabled", actor_user_id=user["id"], actor_role="user", entity_type="user", entity_id=user["id"])
            return redirect("/account/security", request, "2fa disabled.", "ok")
        if action == "revoke":
            db.execute("UPDATE sessions SET revoked_at=? WHERE id=? AND user_id=?", (now_ts(), fval(f, "session_id"), user["id"]))
            return redirect("/account/security", request, "session revoked.", "ok")
        if action == "revoke_all":
            auth.revoke_all_sessions(db, user["id"], except_raw=request.state.session_raw)
            return redirect("/account/security", request, "other sessions signed out.", "ok")
    return render(request, "account/security.html", **ctx)


@login_required
async def data_rights(request: Request):
    core = request.app.state.core
    db = core.db
    user = request.state.viewer.user
    if request.method == "POST":
        f = await form_data(request)
        if fval(f, "action") == "export":
            data = {
                "user": {k: user[k] for k in user.keys() if k not in ("password_hash", "totp_secret", "recovery_codes_json")},
                "purchases": [dict(r) for r in db.all("SELECT * FROM purchases WHERE user_id=?", (user["id"],))],
                "memberships": [dict(r) for r in db.all("SELECT * FROM memberships WHERE user_id=?", (user["id"],))],
                "messages": [dict(r) for r in db.all("SELECT * FROM messages WHERE thread_user_id=?", (user["id"],))],
                "tips": [dict(r) for r in db.all("SELECT * FROM tips WHERE user_id=?", (user["id"],))],
                "requests": [dict(r) for r in db.all("SELECT * FROM rq_orders WHERE user_id=?", (user["id"],))],
                "custom_orders": [dict(r) for r in db.all("SELECT * FROM custom_orders WHERE user_id=?", (user["id"],))],
                "bookings": [dict(r) for r in db.all("SELECT * FROM call_bookings WHERE user_id=?", (user["id"],))],
                "notifications": [dict(r) for r in db.all("SELECT * FROM notifications WHERE user_id=?", (user["id"],))],
            }
            db.audit("user.data_export", actor_user_id=user["id"], actor_role="user", entity_type="user", entity_id=user["id"])
            return Response(json.dumps(data, default=str, indent=1), media_type="application/json",
                            headers={"Content-Disposition": f'attachment; filename="vxyltn-data-{user["id"]}.json"'})
        if fval(f, "action") == "delete":
            if not auth.verify_password(fval(f, "password"), user["password_hash"]):
                return render(request, "account/data.html", error="password is wrong.")
            ts = now_ts()
            db.update("users", user["id"], email=f"deleted-{user['id']}@deleted.invalid", password_hash=None, username=None, display_name=None,
                      bio=None, phone=None, avatar_media_id=None, banner_media_id=None, custom_fields_json=None, totp_secret=None,
                      totp_enabled_at=None, recovery_codes_json=None, deleted_at=ts, oauth_google_sub=None, oauth_apple_sub=None)
            db.execute("UPDATE messages SET deleted_at=? WHERE thread_user_id=? AND sender_role='user'", (ts, user["id"]))
            auth.revoke_all_sessions(db, user["id"])
            db.audit("user.deleted", actor_user_id=user["id"], actor_role="user", entity_type="user", entity_id=user["id"])
            resp = redirect("/", request, "account deleted. payment and audit records are retained as required.", "ok")
            clear_session_cookie(resp)
            return resp
    return render(request, "account/data.html")


@login_required
async def notifications_api(request: Request):
    core = request.app.state.core
    rows = core.db.all("SELECT id, kind, title, body, url, read_at, created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50", (request.state.viewer.user_id,))
    return JSONResponse([dict(r) for r in rows])


@login_required
async def follow(request: Request):
    core = request.app.state.core
    user = request.state.viewer.user
    f = await form_data(request)
    on = fval(f, "action") != "unfollow"
    core.db.update("users", user["id"], is_follower=1 if on else 0, followed_at=now_ts() if on else user["followed_at"])
    return redirect(fval(f, "next") or "/feed", request, "following." if on else "unfollowed.", "ok")


routes = [
    Route("/signup", signup, methods=["GET", "POST"]), Route("/verify", verify, methods=["GET", "POST"]),
    Route("/login", login, methods=["GET", "POST"]), Route("/magic", magic, methods=["GET", "POST"]), Route("/logout", logout, methods=["POST"]),
    Route("/forgot", forgot, methods=["GET", "POST"]), Route("/reset", reset, methods=["GET", "POST"]), Route("/2fa", twofa, methods=["GET", "POST"]),
    Route("/account", account), Route("/account/profile", profile, methods=["GET", "POST"]), Route("/account/security", security, methods=["GET", "POST"]),
    Route("/account/data", data_rights, methods=["GET", "POST"]), Route("/api/notifications", notifications_api), Route("/follow", follow, methods=["POST"]),
]
