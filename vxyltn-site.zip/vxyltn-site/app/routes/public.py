"""Public pages: landing/profile, terms, privacy, DMCA, payments policy, contact (manual high-value flow), COA verify, health."""
from __future__ import annotations

from starlette.requests import Request
from starlette.responses import JSONResponse, PlainTextResponse
from starlette.routing import Route

from .. import content
from ..members import tiers
from ..money import usd
from ..util import now_ts, valid_email
from ..web import fcents, form_data, fval, redirect, render


async def home(request: Request):
    core = request.app.state.core
    db, s = core.db, core.settings
    viewer = request.state.viewer
    pinned = content.feed(db, s, viewer, limit=3)
    links = db.all("SELECT * FROM link_hub WHERE is_active=1 ORDER BY position, id")
    counters = db.all("SELECT * FROM social_counters ORDER BY position, id")
    members_count = db.count("memberships", "status IN ('active','grace') AND current_period_end>?", (now_ts(),))
    return render(request, "home.html", pinned=pinned, links=links, counters=counters, tiers=tiers(db), members_count=members_count,
                  headline=s.get("profile_headline"), bio_html=content.render_markdown(s.get("profile_bio")))


async def link_out(request: Request):
    core = request.app.state.core
    link = core.db.get("link_hub", int(request.path_params["link_id"]))
    if link is None:
        return redirect("/")
    core.db.execute("UPDATE link_hub SET clicks=clicks+1 WHERE id=?", (link["id"],))
    core.db.insert("link_clicks", link_id=link["id"], user_id=request.state.viewer.user_id, ts=now_ts(), ip=request.state.ip)
    return redirect(link["url"], status_code=302)


async def terms(request: Request):
    from ..requestsys.service import terms_full
    core = request.app.state.core
    return render(request, "terms.html", rq_terms=terms_full(core), cap=usd(core.settings.int("platform_tx_cap_cents")))


async def privacy(request: Request):
    return render(request, "privacy.html")


async def dmca(request: Request):
    core = request.app.state.core
    if request.method == "POST":
        f = await form_data(request)
        if not (fval(f, "urls") and fval(f, "email")):
            return render(request, "dmca.html", error="Email and URLs are required.", form=f)
        core.db.insert("dmca_notices", reporter_name=fval(f, "name"), email=fval(f, "email"), urls=fval(f, "urls")[:8000],
                       description=fval(f, "description")[:8000], kind=fval(f, "kind") or "notice", created_at=now_ts())
        await core.notifier.admin(f"DMCA {fval(f, 'kind') or 'notice'} from {fval(f, 'email')}")
        return redirect("/dmca", request, "Received. The designated agent will review it.", "ok")
    return render(request, "dmca.html", form={})


async def paysupport(request: Request):
    core = request.app.state.core
    return render(request, "paysupport.html", cap=usd(core.settings.int("platform_tx_cap_cents")))


async def contact(request: Request):
    """Contact form; also the manual flow for platform purchases above the automated cap."""
    core = request.app.state.core
    viewer = request.state.viewer
    amount = request.query_params.get("amount")
    if request.method == "POST":
        f = await form_data(request)
        email = fval(f, "email") or (viewer.user["email"] if viewer.user else "")
        if not valid_email(email) or not fval(f, "body"):
            return render(request, "contact.html", error="A valid email and a message are required.", form=f, amount=amount)
        core.db.insert("contact_requests", user_id=viewer.user_id, email=email, subject=fval(f, "subject")[:200], body=fval(f, "body")[:8000],
                       amount_cents=fcents(f, "amount"), kind=fval(f, "kind") or "contact", created_at=now_ts())
        await core.notifier.admin(f"CONTACT ({fval(f, 'kind') or 'contact'}) from {email}: {fval(f, 'subject')[:80]} "
                                  f"{('amount ' + usd(fcents(f, 'amount'))) if fcents(f, 'amount') else ''}")
        return redirect("/contact", request, "Sent. No reply is guaranteed.", "ok")
    return render(request, "contact.html", form={}, amount=amount, cap=usd(core.settings.int("platform_tx_cap_cents")))


async def coa_verify(request: Request):
    core = request.app.state.core
    serial = request.path_params["serial"]
    row = core.db.one("SELECT public_id, coa_json, created_at FROM shop_orders WHERE coa_json LIKE ?", (f'%"{serial}"%',))
    return render(request, "coa.html", serial=serial, found=row is not None, order=row)


async def health(request: Request):
    core = request.app.state.core
    return JSONResponse({"ok": True, "db": core.db.count("users") >= 0, "payments": core.np.enabled, "time": now_ts()})


async def robots(request: Request):
    return PlainTextResponse("User-agent: *\nDisallow: /admin\nDisallow: /account\nDisallow: /messages\nDisallow: /pay\nDisallow: /media\n")


routes = [
    Route("/", home), Route("/l/{link_id:int}", link_out), Route("/terms", terms), Route("/privacy", privacy),
    Route("/dmca", dmca, methods=["GET", "POST"]), Route("/paysupport", paysupport), Route("/contact", contact, methods=["GET", "POST"]),
    Route("/coa/{serial}", coa_verify), Route("/health", health), Route("/robots.txt", robots),
]
