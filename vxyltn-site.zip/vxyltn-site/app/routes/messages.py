"""Direct messages between a user and the creator; paid per message by audience/tier; PPV messages; SSE updates; public question."""
from __future__ import annotations

from starlette.requests import Request
from starlette.responses import HTMLResponse, StreamingResponse
from starlette.routing import Route

from .. import messaging
from ..access import dm_price
from ..lang import is_english
from ..money import usd
from ..payments import CapExceeded
from ..util import esc, valid_email
from ..web import fbool, files_of, form_data, fval, login_required, redirect, render


@login_required
async def inbox(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    if viewer.is_admin:
        return redirect("/admin/messages")
    rows = messaging.thread(core.db, viewer.user_id)
    messaging.mark_read(core.db, viewer.user_id, "user")
    price = dm_price(core.settings, viewer)
    credits = messaging.credits_remaining(core.db, viewer.user_id)
    return render(request, "messages/thread.html", rows=rows, price=price, credits=credits, priority_price=core.settings.int("priority_dm_cents"))


@login_required
async def send(request: Request):
    core = request.app.state.core
    db = core.db
    viewer = request.state.viewer
    f = await form_data(request)
    body = fval(f, "body")
    files = files_of(f, "file")
    if not body and not files:
        return redirect("/messages")
    if body and not is_english(body):
        return redirect("/messages", request, "english (us) only.", "error")
    media_id = None
    if files:
        try:
            media_id = await core.media.save_upload(files[0], viewer.user_id, folder=f"dm/{viewer.user_id}", source="dm")
        except ValueError as exc:
            return redirect("/messages", request, str(exc), "error")
    priority = fbool(f, "priority")
    price = dm_price(core.settings, viewer)
    extra = core.settings.int("priority_dm_cents") if priority else 0
    if price == 0 or messaging.consume_message_credit(db, viewer.user_id):
        if extra and not viewer.is_admin:
            return await _dm_purchase(core, request, viewer, extra, body, media_id, True)
        messaging.send(db, viewer.user_id, "user", body, media_id=media_id, priority=priority)
        return redirect("/messages", request, "sent.", "ok")
    return await _dm_purchase(core, request, viewer, price + extra, body, media_id, priority)


async def _dm_purchase(core, request, viewer, total, body, media_id, priority):
    try:
        p = core.payments.create_purchase(user_id=viewer.user_id, kind="dm", title="direct message" + (" (priority)" if priority else ""), total_cents=total,
                                          entity_type="thread", entity_id=viewer.user_id, audience=viewer.audience, use_credit=True,
                                          meta={"body": body, "media_id": media_id, "priority": priority}, ip=request.state.ip)
    except CapExceeded as exc:
        return redirect(f"/contact?amount={exc.total_cents / 100:.2f}", request, "above the automated cap.", "warn")
    if p["total_cents"] == 0:
        await core.payments.finalize_zero(p)
        return redirect("/messages", request, "sent (paid with credit).", "ok")
    return redirect(f"/pay/{p['public_id']}")


@login_required
async def unlock_message(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    m = core.db.get("messages", int(request.path_params["message_id"]))
    if m is None or m["thread_user_id"] != viewer.user_id or not m["is_locked"]:
        return redirect("/messages")
    from ..access import price_for
    price = price_for(core.settings, viewer, int(m["price_cents"] or 0), None, None, 0, False)
    try:
        p = core.payments.create_purchase(user_id=viewer.user_id, kind="message_unlock", title="unlock message", total_cents=price, entity_type="message",
                                          entity_id=m["id"], audience=viewer.audience, use_credit=True, ip=request.state.ip)
    except CapExceeded as exc:
        return redirect(f"/contact?amount={exc.total_cents / 100:.2f}", request, "above the automated cap.", "warn")
    if p["total_cents"] == 0:
        await core.payments.finalize_zero(p)
        return redirect("/messages", request, "unlocked.", "ok")
    return redirect(f"/pay/{p['public_id']}")


@login_required
async def react(request: Request):
    core = request.app.state.core
    f = await form_data(request)
    messaging.react(core.db, int(request.path_params["message_id"]), request.state.viewer.user_id, fval(f, "emoji")[:8])
    return redirect("/messages")


@login_required
async def events(request: Request):
    viewer = request.state.viewer
    return StreamingResponse(messaging.subscribe(f"dm:{viewer.user_id}"), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@login_required
async def fragment(request: Request):
    """HTML fragment of messages after ?after=id (used by SSE refresh)."""
    core = request.app.state.core
    viewer = request.state.viewer
    after = int(request.query_params.get("after", "0") or 0)
    rows = [r for r in messaging.thread(core.db, viewer.user_id) if r["id"] > after]
    messaging.mark_read(core.db, viewer.user_id, "user")
    html = "".join(_msg_html(r, viewer) for r in rows)
    return HTMLResponse(html)


def _msg_html(r, viewer) -> str:
    who = "you" if r["sender_role"] == "user" else ("system" if r["sender_role"] == "system" else "vxyltn")
    body = esc(r["body"] or "")
    if r["is_locked"] and r["sender_role"] == "creator":
        body = f"locked message — <form method='post' action='/messages/{r['id']}/unlock' class='inline'><button class='link'>unlock for {usd(r['price_cents'])}</button></form>"
    media = f"<div><a href='/media/{r['media_id']}'>attachment</a></div>" if r["media_id"] and not r["is_locked"] else ""
    return f"<div class='msg {r['sender_role']}' data-id='{r['id']}'><div class='who muted'>{who}</div><div>{body}</div>{media}<div class='t'>{r['created_at']}</div></div>"


async def public_question(request: Request):
    """Anyone (even without an account) can pay to send one question. No reply is guaranteed."""
    core = request.app.state.core
    viewer = request.state.viewer
    if request.method == "GET":
        return render(request, "messages/public_question.html", price=core.settings.int("public_question_cents"))
    f = await form_data(request)
    body = fval(f, "body")
    email = fval(f, "email") or (viewer.user["email"] if viewer.user else "")
    if not body or not is_english(body):
        return redirect("/ask", request, "write your question in english.", "error")
    if not viewer.user and not valid_email(email):
        return redirect("/ask", request, "enter a valid email.", "error")
    try:
        p = core.payments.create_purchase(user_id=viewer.user_id, kind="public_question", title="public question", total_cents=core.settings.int("public_question_cents"),
                                          audience=viewer.audience, guest_email=None if viewer.user else email, meta={"body": body}, ip=request.state.ip)
    except CapExceeded as exc:
        return redirect(f"/contact?amount={exc.total_cents / 100:.2f}", request, "above the automated cap.", "warn")
    resp = redirect(f"/pay/{p['public_id']}")
    if not viewer.user:
        resp.set_cookie(f"guest_{p['public_id']}", p["public_id"], max_age=7 * 86400, httponly=True, samesite="lax", secure=core.cfg.cookie_secure)
    return resp


routes = [
    Route("/messages", inbox), Route("/messages/send", send, methods=["POST"]), Route("/messages/{message_id:int}/unlock", unlock_message, methods=["POST"]),
    Route("/messages/{message_id:int}/react", react, methods=["POST"]), Route("/messages/events", events), Route("/messages/fragment", fragment),
    Route("/ask", public_question, methods=["GET", "POST"]),
]
