"""Membership: tiers, bundles, join/renew/upgrade, promo codes, priority list application, audience products."""
from __future__ import annotations

from starlette.requests import Request
from starlette.routing import Route

from .. import members
from ..access import active_membership
from ..money import usd
from ..payments import CapExceeded
from ..web import fbool, fint, form_data, fval, login_required, redirect, render


async def overview(request: Request):
    core = request.app.state.core
    db = core.db
    viewer = request.state.viewer
    current, tier = active_membership(db, viewer.user_id, core.settings.int("membership_grace_days")) if viewer.user_id else (None, None)
    periods = db.all("SELECT * FROM membership_periods WHERE membership_id=? ORDER BY id DESC LIMIT 12", (current["id"],)) if current else []
    rows = []
    for t in members.tiers(db):
        rows.append({"tier": t, "perks": members.tier_perks(t), "full": members.tier_full(db, t), "bundles": members.bundles_for(db, t["id"]),
                     "count": members.tier_member_count(db, t["id"])})
    return render(request, "membership/overview.html", rows=rows, current=current, current_tier=tier, periods=periods,
                  proration=members.proration_credit(db, core.settings, viewer.user_id) if viewer.user_id else 0,
                  preview_pass_cents=core.settings.int("preview_pass_cents"), follower_badge_cents=core.settings.int("follower_badge_cents"),
                  packs=db.all("SELECT * FROM message_packs WHERE is_active=1 ORDER BY price_cents"))


async def tier_page(request: Request):
    core = request.app.state.core
    db = core.db
    viewer = request.state.viewer
    tier = members.tier_by_slug(db, request.path_params["slug"])
    if tier is None or not tier["is_active"]:
        return redirect("/membership", request, "tier not found.")
    options = []
    for months in (1, 3, 6, 12):
        price, label = members.period_price(db, tier, months, False, viewer.user_id)
        options.append({"months": months, "price": price, "label": label})
    yearly = members.period_price(db, tier, 12, True, viewer.user_id) if tier["price_year_cents"] else None
    current, cur_tier = active_membership(db, viewer.user_id, core.settings.int("membership_grace_days")) if viewer.user_id else (None, None)
    credit = members.proration_credit(db, core.settings, viewer.user_id) if (current and cur_tier and cur_tier["rank"] < tier["rank"]) else 0
    return render(request, "membership/tier.html", tier=tier, perks=members.tier_perks(tier), options=options, yearly=yearly,
                  bundles=members.bundles_for(db, tier["id"]), full=members.tier_full(db, tier), current=current, cur_tier=cur_tier,
                  credit=credit, promo=request.query_params.get("promo", ""))


@login_required
async def join(request: Request):
    core = request.app.state.core
    db = core.db
    viewer = request.state.viewer
    f = await form_data(request)
    tier = db.get("tiers", fint(f, "tier_id") or 0)
    if tier is None or not tier["is_active"]:
        return redirect("/membership", request, "tier not found.", "error")
    if members.tier_full(db, tier):
        return redirect(f"/membership/{tier['slug']}", request, "this tier is full.", "warn")
    if core.settings.bool("require_email_verification") and core.emailer.enabled and not viewer.email_verified:
        return redirect("/verify", request, "confirm your email before paying.")
    bundle = db.get("bundles", fint(f, "bundle_id")) if fint(f, "bundle_id") else None
    months = max(1, min(120, fint(f, "months", 1) or 1))
    yearly = fval(f, "period") == "year"
    if bundle and bundle["tier_id"] == tier["id"] and bundle["is_active"]:
        price, label = int(bundle["price_cents"]), f"{bundle['name']} ({bundle['months']} months)"
        seconds = int(bundle["months"]) * members.MONTH
        kind = "bundle"
    else:
        price, label = members.period_price(db, tier, months, yearly, viewer.user_id)
        seconds = members.YEAR if yearly else months * members.MONTH
        kind = "membership"
    promo, perr = members.promo_lookup(db, fval(f, "promo"), "tier", tier["id"], viewer.user_id)
    if perr and fval(f, "promo"):
        return redirect(f"/membership/{tier['slug']}", request, perr, "error")
    discount = members.promo_discount(promo, price)
    current, cur_tier = active_membership(db, viewer.user_id, core.settings.int("membership_grace_days"))
    credit_note = ""
    if current and cur_tier and cur_tier["rank"] < tier["rank"]:
        credit = members.proration_credit(db, core.settings, viewer.user_id)
        if credit:
            db.wallet_apply(viewer.user_id, credit, "upgrade proration credit", "membership", current["id"])
            credit_note = f" {usd(credit)} unused value credited."
        kind = "upgrade"
    try:
        p = core.payments.create_purchase(user_id=viewer.user_id, kind=kind, title=f"{tier['name']} — {label}", total_cents=price, discount_cents=discount,
                                          entity_type="tier", entity_id=tier["id"], promo_id=promo["id"] if promo else None, use_credit=fbool(f, "use_credit") or kind == "upgrade",
                                          audience=viewer.audience, tier_rank_at=viewer.tier_rank, meta={"seconds": seconds, "months": months, "yearly": yearly},
                                          ip=request.state.ip)
    except CapExceeded as exc:
        return redirect(f"/contact?amount={exc.total_cents / 100:.2f}", request, "above the automated cap. use the manual flow.", "warn")
    if p["total_cents"] == 0:
        await core.payments.finalize_zero(p)
        return redirect("/membership", request, "membership active." + credit_note, "ok")
    return redirect(f"/pay/{p['public_id']}", request, credit_note.strip() or None, "ok") if credit_note else redirect(f"/pay/{p['public_id']}")


@login_required
async def priority_apply(request: Request):
    core = request.app.state.core
    db = core.db
    viewer = request.state.viewer
    if request.method == "POST":
        f = await form_data(request)
        if viewer.user["priority_status"] in ("approved", "applied"):
            return redirect("/membership", request, "already on the list or pending.", "warn")
        members.apply_priority(db, viewer.user_id, fval(f, "text"))
        db.audit("priority.applied", actor_user_id=viewer.user_id, actor_role="user", entity_type="user", entity_id=viewer.user_id)
        await core.notifier.admin(f"priority application from #{viewer.user_id} {viewer.user['email']}")
        return redirect("/membership", request, "application received. approval is manual.", "ok")
    rules = members.priority_rules(core.settings)
    return render(request, "membership/priority.html", rules=rules)


@login_required
async def audience_product(request: Request):
    """preview pass, follower badge, message pack purchases."""
    core = request.app.state.core
    viewer = request.state.viewer
    f = await form_data(request)
    kind = fval(f, "kind")
    if kind == "preview_pass":
        price, title, eid = core.settings.int("preview_pass_cents"), f"preview pass ({core.settings.int('preview_pass_hours')}h)", None
    elif kind == "follower_badge":
        price, title, eid = core.settings.int("follower_badge_cents"), "follower badge", None
    elif kind == "message_pack":
        pack = core.db.get("message_packs", fint(f, "pack_id") or 0)
        if pack is None:
            return redirect("/membership", request, "pack not found.", "error")
        price, title, eid = int(pack["price_cents"]), f"message pack: {pack['name']}", pack["id"]
    else:
        return redirect("/membership")
    try:
        p = core.payments.create_purchase(user_id=viewer.user_id, kind=kind, title=title, total_cents=price, entity_type=kind, entity_id=eid,
                                          audience=viewer.audience, use_credit=True, ip=request.state.ip)
    except CapExceeded as exc:
        return redirect(f"/contact?amount={exc.total_cents / 100:.2f}", request, "above the automated cap.", "warn")
    if p["total_cents"] == 0:
        await core.payments.finalize_zero(p)
        return redirect("/membership", request, "done.", "ok")
    return redirect(f"/pay/{p['public_id']}")


routes = [
    Route("/membership", overview), Route("/membership/apply", priority_apply, methods=["GET", "POST"]),
    Route("/membership/join", join, methods=["POST"]), Route("/membership/product", audience_product, methods=["POST"]),
    Route("/membership/{slug}", tier_page),
]
