"""Livestreams: schedule list, room with chat (SSE), tickets, tips/goal, paid pinned + highlighted messages, RSVPs, replays."""
from __future__ import annotations

from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse, StreamingResponse
from starlette.routing import Route

from .. import live, messaging
from ..access import stream_access, tip_min
from ..lang import is_english
from ..money import usd
from ..payments import CapExceeded
from ..util import esc, loads, now_ts
from ..web import form_data, fval, login_required, redirect, render


async def index(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    ups = [(s, stream_access(core.db, core.settings, viewer, s)) for s in live.upcoming(core.db)]
    pasts = [(s, stream_access(core.db, core.settings, viewer, s)) for s in live.past(core.db)]
    return render(request, "live/index.html", upcoming=ups, past=pasts)


async def room(request: Request):
    core = request.app.state.core
    db = core.db
    viewer = request.state.viewer
    s = db.get("streams", int(request.path_params["stream_id"]))
    if s is None:
        return redirect("/live")
    acc = stream_access(db, core.settings, viewer, s)
    if viewer.user_id and acc["ok"]:
        live.touch_viewer(db, s["id"], viewer.user_id)
    rsvp = bool(viewer.user_id and db.one("SELECT 1 FROM stream_rsvps WHERE stream_id=? AND user_id=?", (s["id"], viewer.user_id)))
    return render(request, "live/room.html", s=s, acc=acc, chat=live.chat(db, s["id"]) if acc["ok"] else [], pinned=live.pinned(db, s["id"]),
                  viewers=live.viewers_now(db, s["id"]), offers=live.offers_active(s), milestones=loads(s["milestones_json"], []),
                  tip_presets=core.cfg.tip_presets_cents, tip_min_cents=tip_min(core.settings, viewer), rsvp=rsvp,
                  recording=db.get("media", s["recording_media_id"]) if s["recording_media_id"] else None)


@login_required
async def ticket(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    s = core.db.get("streams", int(request.path_params["stream_id"]))
    acc = stream_access(core.db, core.settings, viewer, s) if s else {"ok": False, "price_cents": 0}
    if s is None or acc["ok"] or acc["price_cents"] <= 0:
        return redirect(f"/live/{s['id']}" if s else "/live")
    try:
        p = core.payments.create_purchase(user_id=viewer.user_id, kind="stream_ticket", title=f"live ticket: {s['title']}", total_cents=acc["price_cents"],
                                          entity_type="stream", entity_id=s["id"], audience=viewer.audience, use_credit=True, ip=request.state.ip)
    except CapExceeded as exc:
        return redirect(f"/contact?amount={exc.total_cents / 100:.2f}", request, "above the automated cap.", "warn")
    if p["total_cents"] == 0:
        await core.payments.finalize_zero(p)
        return redirect(f"/live/{s['id']}", request, "ticket issued.", "ok")
    return redirect(f"/pay/{p['public_id']}")


@login_required
async def rsvp(request: Request):
    core = request.app.state.core
    sid = int(request.path_params["stream_id"])
    core.db.execute("INSERT OR IGNORE INTO stream_rsvps(stream_id, user_id, created_at) VALUES (?,?,?)", (sid, request.state.viewer.user_id, now_ts()))
    return redirect(f"/live/{sid}", request, "you will be notified when it starts.", "ok")


@login_required
async def say(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    s = core.db.get("streams", int(request.path_params["stream_id"]))
    if s is None or not s["chat_enabled"] or s["status"] != "live":
        return HTMLResponse("chat closed", status_code=400)
    if not stream_access(core.db, core.settings, viewer, s)["ok"]:
        return HTMLResponse("no access", status_code=403)
    f = await form_data(request)
    body = fval(f, "body")
    if not body:
        return HTMLResponse("", status_code=204)
    if not is_english(body):
        return HTMLResponse("english (us) only.", status_code=400)
    kind = fval(f, "kind") or "chat"
    if kind in ("pinned", "highlight"):
        price = int((s["pinned_price_cents"] if kind == "pinned" else s["highlight_price_cents"]) or 0)
        if price <= 0:
            return HTMLResponse("not available", status_code=400)
        try:
            p = core.payments.create_purchase(user_id=viewer.user_id, kind=f"{kind}_chat", title=f"{kind} message in {s['title']}", total_cents=price,
                                              entity_type="stream", entity_id=s["id"], audience=viewer.audience, use_credit=True,
                                              meta={"body": body, "minutes": 10}, ip=request.state.ip)
        except CapExceeded as exc:
            return redirect(f"/contact?amount={exc.total_cents / 100:.2f}")
        if p["total_cents"] == 0:
            await core.payments.finalize_zero(p)
            return HTMLResponse("", status_code=204)
        return redirect(f"/pay/{p['public_id']}")
    live.post_chat(core.db, s["id"], viewer.user_id, body)
    return HTMLResponse("", status_code=204)


async def events(request: Request):
    sid = int(request.path_params["stream_id"])
    return StreamingResponse(messaging.subscribe(f"stream:{sid}"), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


async def fragment(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    s = core.db.get("streams", int(request.path_params["stream_id"]))
    if s is None or not stream_access(core.db, core.settings, viewer, s)["ok"]:
        return HTMLResponse("")
    after = int(request.query_params.get("after", "0") or 0)
    if viewer.user_id:
        live.touch_viewer(core.db, s["id"], viewer.user_id)
    rows = live.chat(core.db, s["id"], after_id=after)
    out = []
    for r in rows:
        name = esc(r["display_name"] or r["username"] or ("vxyltn" if r["role"] == "admin" else "member"))
        badge = " <span class='badge vip'>priority</span>" if r["priority_status"] == "approved" else ""
        amt = f" <span class='muted'>{usd(r['amount_cents'])}</span>" if r["amount_cents"] else ""
        out.append(f"<div class='m {r['kind']}' data-id='{r['id']}'><span class='who'>{name}{badge}{amt}</span> {esc(r['body'] or '')}</div>")
    return HTMLResponse("".join(out))


async def state(request: Request):
    core = request.app.state.core
    s = core.db.get("streams", int(request.path_params["stream_id"]))
    if s is None:
        return JSONResponse({}, status_code=404)
    return JSONResponse({"status": s["status"], "viewers": live.viewers_now(core.db, s["id"]), "tips_total_cents": s["tips_total_cents"], "goal_cents": s["tip_goal_cents"]})


routes = [
    Route("/live", index), Route("/live/{stream_id:int}", room), Route("/live/{stream_id:int}/ticket", ticket, methods=["POST"]),
    Route("/live/{stream_id:int}/rsvp", rsvp, methods=["POST"]), Route("/live/{stream_id:int}/say", say, methods=["POST"]),
    Route("/live/{stream_id:int}/events", events), Route("/live/{stream_id:int}/chat", fragment), Route("/api/live/{stream_id:int}", state),
]
