"""Calls: available slots, prepaid booking, my bookings, iCal."""
from __future__ import annotations

from starlette.requests import Request
from starlette.responses import PlainTextResponse
from starlette.routing import Route

from .. import calls
from ..payments import CapExceeded
from ..web import fbool, form_data, fval, login_required, redirect, render


async def index(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    kind = request.query_params.get("kind") or None
    slots = calls.open_slots(core.db, viewer, kind)
    return render(request, "calls/index.html", slots=[(s, calls.slot_price(s)) for s in slots], kind=kind,
                  call_access=viewer.perks.get("call_access", True))


@login_required
async def book(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    slot = core.db.get("call_slots", int(request.path_params["slot_id"]))
    if slot is None or slot["status"] != "open":
        return redirect("/calls", request, "slot not available.", "warn")
    if (slot["priority_only"] and not viewer.is_priority) or int(slot["min_tier_rank"] or 0) > viewer.tier_rank:
        if not viewer.is_admin:
            return redirect("/calls", request, "this slot is reserved for a higher tier or the priority list.", "warn")
    if not viewer.is_member and not viewer.is_admin:
        return redirect("/membership", request, "calls are for members.", "warn")
    f = await form_data(request)
    price = calls.slot_price(slot)
    try:
        bid = calls.book(core.db, slot["id"], viewer.user_id, fval(f, "notes"), fbool(f, "record"))
    except ValueError as exc:
        return redirect("/calls", request, str(exc), "warn")
    try:
        p = core.payments.create_purchase(user_id=viewer.user_id, kind="call", title=f"{slot['kind']} call {core.local(slot['start_at'])}", total_cents=price,
                                          entity_type="call_booking", entity_id=bid, audience=viewer.audience, use_credit=True,
                                          ttl_seconds=30 * 60, ip=request.state.ip)
    except CapExceeded as exc:
        return redirect(f"/contact?amount={exc.total_cents / 100:.2f}", request, "above the automated cap.", "warn")
    core.db.update("call_bookings", bid, purchase_id=p["id"])
    if p["total_cents"] == 0:
        await core.payments.finalize_zero(p)
        return redirect("/calls/mine", request, "booked.", "ok")
    return redirect(f"/pay/{p['public_id']}", request, "the slot is held for 30 minutes while you pay.", "ok")


@login_required
async def mine(request: Request):
    core = request.app.state.core
    rows = core.db.all("SELECT b.*, s.start_at, s.end_at, s.kind AS slot_kind, s.duration_min FROM call_bookings b JOIN call_slots s ON s.id=b.slot_id WHERE b.user_id=? ORDER BY s.start_at DESC",
                       (request.state.viewer.user_id,))
    return render(request, "calls/mine.html", rows=rows)


@login_required
async def ical(request: Request):
    core = request.app.state.core
    rows = core.db.all("SELECT b.id, s.start_at, s.end_at, s.kind FROM call_bookings b JOIN call_slots s ON s.id=b.slot_id WHERE b.user_id=? AND b.status='confirmed'",
                       (request.state.viewer.user_id,))
    events = [{"uid": f"call-{r['id']}@{core.cfg.site_domain}", "start_at": r["start_at"], "end_at": r["end_at"], "title": f"{core.cfg.site_name} {r['kind']} call"} for r in rows]
    return PlainTextResponse(calls.ical(events, core.cfg.site_name), media_type="text/calendar", headers={"Content-Disposition": 'attachment; filename="calls.ics"'})


routes = [Route("/calls", index), Route("/calls/{slot_id:int}/book", book, methods=["POST"]), Route("/calls/mine", mine), Route("/calls/calendar.ics", ical)]
