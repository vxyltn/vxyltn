"""Custom content marketplace (members): submit brief -> quote -> deposit -> delivery -> balance -> revisions; shoutouts."""
from __future__ import annotations

import json

from starlette.requests import Request
from starlette.routing import Route

from .. import customs
from ..lang import is_english
from ..money import usd
from ..payments import CapExceeded
from ..util import now_ts
from ..web import fcents, files_of, form_data, fval, login_required, redirect, render

TYPES = {"custom": "custom content", "shoutout": "shoutout / video message", "photo_set": "photo set", "voice": "voice note", "other": "other"}


async def index(request: Request):
    viewer = request.state.viewer
    return render(request, "customs/index.html", types=TYPES, can=viewer.is_member or viewer.is_admin, fees=customs.PRIORITY_FEES)


@login_required
async def create(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    if not (viewer.is_member or viewer.is_admin) or not viewer.perks.get("custom_orders", True):
        return redirect("/membership", request, "custom orders are for members.", "warn")
    f = await form_data(request)
    title, brief = fval(f, "title"), fval(f, "brief")
    if not title or not brief:
        return redirect("/customs", request, "title and brief are required.", "error")
    if not is_english(title + " " + brief):
        return redirect("/customs", request, "english (us) only.", "error")
    specs = {k: fval(f, k) for k in ("length", "format", "theme", "props", "deadline", "budget") if fval(f, k)}
    media_ids = []
    for up in files_of(f, "files")[:10]:
        try:
            media_ids.append(await core.media.save_upload(up, viewer.user_id, folder=f"customs/{viewer.user_id}", source="custom_brief"))
        except ValueError as exc:
            return redirect("/customs", request, str(exc), "error")
    o = customs.create(core.db, viewer.user_id, fval(f, "type") if fval(f, "type") in TYPES else "custom", title, brief, specs, media_ids)
    await core.notifier.admin(f"custom order {o['public_id']} from #{viewer.user_id}: {title[:80]}")
    return redirect(f"/customs/{o['public_id']}", request, "submitted. you will see a quote here when it is ready.", "ok")


@login_required
async def mine(request: Request):
    core = request.app.state.core
    return render(request, "customs/mine.html", orders=customs.user_orders(core.db, request.state.viewer.user_id))


@login_required
async def detail(request: Request):
    core = request.app.state.core
    db = core.db
    viewer = request.state.viewer
    o = db.one("SELECT * FROM custom_orders WHERE public_id=?", (request.path_params["public_id"],))
    if o is None or (o["user_id"] != viewer.user_id and not viewer.is_admin):
        return redirect("/customs/mine", request, "not found.")
    if request.method == "POST":
        f = await form_data(request)
        action = fval(f, "action")
        if action == "deposit" and o["status"] == "quoted":
            cents = customs.deposit_cents(o)
            try:
                p = core.payments.create_purchase(user_id=viewer.user_id, kind="custom_deposit", title=f"deposit {o['public_id']}", total_cents=cents,
                                                  entity_type="custom_order", entity_id=o["id"], use_credit=True, ip=request.state.ip)
            except CapExceeded as exc:
                return redirect(f"/contact?amount={exc.total_cents / 100:.2f}", request, "above the automated cap.", "warn")
            if p["total_cents"] == 0:
                await core.payments.finalize_zero(p)
                return redirect(f"/customs/{o['public_id']}", request, "deposit received.", "ok")
            return redirect(f"/pay/{p['public_id']}")
        if action == "balance" and o["status"] == "delivered":
            cents = customs.balance_cents(o)
            if cents <= 0:
                customs.on_balance_paid(db, o["id"], None)
                return redirect(f"/customs/{o['public_id']}")
            try:
                p = core.payments.create_purchase(user_id=viewer.user_id, kind="custom_balance", title=f"balance {o['public_id']}", total_cents=cents,
                                                  entity_type="custom_order", entity_id=o["id"], use_credit=True, ip=request.state.ip)
            except CapExceeded as exc:
                return redirect(f"/contact?amount={exc.total_cents / 100:.2f}", request, "above the automated cap.", "warn")
            if p["total_cents"] == 0:
                await core.payments.finalize_zero(p)
                return redirect(f"/customs/{o['public_id']}", request, "balance received. download available.", "ok")
            return redirect(f"/pay/{p['public_id']}")
        if action == "counter" and o["status"] == "quoted":
            cents = fcents(f, "amount")
            if cents:
                customs.counter_offer(db, o["id"], cents, viewer.user_id)
                await core.notifier.admin(f"counter-offer {usd(cents)} on {o['public_id']}")
            return redirect(f"/customs/{o['public_id']}", request, "counter-offer sent.", "ok")
        if action == "priority":
            level = fval(f, "level")
            fee = customs.PRIORITY_FEES.get(level)
            if not fee:
                return redirect(f"/customs/{o['public_id']}")
            try:
                p = core.payments.create_purchase(user_id=viewer.user_id, kind="custom_priority", title=f"{level} priority for {o['public_id']}", total_cents=fee,
                                                  entity_type="custom_order", entity_id=o["id"], use_credit=True, meta={"level": level}, ip=request.state.ip)
            except CapExceeded as exc:
                return redirect(f"/contact?amount={exc.total_cents / 100:.2f}", request, "above the automated cap.", "warn")
            if p["total_cents"] == 0:
                await core.payments.finalize_zero(p)
                return redirect(f"/customs/{o['public_id']}", request, "priority applied.", "ok")
            return redirect(f"/pay/{p['public_id']}")
        if action == "revision" and o["status"] in ("delivered", "completed"):
            err = customs.request_revision(db, o["id"], viewer.user_id, fval(f, "note")[:2000])
            return redirect(f"/customs/{o['public_id']}", request, err or "revision requested.", "error" if err else "ok")
        if action == "message":
            body = fval(f, "body")
            if body and is_english(body):
                db.insert("custom_messages", order_id=o["id"], sender_role="user", body=body[:4000], created_at=now_ts())
                await core.notifier.admin(f"message on {o['public_id']}: {body[:120]}")
            return redirect(f"/customs/{o['public_id']}")
        if action == "cancel" and o["status"] in ("pending", "quoted"):
            db.update("custom_orders", o["id"], status="canceled", updated_at=now_ts())
            return redirect("/customs/mine", request, "canceled.", "ok")
    deliverables = customs.deliverables(db, o) if customs.can_download(o) else []
    links = [(m, core.media.download_token(m["id"], viewer.user_id, "custom_delivery", 24 * 3600, 5)) for m in deliverables]
    return render(request, "customs/detail.html", o=o, specs=json.loads(o["specs_json"] or "{}"), messages=customs.messages(db, o["id"]),
                  attachments=customs.attachments(db, o), deliverables=links, deposit=customs.deposit_cents(o), balance=customs.balance_cents(o),
                  can_download=customs.can_download(o), fees=customs.PRIORITY_FEES)


routes = [Route("/customs", index), Route("/customs/new", create, methods=["POST"]), Route("/customs/mine", mine), Route("/customs/{public_id}", detail, methods=["GET", "POST"])]
