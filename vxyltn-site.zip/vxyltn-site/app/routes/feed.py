"""Feed, posts, interactions, collections, and access-controlled media delivery (watermarked)."""
from __future__ import annotations

import asyncio
import os

from starlette.requests import Request
from starlette.responses import FileResponse, Response
from starlette.routing import Route

from .. import content
from ..access import channel_access, has_unlock, post_access, price_for, stream_access
from ..lang import is_english
from ..payments import CapExceeded
from ..util import loads, now_ts
from ..web import fint, form_data, fval, login_required, page_args, redirect, render


# ------------------------------------------------------------------ feed
async def feed(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    page, size, offset = page_args(request, 15)
    only_type = request.query_params.get("type") or None
    coll = fint(dict(request.query_params), "collection")
    items = content.feed(core.db, core.settings, viewer, limit=size + 1, offset=offset, collection_id=coll, only_type=only_type)
    has_more = len(items) > size
    return render(request, "feed.html", items=items[:size], page=page, has_more=has_more, stories=content.stories(core.db, core.settings, viewer),
                  collections=content.collections_list(core.db), only_type=only_type, coll=coll, types=content.POST_TYPES)


async def post_page(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    post = core.db.get("posts", int(request.path_params["post_id"]))
    if post is None or post["deleted_at"]:
        return render(request, "error.html", status_code=404, status="not found", message="this post does not exist.")
    item = content.decorate(core.db, core.settings, viewer, post)
    if item["access"]["state"] == "hidden" and not viewer.is_admin:
        return render(request, "error.html", status_code=404, status="not found", message="this post is not available.")
    content.record_view(core.db, post["id"], viewer.user_id, request.state.ip)
    comments_price = 0
    if viewer.user_id and not viewer.is_admin and post["allow_comments"]:
        cp = post["comments_price_cents"] if post["comments_price_cents"] is not None else core.settings.int("comment_price_cents")
        if cp and not (viewer.is_member and viewer.perks.get("comments_free")) and not has_unlock(core.db, viewer.user_id, "comments", post["id"]):
            comments_price = price_for(core.settings, viewer, cp, None, None, 0, False)
    return render(request, "post.html", item=item, post=post, comments=content.comments_tree(core.db, post["id"], viewer),
                  comments_price=comments_price, reactions=content.REACTIONS, tip_presets=core.cfg.tip_presets_cents)


def _purchase_or_redirect(request: Request, **kw):
    core = request.app.state.core
    try:
        p = core.payments.create_purchase(ip=request.state.ip, **kw)
    except CapExceeded as exc:
        return None, redirect(f"/contact?amount={exc.total_cents / 100:.2f}", request, "that amount is above the automated cap. use the manual flow.", "warn")
    return p, None


@login_required
async def unlock(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    post = core.db.get("posts", int(request.path_params["post_id"]))
    if post is None:
        return redirect("/feed")
    acc = post_access(core.db, core.settings, viewer, post)
    if acc["state"] == "open":
        return redirect(f"/post/{post['id']}")
    if acc["price_cents"] <= 0:
        return redirect("/membership", request, "this post is included with a membership tier.", "warn")
    p, resp = _purchase_or_redirect(request, user_id=viewer.user_id, kind="post", title=f"unlock: {post['title'] or post['type']} #{post['id']}",
                                    total_cents=acc["price_cents"], entity_type="post", entity_id=post["id"], audience=viewer.audience,
                                    tier_rank_at=viewer.tier_rank, use_credit=True)
    if resp:
        return resp
    if p["total_cents"] == 0:
        await core.payments.finalize_zero(p)
        return redirect(f"/post/{post['id']}", request, "unlocked with credit.", "ok")
    return redirect(f"/pay/{p['public_id']}")


@login_required
async def unlock_collection(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    coll = core.db.get("collections", int(request.path_params["coll_id"]))
    if coll is None or coll["price_cents"] is None:
        return redirect("/feed")
    price = price_for(core.settings, viewer, int(coll["price_cents"]), coll["public_price_cents"], None, int(coll["min_tier_rank"] or 0), True)
    if price <= 0:
        return redirect(f"/feed?collection={coll['id']}")
    p, resp = _purchase_or_redirect(request, user_id=viewer.user_id, kind="collection", title=f"collection: {coll['name']}", total_cents=price,
                                    entity_type="collection", entity_id=coll["id"], audience=viewer.audience, use_credit=True)
    if resp:
        return resp
    if p["total_cents"] == 0:
        await core.payments.finalize_zero(p)
        return redirect(f"/feed?collection={coll['id']}", request, "unlocked.", "ok")
    return redirect(f"/pay/{p['public_id']}")


@login_required
async def like(request: Request):
    core = request.app.state.core
    pid = int(request.path_params["post_id"])
    content.toggle_like(core.db, pid, request.state.viewer.user_id)
    return redirect(f"/post/{pid}")


@login_required
async def react(request: Request):
    core = request.app.state.core
    pid = int(request.path_params["post_id"])
    f = await form_data(request)
    try:
        content.toggle_reaction(core.db, pid, request.state.viewer.user_id, fval(f, "emoji"))
    except ValueError:
        pass
    return redirect(f"/post/{pid}")


@login_required
async def comment(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    pid = int(request.path_params["post_id"])
    post = core.db.get("posts", pid)
    if post is None or not post["allow_comments"]:
        return redirect(f"/post/{pid}", request, "comments are closed.", "warn")
    acc = post_access(core.db, core.settings, viewer, post)
    if acc["state"] != "open":
        return redirect(f"/post/{pid}", request, "unlock the post to comment.", "warn")
    cp = post["comments_price_cents"] if post["comments_price_cents"] is not None else core.settings.int("comment_price_cents")
    if cp and not viewer.is_admin and not (viewer.is_member and viewer.perks.get("comments_free")) and not has_unlock(core.db, viewer.user_id, "comments", pid):
        price = price_for(core.settings, viewer, cp, None, None, 0, False)
        p, resp = _purchase_or_redirect(request, user_id=viewer.user_id, kind="comment_unlock", title=f"commenting on post #{pid}", total_cents=price,
                                        entity_type="post", entity_id=pid, audience=viewer.audience, use_credit=True)
        if resp:
            return resp
        return redirect(f"/pay/{p['public_id']}")
    f = await form_data(request)
    body = fval(f, "body")
    if not body:
        return redirect(f"/post/{pid}")
    if not is_english(body):
        return redirect(f"/post/{pid}", request, "english (us) only.", "error")
    try:
        content.add_comment(core.db, pid, viewer.user_id, body, fint(f, "parent_id"), is_private=fval(f, "private") == "1")
    except ValueError:
        pass
    return redirect(f"/post/{pid}#comments")


@login_required
async def vote(request: Request):
    core = request.app.state.core
    f = await form_data(request)
    poll_id = int(request.path_params["poll_id"])
    opts = f.get("option") or []
    if not isinstance(opts, list):
        opts = [opts]
    try:
        content.vote(core.db, poll_id, request.state.viewer.user_id, [int(o) for o in opts if str(o).isdigit()])
    except ValueError as exc:
        poll = core.db.get("polls", poll_id)
        return redirect(f"/post/{poll['post_id']}" if poll else "/feed", request, str(exc), "error")
    poll = core.db.get("polls", poll_id)
    return redirect(f"/post/{poll['post_id']}", request, "vote recorded.", "ok")


# ------------------------------------------------------------------ media delivery
def _media_access(core, viewer, media) -> tuple[bool, bool]:
    """(allowed, watermark). Looks up where the media is used and applies that object's access rules."""
    db, s = core.db, core.settings
    if viewer.is_admin:
        return True, False
    if media["owner_user_id"] and viewer.user_id == media["owner_user_id"]:
        return True, False
    if media["folder"] == "avatars" or media["is_public"]:
        return True, False
    if viewer.user_id and has_unlock(db, viewer.user_id, "media", media["id"]):
        return True, False
    for pm in db.all("SELECT post_id FROM post_media WHERE media_id=?", (media["id"],)):
        post = db.get("posts", pm["post_id"])
        if post and not post["deleted_at"]:
            acc = post_access(db, s, viewer, post)
            if acc["state"] == "open":
                return True, bool(post["watermark"])
    for m in db.all("SELECT * FROM messages WHERE media_id=? AND deleted_at IS NULL", (media["id"],)):
        if viewer.user_id == m["thread_user_id"] and not (m["is_locked"] and m["sender_role"] == "creator"):
            return True, True
    for cp in db.all("SELECT channel_id, price_cents, id FROM channel_posts WHERE media_id=?", (media["id"],)):
        ch = db.get("channels", cp["channel_id"])
        if ch and channel_access(db, viewer, ch) and (not cp["price_cents"] or has_unlock(db, viewer.user_id, "channel_post", cp["id"])):
            return True, True
    for cc in db.all("SELECT channel_id FROM channel_chat WHERE media_id=?", (media["id"],)):
        ch = db.get("channels", cc["channel_id"])
        if ch and channel_access(db, viewer, ch):
            return True, True
    for st in db.all("SELECT * FROM streams WHERE recording_media_id=?", (media["id"],)):
        if stream_access(db, s, viewer, st)["ok"]:
            return True, True
    if viewer.user_id:
        from .. import customs
        for d in db.all("SELECT id FROM drops WHERE media_ids_json LIKE ?", (f"%{media['id']}%",)):
            dr = db.get("drops", d["id"])
            if media["id"] in loads(dr["media_ids_json"], []) and has_unlock(db, viewer.user_id, "drop", dr["id"]):
                return True, True
        for co in db.all("SELECT * FROM custom_orders WHERE user_id=? AND (delivery_media_json LIKE ? OR attachments_json LIKE ?)", (viewer.user_id, f"%{media['id']}%", f"%{media['id']}%")):
            if media["id"] in loads(co["attachments_json"], []):
                return True, False
            if media["id"] in loads(co["delivery_media_json"], []) and customs.can_download(co):
                return True, True
    return False, False


async def media_file(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    media = core.db.get("media", int(request.path_params["media_id"]))
    if media is None or media["deleted_at"]:
        return Response("not found", status_code=404)
    variant = request.path_params.get("variant")
    path = media["path"]
    if variant == "thumb":
        path = media["thumb_path"] or media["path"]
    elif variant == "blur":
        path = media["blur_path"] or media["thumb_path"] or media["path"]
    elif variant == "poster":
        path = media["poster_path"] or media["thumb_path"] or media["path"]
    if variant == "blur":
        abs_path = core.media.abs_path(path)
        return FileResponse(abs_path, headers={"Cache-Control": "private, max-age=3600"}) if os.path.exists(abs_path) else Response(status_code=404)
    allowed, watermark = _media_access(core, viewer, media)
    if not allowed:
        if variant in ("thumb", "poster") and media["blur_path"]:
            return FileResponse(core.media.abs_path(media["blur_path"]), headers={"Cache-Control": "private, max-age=3600"})
        return Response("locked", status_code=403)
    abs_path = core.media.abs_path(path)
    if not os.path.exists(abs_path):
        return Response("missing", status_code=404)
    if watermark and media["kind"] == "image" and variant is None and (media["mime"] or "").startswith("image/") and "gif" not in (media["mime"] or ""):
        text = core.settings.get("watermark_text") or f"© {now_ts() // 31557600 + 1970} {core.cfg.site_name}"
        data = await asyncio.to_thread(core.media.watermarked, media, viewer.user_id, request.state.ip, text, core.settings.int("watermark_opacity"))
        return Response(data, media_type=media["mime"], headers={"Cache-Control": "private, no-store", "Content-Disposition": "inline"})
    headers = {"Cache-Control": "private, max-age=600", "Content-Disposition": "inline"}
    return FileResponse(abs_path, media_type=media["mime"] if variant is None else None, headers=headers)


async def download(request: Request):
    core = request.app.state.core
    media = core.media.consume_download_token(request.path_params["token"])
    if media is None:
        return Response("link expired", status_code=410)
    return FileResponse(core.media.abs_path(media["path"]), media_type=media["mime"], filename=media["filename"])


routes = [
    Route("/feed", feed), Route("/post/{post_id:int}", post_page), Route("/post/{post_id:int}/unlock", unlock, methods=["POST"]),
    Route("/collection/{coll_id:int}/unlock", unlock_collection, methods=["POST"]), Route("/post/{post_id:int}/like", like, methods=["POST"]),
    Route("/post/{post_id:int}/react", react, methods=["POST"]), Route("/post/{post_id:int}/comment", comment, methods=["POST"]),
    Route("/poll/{poll_id:int}/vote", vote, methods=["POST"]), Route("/media/{media_id:int}", media_file),
    Route("/media/{media_id:int}/{variant}", media_file), Route("/dl/{token}", download),
]
