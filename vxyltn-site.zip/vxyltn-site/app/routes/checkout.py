"""Checkout: payment page per purchase, redirect to NOWPayments, status API, IPN webhook, receipts."""
from __future__ import annotations

import asyncio

from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from ..money import display_prices
from ..nowpayments import STATUS_HELP
from ..payments import PaymentsNotConfigured
from ..web import form_data, fval, redirect, render


def _owned(request: Request, purchase) -> bool:
    viewer = request.state.viewer
    if purchase is None:
        return False
    if viewer.is_admin:
        return True
    if purchase["user_id"]:
        return viewer.user_id == purchase["user_id"]
    # guest purchase: allow via signed cookie token
    return request.cookies.get(f"guest_{purchase['public_id']}") == purchase["public_id"]


async def pay(request: Request):
    core = request.app.state.core
    purchase = core.db.one("SELECT * FROM purchases WHERE public_id=?", (request.path_params["public_id"],))
    if not _owned(request, purchase):
        return redirect("/login?next=" + request.url.path, request, "log in to see this payment.")
    invoices = core.payments.invoices(purchase["id"])
    nxt = core.payments.next_invoice(purchase["id"])
    rq = core.db.one("SELECT public_id FROM rq_orders WHERE purchase_id=?", (purchase["id"],)) if purchase["kind"].startswith("rq_") else None
    return render(request, "pay.html", purchase=purchase, invoices=invoices, next_invoice=nxt, status_help=STATUS_HELP,
                  prices=display_prices(int(purchase["total_cents"]), core.cfg.fx_rates, core.cfg.display_currencies),
                  rq=rq, returned=request.query_params.get("return"), canceled=request.query_params.get("cancel"),
                  payments_enabled=core.np.enabled)


async def pay_go(request: Request):
    """POST: create/reuse the NOWPayments invoice for the next part and redirect to it."""
    core = request.app.state.core
    purchase = core.db.one("SELECT * FROM purchases WHERE public_id=?", (request.path_params["public_id"],))
    if not _owned(request, purchase):
        return redirect("/login", request, "log in first.")
    if purchase["status"] in ("paid", "canceled", "expired", "failed"):
        return redirect(f"/pay/{purchase['public_id']}", request, f"this purchase is {purchase['status']}.")
    f = await form_data(request)
    try:
        url = await core.payments.checkout_url(purchase, reissue=fval(f, "reissue") == "1")
    except PaymentsNotConfigured:
        return redirect(f"/pay/{purchase['public_id']}", request, "payments are not configured yet. try later.", "error")
    except Exception as exc:  # NOWPayments error
        core.db.audit("invoice.error", actor_user_id=purchase["user_id"], entity_type="purchase", entity_id=purchase["public_id"], data={"error": str(exc)[:500]})
        return redirect(f"/pay/{purchase['public_id']}", request, "the payment processor did not accept the invoice. try again in a minute.", "error")
    return redirect(url, status_code=303)


async def pay_cancel(request: Request):
    core = request.app.state.core
    purchase = core.db.one("SELECT * FROM purchases WHERE public_id=?", (request.path_params["public_id"],))
    if not _owned(request, purchase):
        return redirect("/login")
    core.payments.cancel_pending(purchase, "user")
    return redirect("/account", request, "unpaid purchase canceled. nothing was charged.")


async def pay_status(request: Request):
    core = request.app.state.core
    purchase = core.db.one("SELECT * FROM purchases WHERE public_id=?", (request.path_params["public_id"],))
    if not _owned(request, purchase):
        return JSONResponse({"error": "not found"}, status_code=404)
    nxt = core.payments.next_invoice(purchase["id"])
    return JSONResponse({"status": purchase["status"], "parts_paid": purchase["parts_paid"], "parts_total": purchase["parts_total"],
                         "np_status": nxt["np_status"] if nxt else None})


async def receipt(request: Request):
    core = request.app.state.core
    purchase = core.db.one("SELECT * FROM purchases WHERE public_id=?", (request.path_params["public_id"],))
    if not _owned(request, purchase) or purchase["status"] != "paid":
        return redirect("/account")
    from ..pdfgen import build_receipt_pdf
    data = await asyncio.to_thread(build_receipt_pdf, core, purchase)
    return Response(data, media_type="application/pdf", headers={"Content-Disposition": f'inline; filename="receipt-{purchase["public_id"]}.pdf"'})


async def ipn(request: Request):
    core = request.app.state.core
    body = await request.body()
    result = await core.payments.handle_ipn(body, request.headers.get("x-nowpayments-sig"), request.state.ip)
    status = 200 if result.get("ok") else 400
    return JSONResponse(result, status_code=status)


async def wallet_topup(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    if viewer.user is None:
        return redirect("/login")
    from ..web import fcents
    f = await form_data(request)
    cents = fcents(f, "amount")
    if not cents or cents < 1:
        return redirect("/account", request, "enter an amount.", "error")
    try:
        p = core.payments.create_purchase(user_id=viewer.user_id, kind="wallet", title="credit top-up", total_cents=cents, ip=request.state.ip)
    except Exception as exc:
        return redirect("/account", request, str(exc), "error")
    return redirect(f"/pay/{p['public_id']}")


routes = [
    Route("/pay/{public_id}", pay), Route("/pay/{public_id}/go", pay_go, methods=["POST"]), Route("/pay/{public_id}/cancel", pay_cancel, methods=["POST"]),
    Route("/api/pay/{public_id}", pay_status), Route("/pay/{public_id}/receipt.pdf", receipt),
    Route("/api/nowpayments/ipn", ipn, methods=["POST"]), Route("/wallet/topup", wallet_topup, methods=["POST"]),
]
