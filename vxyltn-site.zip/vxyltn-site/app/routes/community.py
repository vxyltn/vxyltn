"""Tips & fundraising, private channels, drops, shop, public calendar."""
from __future__ import annotations


from starlette.requests import Request
from starlette.responses import HTMLResponse, PlainTextResponse, StreamingResponse
from starlette.routing import Route

from .. import community, messaging
from ..access import channel_access, price_for, tip_min
from ..lang import is_english
from ..money import usd
from ..payments import CapExceeded
from ..util import esc, loads, now_ts
from ..web import fbool, fcents, fint, form_data, fval, login_required, redirect, render


def _cap(request, exc: CapExceeded):
    return redirect(f"/contact?amount={exc.total_cents / 100:.2f}", request, "above the automated cap. use the manual flow.", "warn")


# ================================================================== tips & fundraising
async def tips_page(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    return render(request, "community/tips.html", presets=core.cfg.tip_presets_cents, minimum=tip_min(core.settings, viewer),
                  leaders=community.leaderboard(core.db), campaigns=community.campaigns_active(core.db),
                  first_bonus=core.settings.int("first_tip_bonus_pct"))


async def tip_send(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    f = await form_data(request)
    cents = fcents(f, "amount")
    minimum = tip_min(core.settings, viewer)
    if not cents or cents < minimum:
        return redirect(fval(f, "next") or "/tips", request, f"minimum tip is {usd(minimum)}.", "error")
    ctx_type = fval(f, "context_type") or "profile"
    ctx_id = fint(f, "context_id")
    guest_email = None
    if viewer.user is None:
        guest_email = fval(f, "email") or None
    try:
        p = core.payments.create_purchase(user_id=viewer.user_id, kind="tip", title=f"tip ({ctx_type})", total_cents=cents, entity_type=ctx_type, entity_id=ctx_id,
                                          audience=viewer.audience, use_credit=fbool(f, "use_credit"), guest_email=guest_email,
                                          meta={"context_type": ctx_type, "context_id": ctx_id, "message": fval(f, "message")[:500], "anonymous": fbool(f, "anonymous")},
                                          ip=request.state.ip)
    except CapExceeded as exc:
        return _cap(request, exc)
    if p["total_cents"] == 0:
        await core.payments.finalize_zero(p)
        return redirect(fval(f, "next") or "/tips", request, "tip sent.", "ok")
    resp = redirect(f"/pay/{p['public_id']}")
    if viewer.user is None:
        resp.set_cookie(f"guest_{p['public_id']}", p["public_id"], max_age=7 * 86400, httponly=True, samesite="lax", secure=core.cfg.cookie_secure)
    return resp


async def campaign(request: Request):
    core = request.app.state.core
    c = core.db.one("SELECT * FROM campaigns WHERE slug=?", (request.path_params["slug"],))
    if c is None:
        return redirect("/tips")
    return render(request, "community/campaign.html", c=c, milestones=loads(c["milestones_json"], []), donors=community.campaign_donors(core.db, c["id"]),
                  presets=core.cfg.tip_presets_cents, pct=min(100, int(100 * c["raised_cents"] / c["goal_cents"])) if c["goal_cents"] else 0)


async def contribute(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    c = core.db.one("SELECT * FROM campaigns WHERE slug=?", (request.path_params["slug"],))
    if c is None or c["status"] not in ("active", "funded"):
        return redirect("/tips", request, "campaign closed.", "warn")
    f = await form_data(request)
    cents = fcents(f, "amount")
    if not cents or cents < 1:
        return redirect(f"/fund/{c['slug']}", request, "enter an amount.", "error")
    try:
        p = core.payments.create_purchase(user_id=viewer.user_id, kind="campaign", title=f"contribution: {c['title']}", total_cents=cents, entity_type="campaign",
                                          entity_id=c["id"], audience=viewer.audience, guest_email=fval(f, "email") or None if not viewer.user else None,
                                          meta={"public": not fbool(f, "anonymous"), "message": fval(f, "message")[:300]}, ip=request.state.ip)
    except CapExceeded as exc:
        return _cap(request, exc)
    resp = redirect(f"/pay/{p['public_id']}")
    if viewer.user is None:
        resp.set_cookie(f"guest_{p['public_id']}", p["public_id"], max_age=7 * 86400, httponly=True, samesite="lax", secure=core.cfg.cookie_secure)
    return resp


# ================================================================== channels
async def channels(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    rows = community.channels_visible(core.db, viewer)
    for r in rows:
        ch = r["channel"]
        r["price"] = price_for(core.settings, viewer, int(ch["entry_price_cents"]), None, None, 0, False) if ch["entry_price_cents"] else 0
    return render(request, "community/channels.html", rows=rows)


@login_required
async def channel_room(request: Request):
    core = request.app.state.core
    db = core.db
    viewer = request.state.viewer
    ch = db.one("SELECT * FROM channels WHERE slug=?", (request.path_params["slug"],))
    if ch is None or not ch["is_active"]:
        return redirect("/channels")
    ok = channel_access(db, viewer, ch)
    if not ok:
        price = price_for(core.settings, viewer, int(ch["entry_price_cents"]), None, None, 0, False) if ch["entry_price_cents"] else 0
        return render(request, "community/channel_locked.html", ch=ch, price=price, members=db.count("channel_members", "channel_id=?", (ch["id"],)))
    posts = community.channel_feed(db, ch["id"])
    chat = community.channel_chat(db, ch["id"])
    return render(request, "community/channel.html", ch=ch, posts=posts, chat=chat, members=db.count("channel_members", "channel_id=?", (ch["id"],)),
                  streams=db.all("SELECT * FROM streams WHERE channel_id=? AND status IN ('scheduled','live') ORDER BY scheduled_at", (ch["id"],)))


@login_required
async def channel_join(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    ch = core.db.one("SELECT * FROM channels WHERE slug=?", (request.path_params["slug"],))
    if ch is None or channel_access(core.db, viewer, ch):
        return redirect(f"/channels/{ch['slug']}" if ch else "/channels")
    if ch["member_cap"] and core.db.count("channel_members", "channel_id=?", (ch["id"],)) >= ch["member_cap"]:
        return redirect("/channels", request, "this channel is full.", "warn")
    if ch["kind"] == "priority":
        return redirect("/membership/apply", request, "priority-list only.", "warn")
    if ch["kind"] == "tier" or not ch["entry_price_cents"]:
        return redirect("/membership", request, f"this channel requires tier {ch['min_tier_rank']}+.", "warn")
    price = price_for(core.settings, viewer, int(ch["entry_price_cents"]), None, None, 0, False)
    try:
        p = core.payments.create_purchase(user_id=viewer.user_id, kind="channel", title=f"channel entry: {ch['name']}", total_cents=price, entity_type="channel",
                                          entity_id=ch["id"], audience=viewer.audience, use_credit=True, ip=request.state.ip)
    except CapExceeded as exc:
        return _cap(request, exc)
    if p["total_cents"] == 0:
        await core.payments.finalize_zero(p)
        return redirect(f"/channels/{ch['slug']}", request, "joined.", "ok")
    return redirect(f"/pay/{p['public_id']}")


@login_required
async def channel_say(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    ch = core.db.one("SELECT * FROM channels WHERE slug=?", (request.path_params["slug"],))
    if ch is None or not channel_access(core.db, viewer, ch):
        return HTMLResponse("no access", status_code=403)
    f = await form_data(request)
    body = fval(f, "body")
    if body and is_english(body):
        community.channel_say(core.db, ch["id"], viewer.user_id, body)
    return HTMLResponse("", status_code=204)


async def channel_events(request: Request):
    core = request.app.state.core
    ch = core.db.one("SELECT id FROM channels WHERE slug=?", (request.path_params["slug"],))
    if ch is None:
        return HTMLResponse("", status_code=404)
    return StreamingResponse(messaging.subscribe(f"channel:{ch['id']}"), media_type="text/event-stream", headers={"Cache-Control": "no-cache"})


async def channel_fragment(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    ch = core.db.one("SELECT * FROM channels WHERE slug=?", (request.path_params["slug"],))
    if ch is None or not channel_access(core.db, viewer, ch):
        return HTMLResponse("")
    after = int(request.query_params.get("after", "0") or 0)
    rows = community.channel_chat(core.db, ch["id"], after_id=after)
    return HTMLResponse("".join(f"<div class='m' data-id='{r['id']}'><span class='who'>{esc(r['display_name'] or r['username'] or ('vxyltn' if r['role'] == 'admin' else 'member'))}</span> {esc(r['body'] or '')}</div>" for r in rows))


# ================================================================== drops
async def drops(request: Request):
    core = request.app.state.core
    return render(request, "community/drops.html", rows=community.drops_list(core.db, core.settings, request.state.viewer))


async def drop_page(request: Request):
    core = request.app.state.core
    d = core.db.one("SELECT * FROM drops WHERE slug=?", (request.path_params["slug"],))
    if d is None:
        return redirect("/drops")
    return render(request, "community/drop.html", r=community.drop_state(core.db, core.settings, request.state.viewer, d))


@login_required
async def drop_buy(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    d = core.db.one("SELECT * FROM drops WHERE slug=?", (request.path_params["slug"],))
    if d is None:
        return redirect("/drops")
    st = community.drop_state(core.db, core.settings, viewer, d)
    f = await form_data(request)
    if fval(f, "action") == "waitlist":
        core.db.execute("INSERT OR IGNORE INTO drop_waitlist(drop_id, user_id, created_at) VALUES (?,?,?)", (d["id"], viewer.user_id, now_ts()))
        return redirect(f"/drops/{d['slug']}", request, "on the waitlist.", "ok")
    if st["state"] != "open":
        return redirect(f"/drops/{d['slug']}", request, f"not available ({st['state'].replace('_', ' ')}).", "warn")
    if st["price_cents"] <= 0:
        community.grant_drop(core.db, d["id"], viewer.user_id, None)
        return redirect(f"/drops/{d['slug']}", request, "included with your tier.", "ok")
    try:
        p = core.payments.create_purchase(user_id=viewer.user_id, kind="drop", title=f"drop: {d['title']}", total_cents=st["price_cents"], entity_type="drop",
                                          entity_id=d["id"], audience=viewer.audience, use_credit=True, ttl_seconds=3600, ip=request.state.ip)
    except CapExceeded as exc:
        return _cap(request, exc)
    if p["total_cents"] == 0:
        await core.payments.finalize_zero(p)
        return redirect(f"/drops/{d['slug']}", request, "yours.", "ok")
    return redirect(f"/pay/{p['public_id']}")


# ================================================================== shop
def _cart_id(request: Request) -> str | None:
    return request.cookies.get("vx_cart")


async def shop(request: Request):
    core = request.app.state.core
    return render(request, "community/shop.html", items=community.products(core.db, core.settings, request.state.viewer),
                  cart=community.cart_get(core.db, _cart_id(request)))


async def product_page(request: Request):
    core = request.app.state.core
    items = [i for i in community.products(core.db, core.settings, request.state.viewer, active_only=False) if i["product"]["slug"] == request.path_params["slug"]]
    if not items:
        return redirect("/shop")
    return render(request, "community/product.html", item=items[0])


async def cart_add(request: Request):
    core = request.app.state.core
    f = await form_data(request)
    cart = community.cart_get(core.db, _cart_id(request))
    pid = fint(f, "product_id")
    p = core.db.get("products", pid) if pid else None
    if p is None or not p["is_active"]:
        return redirect("/shop", request, "product not found.", "error")
    if p["min_tier_rank"] and request.state.viewer.tier_rank < p["min_tier_rank"] and not request.state.viewer.is_admin:
        return redirect("/shop", request, "this item is for a higher tier.", "warn")
    qty = max(1, min(20, fint(f, "qty", 1) or 1))
    cart["items"].append({"product_id": pid, "qty": qty, "variant": fval(f, "variant") or None, "personalization": fval(f, "personalization")[:120] or None})
    cid = community.cart_save(core.db, cart, request.state.viewer.user_id)
    resp = redirect("/shop/cart", request, "added to cart.", "ok")
    resp.set_cookie("vx_cart", cid, max_age=30 * 86400, httponly=True, samesite="lax", secure=core.cfg.cookie_secure)
    return resp


async def cart_page(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    cart = community.cart_get(core.db, _cart_id(request))
    if request.method == "POST":
        f = await form_data(request)
        if fval(f, "action") == "remove":
            idx = fint(f, "idx")
            if idx is not None and 0 <= idx < len(cart["items"]):
                cart["items"].pop(idx)
                community.cart_save(core.db, cart, viewer.user_id)
            return redirect("/shop/cart")
        if fval(f, "action") == "checkout":
            country = fval(f, "country").upper()[:2]
            totals = community.cart_totals(core.db, core.settings, viewer, cart["items"], country)
            if not totals["lines"]:
                return redirect("/shop/cart", request, "cart is empty.", "warn")
            email = viewer.user["email"] if viewer.user else fval(f, "email")
            if not email:
                return redirect("/shop/cart", request, "email is required.", "error")
            shipping = {k: fval(f, k) for k in ("name", "address1", "address2", "city", "region", "postal", "country", "phone")} if totals["physical"] else {}
            if totals["physical"] and not (shipping.get("name") and shipping.get("address1") and shipping.get("city") and shipping.get("country")):
                return redirect("/shop/cart", request, "fill in the shipping address.", "error")
            order = community.create_shop_order(core.db, viewer.user_id, email, totals, shipping)
            try:
                p = core.payments.create_purchase(user_id=viewer.user_id, kind="shop", title=f"shop order {order['public_id']}", total_cents=totals["total_cents"], entity_type="shop_order",
                                                  entity_id=order["id"], audience=viewer.audience, use_credit=fbool(f, "use_credit"), guest_email=None if viewer.user else email,
                                                  ip=request.state.ip)
            except CapExceeded as exc:
                return _cap(request, exc)
            core.db.update("shop_orders", order["id"], purchase_id=p["id"])
            cart["items"] = []
            community.cart_save(core.db, cart, viewer.user_id)
            resp = redirect(f"/pay/{p['public_id']}")
            if not viewer.user:
                resp.set_cookie(f"guest_{p['public_id']}", p["public_id"], max_age=7 * 86400, httponly=True, samesite="lax", secure=core.cfg.cookie_secure)
            if p["total_cents"] == 0:
                await core.payments.finalize_zero(p)
            return resp
    country = request.query_params.get("country", request.state.country or "")
    totals = community.cart_totals(core.db, core.settings, viewer, cart["items"], country.upper()[:2] if country else None)
    return render(request, "community/cart.html", totals=totals, country=country)


@login_required
async def shop_orders(request: Request):
    core = request.app.state.core
    rows = core.db.all("SELECT * FROM shop_orders WHERE user_id=? ORDER BY id DESC", (request.state.viewer.user_id,))
    return render(request, "community/shop_orders.html", rows=rows)


@login_required
async def shop_order(request: Request):
    core = request.app.state.core
    viewer = request.state.viewer
    o = core.db.one("SELECT * FROM shop_orders WHERE public_id=?", (request.path_params["public_id"],))
    if o is None or (o["user_id"] != viewer.user_id and not viewer.is_admin):
        return redirect("/shop/orders")
    items = loads(o["items_json"], [])
    downloads = []
    if o["status"] in ("delivered", "fulfilling", "shipped"):
        for it in items:
            if it.get("digital_media_id"):
                m = core.db.get("media", it["digital_media_id"])
                if m:
                    downloads.append((it["name"], core.media.download_token(m["id"], viewer.user_id, "shop", 24 * 3600, 5)))
    return render(request, "community/shop_order.html", o=o, items=items, shipping=loads(o["shipping_json"], {}), coa=loads(o["coa_json"], []), downloads=downloads)


# ================================================================== calendar
async def calendar_page(request: Request):
    core = request.app.state.core
    ts = now_ts()
    rows = core.db.all("SELECT * FROM calendar_events WHERE is_public=1 AND start_at>=? ORDER BY start_at LIMIT 100", (ts - 86400,))
    streams = core.db.all("SELECT id, title, scheduled_at, status FROM streams WHERE status IN ('scheduled','live') ORDER BY scheduled_at")
    drops_ = core.db.all("SELECT slug, title, starts_at FROM drops WHERE status IN ('scheduled','live') ORDER BY starts_at")
    return render(request, "community/calendar.html", rows=rows, streams=streams, drops=drops_)


async def calendar_ics(request: Request):
    core = request.app.state.core
    from .. import calls
    events = []
    for s in core.db.all("SELECT id, title, scheduled_at FROM streams WHERE status='scheduled'"):
        events.append({"uid": f"stream-{s['id']}@{core.cfg.site_domain}", "start_at": s["scheduled_at"], "end_at": s["scheduled_at"] + 3600, "title": f"live: {s['title']}"})
    for d in core.db.all("SELECT id, title, starts_at FROM drops WHERE status='scheduled'"):
        events.append({"uid": f"drop-{d['id']}@{core.cfg.site_domain}", "start_at": d["starts_at"], "end_at": d["starts_at"] + 3600, "title": f"drop: {d['title']}"})
    return PlainTextResponse(calls.ical(events, core.cfg.site_name), media_type="text/calendar")


routes = [
    Route("/tips", tips_page), Route("/tips/send", tip_send, methods=["POST"]), Route("/fund/{slug}", campaign), Route("/fund/{slug}/contribute", contribute, methods=["POST"]),
    Route("/channels", channels), Route("/channels/{slug}", channel_room), Route("/channels/{slug}/join", channel_join, methods=["POST"]),
    Route("/channels/{slug}/say", channel_say, methods=["POST"]), Route("/channels/{slug}/events", channel_events), Route("/channels/{slug}/chat", channel_fragment),
    Route("/drops", drops), Route("/drops/{slug}", drop_page), Route("/drops/{slug}/buy", drop_buy, methods=["POST"]),
    Route("/shop", shop), Route("/shop/cart", cart_page, methods=["GET", "POST"]), Route("/shop/cart/add", cart_add, methods=["POST"]),
    Route("/shop/orders", shop_orders), Route("/shop/orders/{public_id}", shop_order), Route("/shop/{slug}", product_page),
    Route("/calendar", calendar_page), Route("/calendar.ics", calendar_ics),
]
