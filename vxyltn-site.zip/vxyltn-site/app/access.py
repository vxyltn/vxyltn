"""Audience resolution and entitlements.

Three paying audiences:
  public      - no account or not following: pays public prices (member price x public_mult)
  follower    - free account that follows: pays follower prices (member price x follower_mult)
  subscriber  - active membership tier: member prices; content at or below the tier rank is included

Priority-list members ("VIP") and admins layer on top.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .money import ceil_mul
from .util import loads, now_ts

DEFAULT_PERKS = {
    "dm_price_cents": None,        # None = settings default
    "ppv_discount_pct": 0,
    "priority_eligible": False,
    "channel_ids": [],
    "call_access": True,
    "early_drop_hours": 0,
    "comments_free": True,
    "tip_min_cents": None,
    "custom_orders": True,
    "live_access": True,
}


def tier_perks(tier) -> dict:
    perks = dict(DEFAULT_PERKS)
    if tier is not None:
        perks.update({k: v for k, v in loads(tier["perks_json"], {}).items() if k in DEFAULT_PERKS})
    return perks


def active_membership(db, user_id: int | None, grace_days: int = 0):
    if not user_id:
        return None, None
    ts = now_ts()
    row = db.one(
        "SELECT m.*, t.rank AS tier_rank, t.name AS tier_name, t.perks_json, t.slug AS tier_slug FROM memberships m JOIN tiers t ON t.id=m.tier_id"
        " WHERE m.user_id=? AND m.status IN ('active','grace') AND COALESCE(m.grace_until, m.current_period_end)>?"
        " ORDER BY t.rank DESC, m.current_period_end DESC LIMIT 1", (user_id, ts))
    if row is None:
        return None, None
    tier = db.get("tiers", row["tier_id"])
    return row, tier


@dataclass
class Viewer:
    user: object = None
    session_raw: str | None = None
    membership: object = None
    tier: object = None
    perks: dict = field(default_factory=lambda: dict(DEFAULT_PERKS))
    preview_pass_until: int | None = None
    twofa_ok: bool = False

    @property
    def user_id(self) -> int | None:
        return int(self.user["id"]) if self.user is not None else None

    @property
    def is_admin(self) -> bool:
        return self.user is not None and self.user["role"] == "admin"

    @property
    def is_member(self) -> bool:
        return self.membership is not None

    @property
    def tier_rank(self) -> int:
        return int(self.membership["tier_rank"]) if self.membership is not None else 0

    @property
    def is_follower(self) -> bool:
        return self.user is not None and bool(self.user["is_follower"])

    @property
    def is_priority(self) -> bool:
        return self.user is not None and self.user["priority_status"] == "approved"

    @property
    def audience(self) -> str:
        if self.is_admin or self.is_member:
            return "subscriber"
        if self.is_follower:
            return "follower"
        return "public"

    @property
    def has_preview_pass(self) -> bool:
        return bool(self.preview_pass_until and self.preview_pass_until > now_ts())

    @property
    def email_verified(self) -> bool:
        return self.user is not None and bool(self.user["email_verified_at"])


def resolve_viewer(db, settings, user, session_raw: str | None, twofa_ok: bool = False) -> Viewer:
    v = Viewer(user=user, session_raw=session_raw, twofa_ok=twofa_ok)
    if user is not None:
        grace = settings.int("membership_grace_days")
        v.membership, v.tier = active_membership(db, user["id"], grace)
        v.perks = tier_perks(v.tier)
        pp = db.one("SELECT expires_at FROM unlocks WHERE user_id=? AND entity_type='preview_pass' AND expires_at>? ORDER BY expires_at DESC LIMIT 1",
                    (user["id"], now_ts()))
        v.preview_pass_until = pp["expires_at"] if pp else None
    return v


def price_for(settings, viewer: Viewer, member_cents: int | None, public_cents: int | None = None,
              follower_cents: int | None = None, min_tier_rank: int = 0, included_for_tier: bool = True) -> int:
    """Price the viewer pays. 0 means included/free. member_cents None means not for sale."""
    if member_cents is None:
        return -1
    if viewer.is_admin:
        return 0
    if included_for_tier and viewer.is_member and viewer.tier_rank >= min_tier_rank and min_tier_rank > 0:
        return 0
    if viewer.audience == "subscriber":
        disc = int(viewer.perks.get("ppv_discount_pct") or 0)
        price = max(0, member_cents - (member_cents * disc) // 100) if disc else member_cents
    elif viewer.audience == "follower":
        price = follower_cents if follower_cents is not None else ceil_mul(member_cents, float(settings.get("follower_mult")))
    else:
        price = public_cents if public_cents is not None else ceil_mul(member_cents, float(settings.get("public_mult")))
    return apply_floor(settings, price)


def apply_floor(settings, cents: int) -> int:
    """Every in-app purchase starts at the platform minimum (1,000 by default). 0 stays 0 (included)."""
    if cents <= 0:
        return cents
    return max(cents, settings.int("platform_min_cents"))


def has_unlock(db, user_id: int | None, entity_type: str, entity_id: int) -> bool:
    if not user_id:
        return False
    row = db.one("SELECT 1 FROM unlocks WHERE user_id=? AND entity_type=? AND entity_id=? AND (expires_at IS NULL OR expires_at>?)",
                 (user_id, entity_type, entity_id, now_ts()))
    return row is not None


def post_access(db, settings, viewer: Viewer, post) -> dict:
    """Returns {'state': open|locked|preview|hidden, 'price_cents': int, 'reason': str}."""
    if viewer.is_admin:
        return {"state": "open", "price_cents": 0, "reason": "admin"}
    vis = post["visibility"]
    ts = now_ts()
    if post["published_at"] and post["published_at"] > ts and not viewer.is_admin:
        return {"state": "hidden", "price_cents": 0, "reason": "scheduled"}
    if post["expires_at"] and post["expires_at"] <= ts:
        return {"state": "hidden", "price_cents": 0, "reason": "expired"}
    if vis == "public":
        return {"state": "open", "price_cents": 0, "reason": "public"}
    if viewer.user_id and has_unlock(db, viewer.user_id, "post", post["id"]):
        return {"state": "open", "price_cents": 0, "reason": "unlocked"}
    if post["collection_id"] and viewer.user_id and has_unlock(db, viewer.user_id, "collection", post["collection_id"]):
        return {"state": "open", "price_cents": 0, "reason": "collection"}
    if vis == "follower":
        if viewer.is_follower or viewer.is_member:
            return {"state": "open", "price_cents": 0, "reason": "follower"}
        price = price_for(settings, viewer, post["ppv_price_cents"], post["public_price_cents"], post["follower_price_cents"], 0, False)
        return {"state": "locked" if price > 0 else "preview", "price_cents": max(price, 0), "reason": "follow"}
    if vis in ("member", "tier"):
        need = int(post["min_tier_rank"] or 0) if vis == "tier" else 1
        if viewer.is_member and viewer.tier_rank >= need:
            return {"state": "open", "price_cents": 0, "reason": "member"}
        price = price_for(settings, viewer, post["ppv_price_cents"], post["public_price_cents"], post["follower_price_cents"], 0, False)
        if post["ppv_price_cents"] is None:
            return {"state": "preview" if viewer.has_preview_pass else "locked", "price_cents": 0, "reason": "tier"}
        return {"state": "locked", "price_cents": price, "reason": "tier"}
    if vis == "ppv":
        price = price_for(settings, viewer, post["ppv_price_cents"] or 0, post["public_price_cents"], post["follower_price_cents"],
                          int(post["min_tier_rank"] or 0), True)
        if price == 0:
            return {"state": "open", "price_cents": 0, "reason": "included"}
        return {"state": "locked", "price_cents": price, "reason": "ppv"}
    return {"state": "locked", "price_cents": 0, "reason": vis}


def channel_access(db, viewer: Viewer, channel) -> bool:
    if viewer.is_admin:
        return True
    if not viewer.user_id:
        return False
    if db.one("SELECT 1 FROM channel_members WHERE channel_id=? AND user_id=?", (channel["id"], viewer.user_id)):
        return True
    kind = channel["kind"]
    if kind == "tier" and viewer.is_member and viewer.tier_rank >= int(channel["min_tier_rank"] or 0):
        return True
    if kind == "priority" and viewer.is_priority:
        return True
    return False


def stream_access(db, settings, viewer: Viewer, stream) -> dict:
    """{'ok': bool, 'price_cents': int, 'reason': str}"""
    if viewer.is_admin:
        return {"ok": True, "price_cents": 0, "reason": "admin"}
    mode = stream["access_mode"]
    if viewer.user_id and db.one("SELECT 1 FROM stream_tickets WHERE stream_id=? AND user_id=?", (stream["id"], viewer.user_id)):
        return {"ok": True, "price_cents": 0, "reason": "ticket"}
    if mode == "members":
        if viewer.is_member:
            return {"ok": True, "price_cents": 0, "reason": "member"}
    elif mode == "tier":
        if viewer.is_member and viewer.tier_rank >= int(stream["min_tier_rank"] or 0):
            return {"ok": True, "price_cents": 0, "reason": "tier"}
    elif mode == "priority":
        if viewer.is_priority:
            return {"ok": True, "price_cents": 0, "reason": "priority"}
        return {"ok": False, "price_cents": 0, "reason": "priority_only"}
    elif mode == "ticket":
        if not viewer.is_member and not viewer.is_follower:
            if stream["public_ticket_price_cents"]:
                return {"ok": False, "price_cents": int(stream["public_ticket_price_cents"]), "reason": "public_ticket"}
            return {"ok": False, "price_cents": 0, "reason": "members_only"}
        price = price_for(settings, viewer, stream["ticket_price_cents"] or 0, stream["public_ticket_price_cents"], None, 0, False)
        return {"ok": price == 0, "price_cents": price, "reason": "ticket"}
    elif mode == "public_ticket":
        price = price_for(settings, viewer, stream["ticket_price_cents"] or 0, stream["public_ticket_price_cents"], None, 0, False)
        return {"ok": price == 0, "price_cents": price, "reason": "ticket"}
    # fallthrough: offer a ticket if priced
    if stream["ticket_price_cents"]:
        price = price_for(settings, viewer, stream["ticket_price_cents"], stream["public_ticket_price_cents"], None, 0, False)
        return {"ok": False, "price_cents": price, "reason": "ticket"}
    return {"ok": False, "price_cents": 0, "reason": "members_only"}


def dm_price(settings, viewer: Viewer) -> int:
    if viewer.is_admin:
        return 0
    if viewer.is_member:
        p = viewer.perks.get("dm_price_cents")
        return apply_floor(settings, int(p) if p is not None else settings.int("dm_price_member_cents"))
    if viewer.is_follower:
        return apply_floor(settings, settings.int("dm_price_public_cents"))
    return apply_floor(settings, settings.int("public_question_cents"))


def tip_min(settings, viewer: Viewer) -> int:
    if viewer.is_priority:
        return max(settings.int("tip_min_vip_cents"), settings.int("platform_min_cents"))
    p = viewer.perks.get("tip_min_cents")
    return max(int(p) if p is not None else settings.int("tip_min_cents"), settings.int("platform_min_cents"))
