"""Analytics: revenue by source/tier/day, funnel, content performance, requests, top users."""
from __future__ import annotations

import statistics
from datetime import datetime, timedelta

from .money import usd
from .util import fmt_local, local_day_bounds, now_ts, pct

RANGES = ("today", "yesterday", "7d", "28d", "90d", "all")
KIND_LABELS = {
    "membership": "memberships", "bundle": "bundles", "upgrade": "upgrades", "post": "ppv posts", "collection": "collections",
    "comment_unlock": "comment unlocks", "media": "digital items", "dm": "paid dms", "public_question": "public questions",
    "message_unlock": "ppv messages", "message_pack": "message packs", "priority_dm": "priority dms", "stream_ticket": "live tickets",
    "pinned_chat": "pinned chat", "highlight_chat": "highlighted chat", "call": "calls", "custom_deposit": "custom deposits",
    "custom_balance": "custom balances", "custom_priority": "custom priority", "tip": "tips", "campaign": "fundraising",
    "channel": "channels", "drop": "drops", "shop": "shop", "preview_pass": "preview passes", "follower_badge": "follower badges",
    "wallet": "credit top-ups", "rq_activation": "request activations", "rq_order": "requests",
}


def range_bounds(core, key: str) -> tuple[int, int, str]:
    tz = core.tz
    if key == "today":
        s, e = local_day_bounds(tz, 0); return s, e, "today"
    if key == "yesterday":
        s, e = local_day_bounds(tz, 1); return s, e, "yesterday"
    if key == "7d":
        s, _ = local_day_bounds(tz, 6); _, e = local_day_bounds(tz, 0); return s, e, "last 7 days"
    if key == "28d":
        s, _ = local_day_bounds(tz, 27); _, e = local_day_bounds(tz, 0); return s, e, "last 28 days"
    if key == "90d":
        s, _ = local_day_bounds(tz, 89); _, e = local_day_bounds(tz, 0); return s, e, "last 90 days"
    _, e = local_day_bounds(tz, 0)
    return 0, e, "all time"


def build(core, since: int, until: int) -> dict:
    db, tz = core.db, core.tz
    r = (since, until)
    k: dict = {}
    k["revenue"] = int(db.scalar("SELECT COALESCE(SUM(amount_cents),0) FROM invoices WHERE status='paid' AND paid_at>=? AND paid_at<?", r))
    k["payments"] = int(db.scalar("SELECT COUNT(*) FROM invoices WHERE status='paid' AND paid_at>=? AND paid_at<?", r))
    k["purchases"] = int(db.scalar("SELECT COUNT(*) FROM purchases WHERE status='paid' AND paid_at>=? AND paid_at<?", r))
    k["payers"] = int(db.scalar("SELECT COUNT(DISTINCT user_id) FROM purchases WHERE status='paid' AND paid_at>=? AND paid_at<?", r))
    k["avg_purchase"] = k["revenue"] / k["purchases"] if k["purchases"] else 0
    k["arppu"] = k["revenue"] / k["payers"] if k["payers"] else 0
    k["new_users"] = int(db.scalar("SELECT COUNT(*) FROM users WHERE created_at>=? AND created_at<?", r))
    k["new_members"] = int(db.scalar("SELECT COUNT(*) FROM memberships WHERE created_at>=? AND created_at<?", r))
    k["active_members"] = int(db.scalar("SELECT COUNT(*) FROM memberships WHERE status IN ('active','grace') AND current_period_end>?", (now_ts(),)))
    k["followers"] = int(db.scalar("SELECT COUNT(*) FROM users WHERE is_follower=1 AND deleted_at IS NULL"))
    k["users"] = int(db.scalar("SELECT COUNT(*) FROM users WHERE deleted_at IS NULL"))
    k["pending_purchases"] = int(db.scalar("SELECT COUNT(*) FROM purchases WHERE status IN ('pending','partial')"))
    k["pending_amount"] = int(db.scalar("SELECT COALESCE(SUM(total_cents-paid_cents),0) FROM purchases WHERE status IN ('pending','partial')"))
    k["expired_purchases"] = int(db.scalar("SELECT COUNT(*) FROM purchases WHERE status IN ('expired','failed','canceled') AND created_at>=? AND created_at<?", r))
    k["rq_activations"] = int(db.scalar("SELECT COUNT(*) FROM rq_orders WHERE kind='activation' AND paid_at>=? AND paid_at<?", r))
    k["rq_requests"] = int(db.scalar("SELECT COUNT(*) FROM rq_orders WHERE kind<>'activation' AND status IN ('paid','expired') AND paid_at>=? AND paid_at<?", r))
    k["rq_revenue"] = int(db.scalar("SELECT COALESCE(SUM(total_cents),0) FROM rq_orders WHERE status IN ('paid','expired') AND paid_at>=? AND paid_at<?", r))
    k["rq_open"] = int(db.scalar("SELECT COUNT(*) FROM rq_orders WHERE status='paid' AND kind<>'activation' AND admin_status IN ('new','reviewed','in_progress')"))
    k["tips"] = int(db.scalar("SELECT COALESCE(SUM(amount_cents),0) FROM tips WHERE created_at>=? AND created_at<?", r))
    k["messages_in"] = int(db.scalar("SELECT COUNT(*) FROM messages WHERE sender_role='user' AND created_at>=? AND created_at<?", r))
    k["custom_open"] = int(db.scalar("SELECT COUNT(*) FROM custom_orders WHERE status NOT IN ('completed','declined','canceled')"))
    k["posts_published"] = int(db.scalar("SELECT COUNT(*) FROM posts WHERE published_at>=? AND published_at<? AND deleted_at IS NULL", r))
    k["post_views"] = int(db.scalar("SELECT COUNT(*) FROM post_views WHERE ts>=? AND ts<?", r))
    k["unlocks"] = int(db.scalar("SELECT COUNT(*) FROM unlocks WHERE created_at>=? AND created_at<?", r))
    k["kyc_required"] = int(db.scalar("SELECT COUNT(*) FROM users WHERE kyc_status='required'"))
    durations = [row[0] for row in db.all("SELECT paid_at-created_at FROM invoices WHERE status='paid' AND paid_at>=? AND paid_at<?", r) if row[0] is not None]
    k["median_pay_seconds"] = statistics.median(durations) if durations else 0

    by_kind = [dict(x) for x in db.all("SELECT kind, COUNT(*) n, COALESCE(SUM(total_cents),0) cents FROM purchases WHERE status='paid' AND paid_at>=? AND paid_at<? GROUP BY kind ORDER BY cents DESC", r)]
    by_tier = [dict(x) for x in db.all("SELECT t.name, COUNT(DISTINCT m.user_id) members, COALESCE(SUM(mp.price_cents),0) cents FROM membership_periods mp"
                                       " JOIN memberships m ON m.id=mp.membership_id JOIN tiers t ON t.id=m.tier_id WHERE mp.created_at>=? AND mp.created_at<? GROUP BY t.id ORDER BY cents DESC", r)]
    top_users = [dict(x) for x in db.all("SELECT p.user_id, u.email, u.username, COUNT(*) n, SUM(p.total_cents) cents, MAX(p.paid_at) last FROM purchases p"
                                         " LEFT JOIN users u ON u.id=p.user_id WHERE p.status='paid' AND p.paid_at>=? AND p.paid_at<? GROUP BY p.user_id ORDER BY cents DESC LIMIT 15", r)]
    content_top = [dict(x) for x in db.all("SELECT id, title, type, views_count, likes_count, comments_count, unlocks_count, revenue_cents FROM posts WHERE deleted_at IS NULL ORDER BY revenue_cents DESC, views_count DESC LIMIT 15")]
    rq_by_offer = [dict(x) for x in db.all("SELECT offer_name, COUNT(*) n, COALESCE(SUM(units),0) units, COALESCE(SUM(total_cents),0) cents FROM rq_orders WHERE status IN ('paid','expired') AND paid_at>=? AND paid_at<? GROUP BY offer_key ORDER BY cents DESC", r)]

    seen = int(db.scalar("SELECT COUNT(*) FROM users WHERE last_seen_at>=? AND created_at<?", r))
    followers = int(db.scalar("SELECT COUNT(*) FROM users WHERE last_seen_at>=? AND created_at<? AND is_follower=1", r))
    paid = int(db.scalar("SELECT COUNT(DISTINCT user_id) FROM purchases WHERE status='paid' AND paid_at>=? AND paid_at<?", r))
    member = int(db.scalar("SELECT COUNT(DISTINCT user_id) FROM memberships WHERE created_at>=? AND created_at<?", r))
    funnel = {"seen": seen, "followers": followers, "paid": paid, "members": member, "followers_pct": pct(followers, seen), "paid_pct": pct(paid, followers), "members_pct": pct(member, paid)}

    daily = []
    start_day = datetime.fromtimestamp(max(since, until - 90 * 86400) if since else until - 28 * 86400, tz).date()
    end_day = datetime.fromtimestamp(until - 1, tz).date()
    day = start_day
    while day <= end_day:
        ds = int(datetime(day.year, day.month, day.day, tzinfo=tz).timestamp())
        de = int((datetime(day.year, day.month, day.day, tzinfo=tz) + timedelta(days=1)).timestamp())
        daily.append({"day": day.isoformat(),
                      "revenue": int(db.scalar("SELECT COALESCE(SUM(amount_cents),0) FROM invoices WHERE status='paid' AND paid_at>=? AND paid_at<?", (ds, de))),
                      "purchases": int(db.scalar("SELECT COUNT(*) FROM purchases WHERE status='paid' AND paid_at>=? AND paid_at<?", (ds, de))),
                      "new_users": int(db.scalar("SELECT COUNT(*) FROM users WHERE created_at>=? AND created_at<?", (ds, de))),
                      "new_members": int(db.scalar("SELECT COUNT(*) FROM memberships WHERE created_at>=? AND created_at<?", (ds, de)))})
        day += timedelta(days=1)

    return {"range": {"since": since, "until": until}, "kpis": k, "by_kind": by_kind, "by_tier": by_tier, "top_users": top_users,
            "content_top": content_top, "rq_by_offer": rq_by_offer, "funnel": funnel, "daily": daily}


def for_pdf(core, rep: dict) -> dict:
    """Shape the report into generic table blocks for pdfgen.build_report_pdf."""
    k = rep["kpis"]
    out = {"range": rep["range"], "kpis": k, "kpi_rows": [
        ("revenue", usd(k["revenue"])), ("payments / purchases", f"{k['payments']} / {k['purchases']}"), ("payers", str(k["payers"])),
        ("average purchase / per payer", f"{usd(int(k['avg_purchase']))} / {usd(int(k['arppu']))}"), ("new users / new members", f"{k['new_users']} / {k['new_members']}"),
        ("active members / followers / users", f"{k['active_members']} / {k['followers']} / {k['users']}"),
        ("pending purchases", f"{k['pending_purchases']} ({usd(k['pending_amount'])})"), ("expired / canceled", str(k["expired_purchases"])),
        ("request activations / requests / revenue", f"{k['rq_activations']} / {k['rq_requests']} / {usd(k['rq_revenue'])}"), ("open requests", str(k["rq_open"])),
        ("tips", usd(k["tips"])), ("messages received", str(k["messages_in"])), ("open custom orders", str(k["custom_open"])),
        ("posts published / views / unlocks", f"{k['posts_published']} / {k['post_views']} / {k['unlocks']}"), ("kyc required", str(k["kyc_required"])),
        ("median time to pay", f"{k['median_pay_seconds']:,.0f}s")]}
    out["by_kind"] = {"title": "revenue by source", "columns": ["source", "purchases", "revenue"], "rows": [[KIND_LABELS.get(x["kind"], x["kind"]), x["n"], usd(x["cents"])] for x in rep["by_kind"]]}
    out["by_tier"] = {"title": "memberships by tier", "columns": ["tier", "members", "revenue"], "rows": [[x["name"], x["members"], usd(x["cents"])] for x in rep["by_tier"]]}
    out["by_day"] = {"title": "daily", "columns": ["day", "revenue", "purchases", "new users", "new members"], "rows": [[d["day"], usd(d["revenue"]), d["purchases"], d["new_users"], d["new_members"]] for d in rep["daily"]]}
    out["top_users"] = {"title": "top users", "columns": ["user", "purchases", "revenue", "last"], "rows": [[f"#{x['user_id']} {x['email'] or ''}", x["n"], usd(x["cents"]), fmt_local(x["last"], core.tz)] for x in rep["top_users"]]}
    f = rep["funnel"]
    out["funnel"] = {"title": "funnel (active in range)", "columns": ["stage", "users", "of previous"], "rows": [["seen", f["seen"], "-"], ["followers", f["followers"], f["followers_pct"]], ["paid", f["paid"], f["paid_pct"]], ["members", f["members"], f["members_pct"]]]}
    out["content_top"] = {"title": "top content", "columns": ["post", "views", "likes", "comments", "unlocks", "revenue"], "rows": [[f"#{x['id']} {x['title'] or x['type']}", x["views_count"], x["likes_count"], x["comments_count"], x["unlocks_count"], usd(x["revenue_cents"])] for x in rep["content_top"]]}
    out["requests_by_offer"] = {"title": "requests by offer", "columns": ["offer", "requests", "units", "revenue"], "rows": [[x["offer_name"], x["n"], x["units"], usd(x["cents"])] for x in rep["rq_by_offer"]]}
    return out


def text_summary(core, rep: dict, title: str) -> str:
    k = rep["kpis"]
    rng = rep["range"]
    lines = [title, f"{fmt_local(rng['since'], core.tz) if rng['since'] else 'start'} -> {fmt_local(rng['until'], core.tz)}", "",
             f"revenue {usd(k['revenue'])} | {k['purchases']} purchases | {k['payers']} payers | avg {usd(int(k['avg_purchase']))}",
             f"new users {k['new_users']} | new members {k['new_members']} | active members {k['active_members']}",
             f"requests: {k['rq_activations']} activations, {k['rq_requests']} requests, {usd(k['rq_revenue'])}; open {k['rq_open']}",
             f"tips {usd(k['tips'])} | messages in {k['messages_in']} | custom open {k['custom_open']}",
             f"pending {k['pending_purchases']} ({usd(k['pending_amount'])}) | kyc required {k['kyc_required']}"]
    if rep["by_kind"]:
        lines += ["", "by source:"] + [f"- {KIND_LABELS.get(x['kind'], x['kind'])}: {x['n']} / {usd(x['cents'])}" for x in rep["by_kind"][:12]]
    return "\n".join(lines)


def csv_rows(rep: dict) -> list[list]:
    rows = [["day", "revenue_cents", "purchases", "new_users", "new_members"]]
    rows += [[d["day"], d["revenue"], d["purchases"], d["new_users"], d["new_members"]] for d in rep["daily"]]
    rows.append([])
    rows.append(["kind", "purchases", "revenue_cents"])
    rows += [[x["kind"], x["n"], x["cents"]] for x in rep["by_kind"]]
    return rows
