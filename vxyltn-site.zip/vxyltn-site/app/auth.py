"""Authentication primitives: password hashing, sessions, CSRF, TOTP 2FA, one-time tokens.

No third-party crypto. scrypt for passwords (hashlib), HMAC-SHA256 signed
cookies, RFC 6238 TOTP, SHA-256 hashed one-time tokens.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import struct
import time
from urllib.parse import quote

from .util import now_ts, sha256, token_urlsafe

SESSION_COOKIE = "vx_session"
CSRF_COOKIE = "vx_csrf"


# ----------------------------------------------------------------- passwords
def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)
    return "scrypt$" + base64.b64encode(salt).decode() + "$" + base64.b64encode(dk).decode()


def verify_password(password: str, stored: str | None) -> bool:
    if not stored or not stored.startswith("scrypt$"):
        return False
    try:
        _, salt_b64, dk_b64 = stored.split("$")
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(dk_b64)
        dk = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)
        return hmac.compare_digest(dk, expected)
    except Exception:
        return False


def password_problems(pw: str) -> str | None:
    if len(pw) < 10:
        return "Password must be at least 10 characters."
    if pw.lower() == pw or pw.upper() == pw:
        return "Use both upper and lower case letters."
    if not any(ch.isdigit() for ch in pw):
        return "Include at least one digit."
    return None


# ----------------------------------------------------------------- signing
def sign(secret: str, value: str) -> str:
    mac = hmac.new(secret.encode("utf-8"), value.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"{value}.{mac}"


def unsign(secret: str, signed: str | None) -> str | None:
    if not signed or "." not in signed:
        return None
    value, mac = signed.rsplit(".", 1)
    expected = hmac.new(secret.encode("utf-8"), value.encode("utf-8"), hashlib.sha256).hexdigest()
    return value if hmac.compare_digest(mac, expected) else None


# ----------------------------------------------------------------- sessions
def create_session(db, user_id: int, days: int, ip: str, user_agent: str, twofa_ok: bool = False) -> str:
    raw = token_urlsafe(32)
    sid = sha256(raw)
    ts = now_ts()
    db.insert("sessions", id=sid, user_id=user_id, created_at=ts, expires_at=ts + days * 86400, last_seen_at=ts,
              ip=ip, user_agent=(user_agent or "")[:300], twofa_ok=1 if twofa_ok else 0)
    return raw


def load_session(db, raw: str | None):
    if not raw:
        return None
    row = db.one("SELECT * FROM sessions WHERE id=? AND revoked_at IS NULL AND expires_at>?", (sha256(raw), now_ts()))
    return row


def revoke_session(db, raw: str | None) -> None:
    if raw:
        db.execute("UPDATE sessions SET revoked_at=? WHERE id=?", (now_ts(), sha256(raw)))


def revoke_all_sessions(db, user_id: int, except_raw: str | None = None) -> None:
    keep = sha256(except_raw) if except_raw else None
    db.execute("UPDATE sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL AND (? IS NULL OR id<>?)",
               (now_ts(), user_id, keep, keep))


# ----------------------------------------------------------------- CSRF
def csrf_token(secret: str, session_raw: str | None) -> str:
    base = session_raw or "anon"
    return hmac.new(secret.encode("utf-8"), f"csrf:{base}".encode("utf-8"), hashlib.sha256).hexdigest()[:40]


def csrf_ok(secret: str, session_raw: str | None, submitted: str | None) -> bool:
    return bool(submitted) and hmac.compare_digest(csrf_token(secret, session_raw), submitted or "")


# ----------------------------------------------------------------- TOTP
def _b32_secret() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode("ascii").rstrip("=")


def totp_new_secret() -> str:
    return _b32_secret()


def totp_code(secret_b32: str, for_time: int | None = None, step: int = 30, digits: int = 6) -> str:
    key = base64.b32decode(secret_b32 + "=" * (-len(secret_b32) % 8), casefold=True)
    counter = int((for_time if for_time is not None else time.time()) // step)
    msg = struct.pack(">Q", counter)
    digest = hmac.new(key, msg, hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    code = (struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF) % (10 ** digits)
    return f"{code:0{digits}d}"


def totp_verify(secret_b32: str, code: str | None, window: int = 1) -> bool:
    if not code or not secret_b32:
        return False
    code = code.strip().replace(" ", "")
    now = int(time.time())
    for w in range(-window, window + 1):
        if hmac.compare_digest(totp_code(secret_b32, now + w * 30), code):
            return True
    return False


def totp_uri(secret_b32: str, account: str, issuer: str) -> str:
    return f"otpauth://totp/{quote(issuer)}:{quote(account)}?secret={secret_b32}&issuer={quote(issuer)}&digits=6&period=30"


def recovery_codes(n: int = 8) -> list[str]:
    return [f"{secrets.token_hex(2)}-{secrets.token_hex(2)}-{secrets.token_hex(2)}" for _ in range(n)]


def hash_codes(codes: list[str]) -> list[str]:
    return [sha256(c) for c in codes]


def use_recovery_code(hashed: list[str], code: str) -> list[str] | None:
    h = sha256(code.strip().lower())
    if h in hashed:
        return [x for x in hashed if x != h]
    return None


# ----------------------------------------------------------------- one-time tokens
def issue_token(db, kind: str, user_id: int | None, email: str | None, ttl_seconds: int, with_code: bool = False, meta: dict | None = None) -> tuple[str, str | None]:
    raw = token_urlsafe(32)
    code = f"{secrets.randbelow(10 ** 6):06d}" if with_code else None
    import json
    db.insert("email_tokens", user_id=user_id, email=email, kind=kind, token_hash=sha256(raw), code=code,
              expires_at=now_ts() + ttl_seconds, created_at=now_ts(), meta_json=json.dumps(meta or {}))
    return raw, code


def consume_token(db, kind: str, raw: str | None = None, code: str | None = None, email: str | None = None, user_id: int | None = None):
    """Returns the token row (and marks it used) or None."""
    ts = now_ts()
    if raw:
        row = db.one("SELECT * FROM email_tokens WHERE kind=? AND token_hash=? AND used_at IS NULL AND expires_at>?", (kind, sha256(raw), ts))
    elif code:
        where, params = ["kind=?", "code=?", "used_at IS NULL", "expires_at>?"], [kind, code.strip(), ts]
        if email:
            where.append("lower(email)=lower(?)"); params.append(email)
        if user_id:
            where.append("user_id=?"); params.append(user_id)
        row = db.one(f"SELECT * FROM email_tokens WHERE {' AND '.join(where)} ORDER BY id DESC LIMIT 1", params)
    else:
        return None
    if row is None:
        return None
    db.execute("UPDATE email_tokens SET used_at=? WHERE id=?", (ts, row["id"]))
    return row
