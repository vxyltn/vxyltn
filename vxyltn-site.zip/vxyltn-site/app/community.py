"""Tips & fundraising, private channels, drops, shop (merch), audience products.

Smaller domains grouped in one module; each section has its own fulfilment helpers used by app.fulfill.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone

from .access import price_for
from .messaging import publish
from .money import usd
from .util import loads, now_ts, token_urlsafe


# ================================================================== tips & fundraising
def record_tip(core, user_id: int | None, amount_cents: int, purchase_id: int | None, context_type: str, context_id: int | None,
               message: str | None, anonymous: bool) -> int:
    db = core.db
    tid = db.insert("tips", user_id=user_id, amount_cents=amount_cents, purchase_id=purchase_id, context_type=context_type,
                    context_id=context_id, message=(message or "")[:500], anonymous=1 if anonymous else 0, created_at=now_ts())
    if context_type == "stream" and context_id:
        from .live import add_tip
        add_tip(db, context_id, user_id, amount_cents, message)
    if context_type == "campaign" and context_id:
        contribute(core, context_id, user_id, amount_cents, purchase_id, public=not anonymous)
    # first-tip incentive
    if user_id:
        prior = db.count("tips", "user_id=? AND id<>?", (user_id, tid))
        bonus_pct = core.settings.int("first_tip_bonus_pct")
        if prior == 0 and bonus_pct:
            credit = amount_cents * bonus_pct // 100
            if credit:
                db.wallet_apply(user_id, credit, "first tip bonus", "tip", tid)
                db.notify(user_id, "tip", "First tip bonus", f"{usd(credit)} credit added.", "/account")
    return tid


def leaderboard(db, days: int = 28, limit: int = 10) -> list[dict]:
    since = now_ts() - days * 86400
    rows = db.all("SELECT t.user_id, t.anonymous, u.username, u.display_name, SUM(t.amount_cents) total, COUNT(*) n FROM tips t"
                  " LEFT JOIN users u ON u.id=t.user_id WHERE t.created_at>? GROUP BY t.user_id ORDER BY total DESC LIMIT ?", (since, limit))
    out = []
    for i, r in enumerate(rows, start=1):
        name = "Anonymous" if r["anonymous"] or not r["user_id"] else (r["display_name"] or r["username"] or f"Member #{r['user_id']}")
        out.append({"rank": i, "name": name, "total_cents": int(r["total"]), "n": int(r["n"])})
    return out


def campaigns_active(db) -> list[sqlite3.Row]:
    ts = now_ts()
    return db.all("SELECT * FROM campaigns WHERE status='active' AND (starts_at IS NULL OR starts_at<=?) AND (ends_at IS NULL OR ends_at>?) ORDER BY id DESC", (ts, ts))


def contribute(core, campaign_id: int, user_id: int | None, amount_cents: int, purchase_id: int | None, public: bool) -> None:
    db = core.db
    c = db.get("campaigns", campaign_id)
    if c is None:
        return
    db.insert("campaign_contributions", campaign_id=campaign_id, user_id=user_id, amount_cents=amount_cents, purchase_id=purchase_id,
              is_public=1 if public else 0, created_at=now_ts())
    raised = int(c["raised_cents"]) + amount_cents
    milestones = loads(c["milestones_json"], [])
    hit = []
    for m in milestones:
        if not m.get("hit") and raised >= int(m.get("cents", 0)):
            m["hit"] = True
            m["hit_at"] = now_ts()
            hit.append(m)
    status = c["status"]
    if raised >= int(c["goal_cents"]) and status == "active" and not c["ends_at"]:
        status = "funded"
    db.update("campaigns", campaign_id, raised_cents=raised, milestones_json=json.dumps(milestones), status=status)
    for m in hit:
        for r in db.all("SELECT DISTINCT user_id FROM campaign_contributions WHERE campaign_id=? AND user_id IS NOT NULL", (campaign_id,)):
            db.notify(r["user_id"], "campaign", f"Milestone reached: {m.get('label', '')}", m.get("reward", ""), f"/fund/{c['slug']}")


def campaign_donors(db, campaign_id: int, limit: int = 50) -> list[sqlite3.Row]:
    return db.all("SELECT cc.amount_cents, cc.created_at, u.username, u.display_name FROM campaign_contributions cc LEFT JOIN users u ON u.id=cc.user_id"
                  " WHERE cc.campaign_id=? AND cc.is_public=1 ORDER BY cc.amount_cents DESC LIMIT ?", (campaign_id, limit))


# ================================================================== channels
def channels_visible(db, viewer) -> list[dict]:
    from .access import channel_access
    out = []
    for c in db.all("SELECT * FROM channels WHERE is_active=1 AND (expires_at IS NULL OR expires_at>?) ORDER BY id", (now_ts(),)):
        members = db.count("channel_members", "channel_id=?", (c["id"],))
        out.append({"channel": c, "access": channel_access(db, viewer, c), "members": members,
                    "full": bool(c["member_cap"]) and members >= int(c["member_cap"])})
    return out


def join_channel(db, channel_id: int, user_id: int, purchase_id: int | None, role: str = "member") -> None:
    db.execute("INSERT OR IGNORE INTO channel_members(channel_id, user_id, role, purchase_id, joined_at) VALUES (?,?,?,?,?)",
               (channel_id, user_id, role, purchase_id, now_ts()))


def channel_feed(db, channel_id: int, limit: int = 50) -> list[sqlite3.Row]:
    return db.all("SELECT p.*, m.kind AS media_kind FROM channel_posts p LEFT JOIN media m ON m.id=p.media_id WHERE p.channel_id=? ORDER BY p.id DESC LIMIT ?", (channel_id, limit))


def channel_chat(db, channel_id: int, after_id: int = 0, limit: int = 200) -> list[sqlite3.Row]:
    return db.all("SELECT c.*, u.username, u.display_name, u.role, u.priority_status FROM channel_chat c LEFT JOIN users u ON u.id=c.user_id"
                  " WHERE c.channel_id=? AND c.id>? AND c.hidden=0 ORDER BY c.id LIMIT ?", (channel_id, after_id, limit))


def channel_say(db, channel_id: int, user_id: int | None, body: str, media_id: int | None = None) -> int:
    cid = db.insert("channel_chat", channel_id=channel_id, user_id=user_id, body=body[:1000], media_id=media_id, created_at=now_ts())
    publish(f"channel:{channel_id}", {"type": "chat", "id": cid})
    return cid


# ================================================================== drops
def drops_list(db, settings, viewer, include_ended: bool = False) -> list[dict]:
    where = "" if include_ended else "WHERE status IN ('scheduled','live','sold_out')"
    return [drop_state(db, settings, viewer, d) for d in db.all(f"SELECT * FROM drops {where} ORDER BY starts_at DESC")]


def drop_state(db, settings, viewer, d: sqlite3.Row) -> dict:
    ts = now_ts()
    early = int(d["early_access_hours"] or 0) * 3600
    perks_early = int(viewer.perks.get("early_drop_hours") or 0) * 3600 if viewer.is_member else 0
    starts = int(d["starts_at"] or 0)
    opens_for_me = starts - (early if viewer.is_priority else perks_early)
    included = viewer.is_member and viewer.tier_rank in loads(d["included_tier_ranks_json"], [])
    price = 0 if included else price_for(settings, viewer, int(d["price_cents"]), d["public_price_cents"], d["follower_price_cents"], 0, False)
    sold_out = bool(d["quantity_cap"]) and int(d["sold"]) >= int(d["quantity_cap"])
    ended = bool(d["ends_at"]) and int(d["ends_at"]) < ts
    locked_tier = int(d["min_tier_rank"] or 0) > viewer.tier_rank and not viewer.is_admin
    owned = viewer.user_id and db.one("SELECT 1 FROM unlocks WHERE user_id=? AND entity_type='drop' AND entity_id=?", (viewer.user_id, d["id"]))
    on_waitlist = viewer.user_id and db.one("SELECT 1 FROM drop_waitlist WHERE drop_id=? AND user_id=?", (d["id"], viewer.user_id))
    state = "owned" if owned else "ended" if ended else "sold_out" if sold_out else "tier_locked" if locked_tier else "early" if ts < opens_for_me else "open"
    return {"drop": d, "state": state, "price_cents": price, "opens_at": opens_for_me, "included": included, "on_waitlist": bool(on_waitlist),
            "media": [m for m in (db.get("media", i) for i in loads(d["media_ids_json"], [])) if m]}


def grant_drop(db, drop_id: int, user_id: int, purchase_id: int | None) -> None:
    from .content import grant_unlock
    grant_unlock(db, user_id, "drop", drop_id, purchase_id)
    db.execute("UPDATE drops SET sold=sold+1 WHERE id=?", (drop_id,))
    d = db.get("drops", drop_id)
    if d["quantity_cap"] and d["sold"] >= d["quantity_cap"]:
        db.update("drops", drop_id, status="sold_out")


def drop_tick(db) -> None:
    ts = now_ts()
    for d in db.all("SELECT * FROM drops WHERE status='scheduled' AND starts_at<=?", (ts,)):
        db.update("drops", d["id"], status="live")
        for r in db.all("SELECT user_id FROM drop_waitlist WHERE drop_id=? AND notified_at IS NULL", (d["id"],)):
            db.notify(r["user_id"], "drop", f"Drop live: {d['title']}", "", f"/drops/{d['slug']}")
        db.execute("UPDATE drop_waitlist SET notified_at=? WHERE drop_id=?", (ts, d["id"]))
    for d in db.all("SELECT * FROM drops WHERE status IN ('live','scheduled') AND ends_at IS NOT NULL AND ends_at<=?", (ts,)):
        db.update("drops", d["id"], status="ended")


# ================================================================== shop
def products(db, settings, viewer, active_only: bool = True) -> list[dict]:
    where = "WHERE is_active=1" if active_only else ""
    out = []
    for p in db.all(f"SELECT * FROM products {where} ORDER BY id DESC"):
        price = price_for(settings, viewer, int(p["price_cents"]), p["public_price_cents"], p["follower_price_cents"], 0, False)
        out.append({"product": p, "price_cents": price, "media": [m for m in (db.get("media", i) for i in loads(p["media_ids_json"], [])) if m],
                    "variants": loads(p["variants_json"], []), "in_stock": p["inventory"] is None or int(p["inventory"]) > 0,
                    "tier_locked": int(p["min_tier_rank"] or 0) > viewer.tier_rank and not viewer.is_admin})
    return out


def cart_get(db, cart_id: str | None) -> dict:
    if cart_id:
        row = db.get("carts", cart_id)
        if row:
            return {"id": cart_id, "items": loads(row["items_json"], [])}
    return {"id": None, "items": []}


def cart_save(db, cart: dict, user_id: int | None) -> str:
    cid = cart.get("id") or token_urlsafe(16)
    db.execute("INSERT INTO carts(id, user_id, items_json, updated_at) VALUES (?,?,?,?) ON CONFLICT(id) DO UPDATE SET items_json=excluded.items_json, updated_at=excluded.updated_at, user_id=excluded.user_id",
               (cid, user_id, json.dumps(cart["items"]), now_ts()))
    return cid


def cart_totals(db, settings, viewer, items: list[dict], country: str | None) -> dict:
    lines, subtotal, weight = [], 0, 0
    classes = set()
    for it in items:
        p = db.get("products", it["product_id"])
        if p is None or not p["is_active"]:
            continue
        qty = max(1, int(it.get("qty", 1)))
        unit = price_for(settings, viewer, int(p["price_cents"]), p["public_price_cents"], p["follower_price_cents"], 0, False)
        line = unit * qty
        subtotal += line
        weight += int(p["weight_g"] or 0) * qty
        classes.add(p["shipping_class"])
        lines.append({"product": p, "qty": qty, "variant": it.get("variant"), "personalization": it.get("personalization"), "unit_cents": unit, "line_cents": line,
                      "tax_class": p["tax_class"], "kind": p["kind"]})
    physical = any(l["kind"] == "physical" for l in lines)
    shipping = 0
    if physical and country:
        for cls in classes:
            rate = db.one("SELECT * FROM shipping_rates WHERE shipping_class=? AND (countries_json LIKE ? OR zone='world') ORDER BY CASE WHEN zone='world' THEN 1 ELSE 0 END LIMIT 1",
                          (cls, f'%"{country}"%'))
            if rate:
                n_items = sum(l["qty"] for l in lines if l["product"]["shipping_class"] == cls)
                shipping += int(rate["price_cents"]) + int(rate["per_item_cents"]) * max(0, n_items - 1)
    tax = 0
    if country:
        for l in lines:
            tr = db.one("SELECT rate_pct FROM tax_rates WHERE country=? AND tax_class=? LIMIT 1", (country, l["tax_class"]))
            if tr:
                tax += int(round(l["line_cents"] * float(tr["rate_pct"]) / 100))
    return {"lines": lines, "subtotal_cents": subtotal, "shipping_cents": shipping, "tax_cents": tax, "total_cents": subtotal + shipping + tax, "physical": physical}


def create_shop_order(db, user_id: int | None, email: str | None, totals: dict, shipping: dict) -> sqlite3.Row:
    pid = db.public_id("SO", datetime.now(timezone.utc).year)
    items = [{"product_id": l["product"]["id"], "name": l["product"]["name"], "qty": l["qty"], "variant": l["variant"], "personalization": l["personalization"],
              "unit_cents": l["unit_cents"], "line_cents": l["line_cents"], "kind": l["kind"], "coa": bool(l["product"]["coa"]),
              "digital_media_id": l["product"]["digital_media_id"]} for l in totals["lines"]]
    oid = db.insert("shop_orders", public_id=pid, user_id=user_id, email=email, items_json=json.dumps(items), subtotal_cents=totals["subtotal_cents"],
                    tax_cents=totals["tax_cents"], shipping_cents=totals["shipping_cents"], total_cents=totals["total_cents"],
                    shipping_json=json.dumps(shipping), status="pending", created_at=now_ts())
    return db.get("shop_orders", oid)


def on_shop_order_paid(core, order_id: int, purchase_id: int) -> None:
    db = core.db
    o = db.get("shop_orders", order_id)
    items = loads(o["items_json"], [])
    coa = []
    for it in items:
        p = db.get("products", it["product_id"])
        if p and p["inventory"] is not None:
            db.execute("UPDATE products SET inventory=MAX(0, inventory-?) WHERE id=?", (it["qty"], p["id"]))
            p2 = db.get("products", p["id"])
            if p2["inventory"] <= p2["low_stock_at"]:
                db.audit("product.low_stock", entity_type="product", entity_id=p["id"], data={"inventory": p2["inventory"]})
        if it.get("coa"):
            for _ in range(int(it["qty"])):
                coa.append({"product": it["name"], "serial": f"VX-COA-{db.next_counter('coa'):06d}", "issued_at": now_ts()})
        if it.get("digital_media_id") and o["user_id"]:
            from .content import grant_unlock
            grant_unlock(db, o["user_id"], "media", int(it["digital_media_id"]), purchase_id)
    status = "fulfilling" if any(it["kind"] == "physical" for it in items) else "delivered"
    db.update("shop_orders", order_id, status=status, purchase_id=purchase_id, coa_json=json.dumps(coa), updated_at=now_ts())
    if o["user_id"]:
        db.notify(o["user_id"], "shop", f"Order {o['public_id']} paid", "Digital items are available now; physical items ship soon." if status == "fulfilling" else "Downloads are available.", f"/shop/orders/{o['public_id']}")


# ================================================================== audience products
def grant_preview_pass(db, settings, user_id: int, purchase_id: int | None) -> None:
    db.insert("unlocks", user_id=user_id, entity_type="preview_pass", entity_id=0, purchase_id=purchase_id, created_at=now_ts(),
              expires_at=now_ts() + settings.int("preview_pass_hours") * 3600)


def grant_follower_badge(db, user_id: int) -> None:
    db.execute("UPDATE users SET follower_badge=1, is_follower=1, followed_at=COALESCE(followed_at, ?) WHERE id=?", (now_ts(), user_id))
