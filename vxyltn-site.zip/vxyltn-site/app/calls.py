"""Calls: availability slots, prepaid bookings, join links, reminders, iCal export."""
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

from .util import now_ts, token_urlsafe


def open_slots(db, viewer, kind: str | None = None, days: int = 60) -> list[sqlite3.Row]:
    ts = now_ts()
    where, params = ["status='open'", "start_at>?", "start_at<?"], [ts, ts + days * 86400]
    if kind:
        where.append("kind=?"); params.append(kind)
    rows = db.all(f"SELECT * FROM call_slots WHERE {' AND '.join(where)} ORDER BY start_at", params)
    out = []
    for s in rows:
        if s["priority_only"] and not viewer.is_priority and not viewer.is_admin:
            continue
        if int(s["min_tier_rank"] or 0) > viewer.tier_rank and not viewer.is_admin:
            continue
        out.append(s)
    return out


def slot_price(slot: sqlite3.Row) -> int:
    if slot["price_cents"]:
        return int(slot["price_cents"])
    if slot["per_minute_cents"]:
        return int(slot["per_minute_cents"]) * int(slot["duration_min"])
    return 0


def book(db, slot_id: int, user_id: int, notes: str, record: bool) -> int:
    slot = db.get("call_slots", slot_id)
    if slot is None or slot["status"] != "open":
        raise ValueError("Slot not available")
    db.update("call_slots", slot_id, status="held")
    bid = db.insert("call_bookings", slot_id=slot_id, user_id=user_id, kind=slot["kind"], status="pending_payment",
                    record=1 if record else 0, user_notes=notes[:2000], created_at=now_ts())
    return bid


def confirm(core, booking_id: int, purchase_id: int | None) -> None:
    db = core.db
    b = db.get("call_bookings", booking_id)
    if b is None:
        return
    slot = db.get("call_slots", b["slot_id"])
    join_url = b["join_url"]
    if not join_url and core.cfg.call_provider == "jitsi":
        join_url = f"{core.cfg.jitsi_base.rstrip('/')}/vx-{slot['kind']}-{booking_id}-{token_urlsafe(6)}"
    db.update("call_bookings", booking_id, status="confirmed", purchase_id=purchase_id, join_url=join_url, updated_at=now_ts())
    db.update("call_slots", b["slot_id"], status="booked")
    db.insert("calendar_events", kind="call", ref_type="call_booking", ref_id=booking_id, title=f"{slot['kind']} call booking #{booking_id}",
              start_at=slot["start_at"], end_at=slot["end_at"], created_at=now_ts())
    db.notify(b["user_id"], "call", "Call booked", f"{core.local(slot['start_at'])}. Join link in your bookings.", "/calls/mine")


def release_stale_holds(db, minutes: int = 30) -> int:
    cutoff = now_ts() - minutes * 60
    rows = db.all("SELECT * FROM call_bookings WHERE status='pending_payment' AND created_at<?", (cutoff,))
    for b in rows:
        db.update("call_bookings", b["id"], status="canceled", updated_at=now_ts())
        db.execute("UPDATE call_slots SET status='open' WHERE id=? AND status='held'", (b["slot_id"],))
    return len(rows)


def due_reminders(core) -> int:
    db = core.db
    ts = now_ts()
    n = 0
    for b in db.all("SELECT b.*, s.start_at FROM call_bookings b JOIN call_slots s ON s.id=b.slot_id WHERE b.status='confirmed' AND s.start_at BETWEEN ? AND ?",
                    (ts, ts + 24 * 3600)):
        sent = set((b["reminders_json"] or "").split(","))
        key = "24h" if b["start_at"] - ts > 3600 else "1h"
        if key in sent:
            continue
        db.notify(b["user_id"], "call", "Upcoming call", f"Starts {core.local(b['start_at'])}.", "/calls/mine")
        sent.add(key)
        db.update("call_bookings", b["id"], reminders_json=",".join(x for x in sent if x))
        n += 1
    return n


def ical(rows: list[sqlite3.Row], title: str) -> str:
    def fmt(ts):
        return datetime.fromtimestamp(int(ts), timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", f"PRODID:-//{title}//EN", "CALSCALE:GREGORIAN"]
    for r in rows:
        lines += ["BEGIN:VEVENT", f"UID:{r['uid']}", f"DTSTAMP:{fmt(now_ts())}", f"DTSTART:{fmt(r['start_at'])}",
                  f"DTEND:{fmt(r['end_at'] or int(r['start_at']) + 3600)}", f"SUMMARY:{r['title']}", "END:VEVENT"]
    lines.append("END:VCALENDAR")
    return "\r\n".join(lines) + "\r\n"
