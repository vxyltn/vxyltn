"""Purchase lifecycle: create -> hosted crypto checkout (NOWPayments) -> IPN/poll -> paid -> fulfill.

A purchase is any paid thing on the site (membership period, PPV unlock, tip, DM, call,
custom order deposit, drop, shop order, request-system activation/order, ...).
It can be split into sequential invoice parts when a per-invoice maximum is set.
All amounts are integer USD cents. Payments are prepayments and final.
"""
from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime, timezone
from typing import Any

from .money import split_amount, usd, usd_plain
from .nowpayments import DEAD, verify_ipn
from .util import now_ts

log = logging.getLogger(__name__)


class CapExceeded(Exception):
    def __init__(self, total_cents: int, cap_cents: int):
        super().__init__(f"Amount {usd(total_cents)} exceeds the automated cap {usd(cap_cents)}")
        self.total_cents = total_cents
        self.cap_cents = cap_cents


class PaymentsNotConfigured(Exception):
    pass


NO_FLOOR_KINDS = {"campaign", "rq_activation", "rq_order"}   # contributions and the request system set their own amounts


class Payments:
    def __init__(self, core):
        self.core = core
        self.db = core.db
        self.cfg = core.cfg

    # ------------------------------------------------------------ create
    def create_purchase(self, *, user_id: int | None, kind: str, title: str, total_cents: int | None = None,
                        entity_type: str | None = None, entity_id: int | None = None, description: str = "",
                        quantity: int = 1, unit_price_cents: int | None = None, discount_cents: int = 0,
                        use_credit: bool = False, promo_id: int | None = None, audience: str | None = None,
                        tier_rank_at: int | None = None, meta: dict | None = None, parts_max_cents: int | None = None,
                        exempt_cap: bool = False, guest_email: str | None = None, ip: str | None = None,
                        ttl_seconds: int | None = None, floor: bool | None = None) -> sqlite3.Row:
        if unit_price_cents is None:
            unit_price_cents = total_cents if total_cents is not None else 0
        subtotal = int(unit_price_cents) * int(quantity)
        total = subtotal - int(discount_cents)
        if total_cents is not None and unit_price_cents == total_cents and quantity == 1 and not discount_cents:
            total = int(total_cents)
        if floor is None:
            floor = kind not in NO_FLOOR_KINDS
        if floor and total > 0:
            minimum = self.core.settings.int("platform_min_cents")
            if total < minimum:
                total = minimum
                subtotal = max(subtotal, minimum)
        credit_used = 0
        if use_credit and user_id:
            bal = int(self.db.scalar("SELECT wallet_cents FROM users WHERE id=?", (user_id,)))
            credit_used = max(0, min(bal, total))
            total -= credit_used
        if total < 0:
            total = 0
        cap = self.core.settings.int("platform_tx_cap_cents")
        if not exempt_cap and total > cap:
            raise CapExceeded(total, cap)
        year = datetime.now(timezone.utc).year
        public_id = self.db.public_id("PX", year)
        ts = now_ts()
        parts = split_amount(total, parts_max_cents or 0) if total > 0 else []
        with self.db.transaction():
            pid = self.db.insert(
                "purchases", public_id=public_id, user_id=user_id, guest_email=guest_email, kind=kind, entity_type=entity_type,
                entity_id=entity_id, title=title[:200], description=description[:1000], quantity=quantity,
                unit_price_cents=int(unit_price_cents), subtotal_cents=subtotal, discount_cents=int(discount_cents),
                credit_used_cents=credit_used, total_cents=total, currency="USD", status="pending", audience=audience,
                tier_rank_at=tier_rank_at, promo_id=promo_id, meta_json=json.dumps(meta or {}, default=str),
                parts_total=max(1, len(parts)), created_at=ts, updated_at=ts,
                expires_at=(ts + ttl_seconds) if ttl_seconds else None, ip=ip)
            for i, amount in enumerate(parts, start=1):
                self.db.insert("invoices", purchase_id=pid, part_no=i, amount_cents=amount, order_ref=f"{public_id}-{i}",
                               created_at=ts, updated_at=ts, expires_at=(ts + ttl_seconds) if ttl_seconds else None)
            if credit_used:
                self.db.wallet_apply(user_id, -credit_used, "purchase credit", "purchase", public_id)
            if promo_id:
                self.db.execute("UPDATE promo_codes SET uses=uses+1 WHERE id=?", (promo_id,))
                self.db.insert("promo_redemptions", promo_id=promo_id, user_id=user_id, purchase_id=pid, created_at=ts)
        self.db.audit("purchase.created", actor_user_id=user_id, actor_role="user", entity_type="purchase", entity_id=public_id, ip=ip,
                      data={"kind": kind, "total_cents": total, "parts": len(parts), "entity": f"{entity_type}:{entity_id}"})
        purchase = self.db.get("purchases", pid)
        return purchase

    async def finalize_zero(self, purchase: sqlite3.Row) -> sqlite3.Row:
        """A purchase fully covered by credit/discount: mark paid and fulfill immediately."""
        if purchase["total_cents"] == 0 and purchase["status"] != "paid":
            ts = now_ts()
            self.db.update("purchases", purchase["id"], status="paid", paid_at=ts, updated_at=ts, parts_paid=purchase["parts_total"])
            purchase = self.db.get("purchases", purchase["id"])
            await self._on_paid(purchase)
        return self.db.get("purchases", purchase["id"])

    # ------------------------------------------------------------ checkout
    def next_invoice(self, purchase_id: int) -> sqlite3.Row | None:
        return self.db.one("SELECT * FROM invoices WHERE purchase_id=? AND status IN ('pending','partial') ORDER BY part_no LIMIT 1", (purchase_id,))

    async def checkout_url(self, purchase: sqlite3.Row, reissue: bool = False) -> str:
        """Create (or reuse) the NOWPayments hosted invoice for the next unpaid part. Returns the URL to redirect to."""
        inv = self.next_invoice(purchase["id"])
        if inv is None:
            return f"/pay/{purchase['public_id']}"
        if inv["np_invoice_url"] and not reissue and inv["status"] == "pending" and inv["np_status"] not in DEAD:
            return inv["np_invoice_url"]
        if not self.core.np.enabled:
            raise PaymentsNotConfigured("NOWPAYMENTS_API_KEY is not set")
        desc = f"{self.cfg.site_name} {purchase['title']}"
        if purchase["parts_total"] > 1:
            desc += f" (part {inv['part_no']}/{purchase['parts_total']})"
        desc += " - request/prepayment, no refunds"
        order_ref = inv["order_ref"] if not reissue else f"{inv['order_ref']}r{now_ts() % 100000}"
        data = await self.core.np.create_invoice(
            amount_usd=usd_plain(inv["amount_cents"]), order_ref=order_ref, description=desc,
            ipn_url=self.core.url("/api/nowpayments/ipn"),
            success_url=self.core.url(f"/pay/{purchase['public_id']}?return=1"),
            cancel_url=self.core.url(f"/pay/{purchase['public_id']}?cancel=1"),
        )
        self.db.update("invoices", inv["id"], np_invoice_id=str(data.get("id")), np_invoice_url=data.get("invoice_url"),
                       np_status="created", status="pending", order_ref=order_ref, updated_at=now_ts(),
                       raw_json=json.dumps(data, default=str))
        self.db.audit("invoice.issued", actor_user_id=purchase["user_id"], actor_role="user", entity_type="invoice", entity_id=order_ref,
                      data={"np_invoice_id": data.get("id"), "amount_cents": inv["amount_cents"]})
        return data["invoice_url"]

    # ------------------------------------------------------------ IPN / status
    def _find_invoice(self, data: dict) -> sqlite3.Row | None:
        order_ref = str(data.get("order_id") or "")
        inv = self.db.one("SELECT * FROM invoices WHERE order_ref=?", (order_ref,)) if order_ref else None
        if inv is None and data.get("invoice_id"):
            inv = self.db.one("SELECT * FROM invoices WHERE np_invoice_id=?", (str(data["invoice_id"]),))
        if inv is None and data.get("payment_id"):
            inv = self.db.one("SELECT * FROM invoices WHERE np_payment_id=?", (str(data["payment_id"]),))
        return inv

    async def handle_ipn(self, body: bytes, signature: str | None, ip: str | None = None) -> dict:
        sig_ok = verify_ipn(self.cfg.np_ipn_secret, body, signature)
        try:
            data = json.loads(body.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {"ok": False, "reason": "bad json"}
        inv = self._find_invoice(data)
        self.db.insert("payment_events", invoice_id=inv["id"] if inv else None, np_payment_id=str(data.get("payment_id") or ""),
                       np_invoice_id=str(data.get("invoice_id") or ""), status=str(data.get("payment_status") or ""),
                       source="ipn", sig_ok=1 if sig_ok else 0, received_at=now_ts(), raw_json=body.decode("utf-8", "replace")[:20000])
        if inv is None:
            log.warning("IPN for unknown invoice: %s", {k: data.get(k) for k in ("order_id", "invoice_id", "payment_id")})
            return {"ok": False, "reason": "unknown invoice", "sig_ok": sig_ok}
        authoritative = data
        if self.core.np.enabled and data.get("payment_id"):
            fetched = await self.core.np.payment_status(str(data["payment_id"]))
            if fetched:
                authoritative = fetched
            elif not sig_ok:
                return {"ok": False, "reason": "signature invalid and status fetch failed"}
        elif not sig_ok:
            return {"ok": False, "reason": "signature invalid"}
        await self.apply_status(inv, authoritative, source="ipn" if authoritative is data else "api")
        return {"ok": True, "sig_ok": sig_ok, "status": authoritative.get("payment_status")}

    async def apply_status(self, inv: sqlite3.Row, data: dict, source: str = "api") -> None:
        """Idempotent state transition for one invoice part from a NOWPayments payment object."""
        status = str(data.get("payment_status") or "").lower()
        ts = now_ts()
        fields: dict[str, Any] = {"np_status": status or inv["np_status"], "updated_at": ts}
        for src, dst in (("payment_id", "np_payment_id"), ("pay_currency", "pay_currency"), ("pay_amount", "pay_amount"),
                         ("actually_paid", "actually_paid"), ("outcome_amount", "outcome_amount"),
                         ("outcome_currency", "outcome_currency"), ("payin_hash", "payin_hash"), ("invoice_id", "np_invoice_id")):
            if data.get(src) not in (None, ""):
                fields[dst] = str(data[src])
        inv_fresh = self.db.get("invoices", inv["id"])
        if inv_fresh["status"] == "paid":
            self.db.update("invoices", inv["id"], **{k: v for k, v in fields.items() if k != "np_status"})
            return
        paid_set = self.core.settings.paid_statuses()
        if status in paid_set:
            fields.update(status="paid", paid_at=ts)
            self.db.update("invoices", inv["id"], **fields)
            await self._on_part_paid(inv_fresh)
        elif status == "partially_paid":
            fields.update(status="partial")
            self.db.update("invoices", inv["id"], **fields)
            purchase = self.db.get("purchases", inv["purchase_id"])
            if purchase["status"] == "pending":
                self.db.update("purchases", purchase["id"], status="partial", updated_at=ts)
        elif status in DEAD:
            fields.update(status=status)
            self.db.update("invoices", inv["id"], **fields)
            purchase = self.db.get("purchases", inv["purchase_id"])
            if purchase["parts_paid"] == 0 and purchase["status"] in ("pending",):
                self.db.update("purchases", purchase["id"], status="expired" if status == "expired" else "failed", updated_at=ts)
            self.db.audit("invoice.dead", actor_role="system", entity_type="invoice", entity_id=inv["order_ref"], data={"status": status})
        else:
            self.db.update("invoices", inv["id"], **fields)

    async def _on_part_paid(self, inv: sqlite3.Row) -> None:
        ts = now_ts()
        with self.db.transaction():
            purchase = self.db.get("purchases", inv["purchase_id"])
            parts_paid = int(purchase["parts_paid"]) + 1
            paid_cents = int(purchase["paid_cents"]) + int(inv["amount_cents"])
            completed = parts_paid >= int(purchase["parts_total"])
            self.db.update("purchases", purchase["id"], parts_paid=parts_paid, paid_cents=paid_cents, updated_at=ts,
                           status="paid" if completed else "partial", paid_at=ts if completed else purchase["paid_at"])
            if purchase["user_id"]:
                self.db.execute("UPDATE users SET total_spent_cents=total_spent_cents+? WHERE id=?", (inv["amount_cents"], purchase["user_id"]))
        self.db.audit("invoice.paid", actor_user_id=purchase["user_id"], actor_role="system", entity_type="invoice", entity_id=inv["order_ref"],
                      data={"amount_cents": inv["amount_cents"], "part_no": inv["part_no"], "completed": completed})
        purchase = self.db.get("purchases", purchase["id"])
        if completed:
            await self._on_paid(purchase)
        else:
            await self.core.notifier.admin(f"Partial: {purchase['public_id']} part {inv['part_no']}/{purchase['parts_total']} paid "
                                           f"({usd(inv['amount_cents'])}). {purchase['title']}")

    async def _on_paid(self, purchase: sqlite3.Row) -> None:
        if purchase["fulfilled_at"]:
            return
        ts = now_ts()
        if purchase["user_id"]:
            self.db.execute("UPDATE users SET purchases_count=purchases_count+1 WHERE id=?", (purchase["user_id"],))
            self._kyc_check(purchase["user_id"])
        self.db.update("purchases", purchase["id"], fulfilled_at=ts, updated_at=ts)
        self.db.audit("purchase.paid", actor_user_id=purchase["user_id"], actor_role="system", entity_type="purchase",
                      entity_id=purchase["public_id"], data={"kind": purchase["kind"], "total_cents": purchase["total_cents"]})
        from .fulfill import fulfill
        try:
            await fulfill(self.core, self.db.get("purchases", purchase["id"]))
        except Exception:  # pragma: no cover - fulfillment bug must not lose the payment record
            log.exception("fulfillment failed for %s", purchase["public_id"])
            await self.core.notifier.admin(f"FULFILLMENT ERROR {purchase['public_id']} ({purchase['kind']}). Check logs.")
        # receipt
        user = self.db.get("users", purchase["user_id"]) if purchase["user_id"] else None
        email = (user["email"] if user else None) or purchase["guest_email"]
        if email and self.core.emailer.enabled:
            await self.core.emailer.receipt(email, purchase["title"], usd(purchase["total_cents"]), purchase["public_id"],
                                            self.core.url(f"/pay/{purchase['public_id']}"))
        await self.core.notifier.mirror("purchase", purchase["public_id"], f"PAID {purchase['public_id']} {purchase['title']} {usd(purchase['total_cents'])}",
                                        dict(self.db.get("purchases", purchase["id"])))

    def _kyc_check(self, user_id: int) -> None:
        user = self.db.get("users", user_id)
        if user and user["kyc_status"] == "none" and user["total_spent_cents"] >= self.core.settings.int("kyc_threshold_cents"):
            self.db.update("users", user_id, kyc_status="required")
            self.db.audit("kyc.required", actor_role="system", entity_type="user", entity_id=user_id,
                          data={"total_spent_cents": user["total_spent_cents"]})

    # ------------------------------------------------------------ reconciliation / housekeeping
    async def reconcile_pending(self, max_age_seconds: int = 14 * 86400) -> int:
        if not self.core.np.enabled:
            return 0
        rows = self.db.all("SELECT * FROM invoices WHERE status IN ('pending','partial') AND np_payment_id IS NOT NULL AND created_at>?",
                           (now_ts() - max_age_seconds,))
        n = 0
        for inv in rows:
            data = await self.core.np.payment_status(inv["np_payment_id"])
            if data:
                self.db.insert("payment_events", invoice_id=inv["id"], np_payment_id=inv["np_payment_id"], np_invoice_id=inv["np_invoice_id"],
                               status=str(data.get("payment_status") or ""), source="poll", sig_ok=1, received_at=now_ts(),
                               raw_json=json.dumps(data, default=str)[:20000])
                await self.apply_status(inv, data, source="poll")
                n += 1
        # Invoices without a payment_id (user never picked a coin): try the listing API by invoice id.
        rows = self.db.all("SELECT * FROM invoices WHERE status='pending' AND np_payment_id IS NULL AND np_invoice_id IS NOT NULL AND created_at>?",
                           (now_ts() - max_age_seconds,))
        for inv in rows[:50]:
            for p in await self.core.np.list_payments(invoice_id=inv["np_invoice_id"]):
                self.db.insert("payment_events", invoice_id=inv["id"], np_payment_id=str(p.get("payment_id")), np_invoice_id=inv["np_invoice_id"],
                               status=str(p.get("payment_status") or ""), source="list", sig_ok=1, received_at=now_ts(),
                               raw_json=json.dumps(p, default=str)[:20000])
                await self.apply_status(inv, p, source="list")
                n += 1
        return n

    def expire_stale(self) -> int:
        ts = now_ts()
        rows = self.db.all("SELECT * FROM purchases WHERE status='pending' AND expires_at IS NOT NULL AND expires_at<?", (ts,))
        for p in rows:
            self.db.update("purchases", p["id"], status="expired", updated_at=ts)
            self.db.execute("UPDATE invoices SET status='expired', updated_at=? WHERE purchase_id=? AND status='pending'", (ts, p["id"]))
            self.db.audit("purchase.expired", actor_role="system", entity_type="purchase", entity_id=p["public_id"])
        return len(rows)

    # ------------------------------------------------------------ queries
    def user_purchases(self, user_id: int, limit: int = 50) -> list[sqlite3.Row]:
        return self.db.all("SELECT * FROM purchases WHERE user_id=? ORDER BY id DESC LIMIT ?", (user_id, limit))

    def invoices(self, purchase_id: int) -> list[sqlite3.Row]:
        return self.db.all("SELECT * FROM invoices WHERE purchase_id=? ORDER BY part_no", (purchase_id,))

    def events(self, invoice_id: int) -> list[sqlite3.Row]:
        return self.db.all("SELECT * FROM payment_events WHERE invoice_id=? ORDER BY id", (invoice_id,))

    def pending_for_user(self, user_id: int) -> list[sqlite3.Row]:
        return self.db.all("SELECT * FROM purchases WHERE user_id=? AND status IN ('pending','partial') ORDER BY id DESC", (user_id,))

    def cancel_pending(self, purchase: sqlite3.Row, reason: str) -> None:
        if purchase["status"] not in ("pending",) or purchase["parts_paid"]:
            return
        ts = now_ts()
        self.db.update("purchases", purchase["id"], status="canceled", updated_at=ts)
        self.db.execute("UPDATE invoices SET status='canceled', updated_at=? WHERE purchase_id=? AND status='pending'", (ts, purchase["id"]))
        if purchase["credit_used_cents"] and purchase["user_id"]:
            self.db.wallet_apply(purchase["user_id"], int(purchase["credit_used_cents"]), "canceled purchase credit returned", "purchase", purchase["public_id"])
        self.db.audit("purchase.canceled", actor_user_id=purchase["user_id"], entity_type="purchase", entity_id=purchase["public_id"], data={"reason": reason})

    async def simulate_paid(self, purchase: sqlite3.Row, actor: int | None = None) -> None:
        """Admin tool: mark all parts paid (manual/off-platform settlement). Audited."""
        for inv in self.invoices(purchase["id"]):
            if inv["status"] != "paid":
                self.db.update("invoices", inv["id"], status="paid", np_status="manual", paid_at=now_ts(), updated_at=now_ts())
                await self._on_part_paid(inv)
        if purchase["parts_total"] == 1 and not self.invoices(purchase["id"]):
            await self.finalize_zero(purchase)
        self.db.audit("purchase.manual_paid", actor_user_id=actor, actor_role="admin", entity_type="purchase", entity_id=purchase["public_id"])
