"""Fulfillment dispatcher: what happens when a purchase is fully paid, by purchase kind.

Kinds:
  rq_activation, rq_order                       -> request system
  membership, bundle, upgrade                   -> membership period
  post, collection, comment_unlock, media       -> content unlocks
  dm, message_unlock, message_pack, priority_dm, public_question
  stream_ticket, pinned_chat, highlight_chat    -> live
  call                                           -> call booking confirmation
  custom_deposit, custom_balance, custom_priority
  tip, campaign                                  -> tips / fundraising
  channel                                        -> channel membership
  drop                                           -> drop unlock
  shop                                           -> shop order
  preview_pass, follower_badge, wallet           -> audience products / credit
"""
from __future__ import annotations

import logging
import sqlite3

from . import calls, community, content, customs, live, members, messaging
from .money import usd
from .util import loads, now_ts

log = logging.getLogger(__name__)


async def fulfill(core, purchase: sqlite3.Row) -> None:
    db = core.db
    kind = purchase["kind"]
    meta = loads(purchase["meta_json"], {})
    uid = purchase["user_id"]
    eid = purchase["entity_id"]
    pid = purchase["id"]
    handler = _HANDLERS.get(kind)
    if handler is None:
        log.warning("no fulfillment handler for kind %s (%s)", kind, purchase["public_id"])
        await core.notifier.admin(f"Paid purchase with unknown kind {kind}: {purchase['public_id']}")
        return
    await handler(core, purchase, meta, uid, eid, pid)
    db.audit("purchase.fulfilled", actor_user_id=uid, actor_role="system", entity_type="purchase", entity_id=purchase["public_id"], data={"kind": kind})
    if kind not in ("rq_activation", "rq_order"):
        who = _who(db, uid)
        await core.notifier.admin(f"PAID {purchase['public_id']} — {purchase['title']} — {usd(purchase['total_cents'])} — {who}")


def _who(db, uid) -> str:
    if not uid:
        return "guest"
    u = db.get("users", uid)
    return f"#{uid} {u['username'] or ''} {u['email'] or ''}".strip() if u else f"#{uid}"


# ------------------------------------------------------------------ request system
async def _rq(core, purchase, meta, uid, eid, pid):
    from .requestsys.service import RequestService
    await RequestService(core).on_purchase_paid(purchase)


# ------------------------------------------------------------------ memberships
async def _membership(core, purchase, meta, uid, eid, pid):
    db = core.db
    tier = db.get("tiers", eid)
    if tier is None or not uid:
        return
    seconds = int(meta.get("seconds") or members.MONTH)
    members.grant_period(core, uid, tier["id"], seconds, int(purchase["total_cents"]), pid, purchase["kind"])
    db.notify(uid, "membership", f"{tier['name']} active", "thank you. access runs until the period end shown in your account.", "/membership")


# ------------------------------------------------------------------ content
async def _post(core, purchase, meta, uid, eid, pid):
    if uid:
        content.grant_unlock(core.db, uid, "post", eid, pid)


async def _collection(core, purchase, meta, uid, eid, pid):
    if uid:
        content.grant_unlock(core.db, uid, "collection", eid, pid)


async def _comment_unlock(core, purchase, meta, uid, eid, pid):
    if uid:
        content.grant_unlock(core.db, uid, "comments", eid, pid)


async def _media(core, purchase, meta, uid, eid, pid):
    if uid:
        content.grant_unlock(core.db, uid, "media", eid, pid)


# ------------------------------------------------------------------ messaging
async def _dm(core, purchase, meta, uid, eid, pid):
    db = core.db
    if not uid:
        return
    body = meta.get("body") or ""
    mid = messaging.send(db, uid, "user", body, media_id=meta.get("media_id"), priority=bool(meta.get("priority")), purchase_id=pid)
    db.update("messages", mid, purchase_id=pid)


async def _public_question(core, purchase, meta, uid, eid, pid):
    db = core.db
    body = meta.get("body") or ""
    if uid:
        messaging.send(db, uid, "user", body, purchase_id=pid)
    else:
        db.insert("contact_requests", email=purchase["guest_email"], subject="Public question (paid)", body=body, amount_cents=purchase["total_cents"],
                  kind="public_question", created_at=now_ts())


async def _message_unlock(core, purchase, meta, uid, eid, pid):
    messaging.unlock_message(core.db, eid, pid)


async def _message_pack(core, purchase, meta, uid, eid, pid):
    db = core.db
    pack = db.get("message_packs", eid)
    if pack and uid:
        db.insert("message_credits", user_id=uid, remaining=int(pack["count"]), expires_at=now_ts() + int(pack["days_valid"]) * 86400,
                  purchase_id=pid, created_at=now_ts())


async def _priority_dm(core, purchase, meta, uid, eid, pid):
    db = core.db
    if eid:
        db.update("messages", eid, priority=1)


# ------------------------------------------------------------------ live
async def _stream_ticket(core, purchase, meta, uid, eid, pid):
    if uid:
        live.grant_ticket(core.db, eid, uid, pid)


async def _pinned_chat(core, purchase, meta, uid, eid, pid):
    live.post_chat(core.db, eid, uid, meta.get("body") or "", kind="pinned", amount_cents=purchase["total_cents"], pin_minutes=int(meta.get("minutes") or 10))
    live.add_tip(core.db, eid, uid, int(purchase["total_cents"]), None, kind="pin")


async def _highlight_chat(core, purchase, meta, uid, eid, pid):
    live.post_chat(core.db, eid, uid, meta.get("body") or "", kind="highlight", amount_cents=purchase["total_cents"])
    live.add_tip(core.db, eid, uid, int(purchase["total_cents"]), None, kind="highlight")


# ------------------------------------------------------------------ calls / customs
async def _call(core, purchase, meta, uid, eid, pid):
    calls.confirm(core, eid, pid)


async def _custom_deposit(core, purchase, meta, uid, eid, pid):
    customs.on_deposit_paid(core.db, eid, pid)


async def _custom_balance(core, purchase, meta, uid, eid, pid):
    customs.on_balance_paid(core.db, eid, pid)


async def _custom_priority(core, purchase, meta, uid, eid, pid):
    core.db.update("custom_orders", eid, priority_level=meta.get("level", "priority"), priority_purchase_id=pid, updated_at=now_ts())


# ------------------------------------------------------------------ tips / campaigns
async def _tip(core, purchase, meta, uid, eid, pid):
    community.record_tip(core, uid, int(purchase["total_cents"]), pid, meta.get("context_type") or "profile", meta.get("context_id"),
                         meta.get("message"), bool(meta.get("anonymous")))


async def _campaign(core, purchase, meta, uid, eid, pid):
    community.record_tip(core, uid, int(purchase["total_cents"]), pid, "campaign", eid, meta.get("message"), not bool(meta.get("public", True)))


# ------------------------------------------------------------------ channels / drops / shop
async def _channel(core, purchase, meta, uid, eid, pid):
    if uid:
        community.join_channel(core.db, eid, uid, pid, role=meta.get("role") or "member")


async def _drop(core, purchase, meta, uid, eid, pid):
    if uid:
        community.grant_drop(core.db, eid, uid, pid)


async def _shop(core, purchase, meta, uid, eid, pid):
    community.on_shop_order_paid(core, eid, pid)


# ------------------------------------------------------------------ audience products / credit
async def _preview_pass(core, purchase, meta, uid, eid, pid):
    if uid:
        community.grant_preview_pass(core.db, core.settings, uid, pid)


async def _follower_badge(core, purchase, meta, uid, eid, pid):
    if uid:
        community.grant_follower_badge(core.db, uid)


async def _wallet(core, purchase, meta, uid, eid, pid):
    if uid:
        core.db.wallet_apply(uid, int(purchase["total_cents"]), "wallet top-up", "purchase", purchase["public_id"])


_HANDLERS = {
    "rq_activation": _rq, "rq_order": _rq,
    "membership": _membership, "bundle": _membership, "upgrade": _membership,
    "post": _post, "collection": _collection, "comment_unlock": _comment_unlock, "media": _media,
    "dm": _dm, "public_question": _public_question, "message_unlock": _message_unlock, "message_pack": _message_pack, "priority_dm": _priority_dm,
    "stream_ticket": _stream_ticket, "pinned_chat": _pinned_chat, "highlight_chat": _highlight_chat,
    "call": _call, "custom_deposit": _custom_deposit, "custom_balance": _custom_balance, "custom_priority": _custom_priority,
    "tip": _tip, "campaign": _campaign, "channel": _channel, "drop": _drop, "shop": _shop,
    "preview_pass": _preview_pass, "follower_badge": _follower_badge, "wallet": _wallet,
}

KINDS = tuple(_HANDLERS)
