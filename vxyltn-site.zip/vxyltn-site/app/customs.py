"""Custom content marketplace (members): request -> quote -> deposit -> work -> delivery -> balance -> revisions."""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone

from .money import usd
from .util import loads, now_ts

STATUSES = ("pending", "quoted", "accepted", "declined", "in_progress", "delivered", "completed", "disputed", "canceled")
PRIORITY_FEES = {"none": 0, "priority": 100_000, "high": 250_000, "urgent": 500_000}


def create(db, user_id: int, type_: str, title: str, brief: str, specs: dict, attachment_media_ids: list[int], deposit_pct: int = 50) -> sqlite3.Row:
    ts = now_ts()
    pid = db.public_id("CO", datetime.now(timezone.utc).year)
    oid = db.insert("custom_orders", public_id=pid, user_id=user_id, type=type_, title=title[:200], specs_json=json.dumps(specs),
                    brief=brief[:8000], attachments_json=json.dumps(attachment_media_ids), status="pending", deposit_pct=deposit_pct,
                    created_at=ts, updated_at=ts)
    db.audit("custom.created", actor_user_id=user_id, actor_role="user", entity_type="custom_order", entity_id=pid, data={"type": type_})
    return db.get("custom_orders", oid)


def quote(db, order_id: int, quote_cents: int, deadline_at: int | None, revisions: int, note: str, actor: int) -> None:
    o = db.get("custom_orders", order_id)
    db.update("custom_orders", order_id, status="quoted", quote_cents=quote_cents, deadline_at=deadline_at, revisions_allowed=revisions,
              creator_notes=note, updated_at=now_ts())
    db.insert("custom_messages", order_id=order_id, sender_role="creator", body=f"Quote: {usd(quote_cents)}. {note}".strip(), created_at=now_ts())
    db.notify(o["user_id"], "custom", f"Quote for {o['public_id']}", f"{usd(quote_cents)}. Deposit {o['deposit_pct']}% to start.", f"/customs/{o['public_id']}")
    db.audit("custom.quoted", actor_user_id=actor, actor_role="admin", entity_type="custom_order", entity_id=o["public_id"], data={"quote_cents": quote_cents})


def counter_offer(db, order_id: int, cents: int, user_id: int) -> None:
    db.update("custom_orders", order_id, counter_offer_cents=cents, updated_at=now_ts())
    db.insert("custom_messages", order_id=order_id, sender_role="user", body=f"Counter-offer: {usd(cents)}", created_at=now_ts())


def decline(db, order_id: int, note: str, actor: int) -> None:
    o = db.get("custom_orders", order_id)
    db.update("custom_orders", order_id, status="declined", creator_notes=note, updated_at=now_ts())
    db.notify(o["user_id"], "custom", f"{o['public_id']} declined", note or "", f"/customs/{o['public_id']}")


def deposit_cents(o: sqlite3.Row) -> int:
    return int(int(o["quote_cents"] or 0) * int(o["deposit_pct"]) / 100)


def balance_cents(o: sqlite3.Row) -> int:
    return int(o["quote_cents"] or 0) - deposit_cents(o)


def on_deposit_paid(db, order_id: int, purchase_id: int) -> None:
    o = db.get("custom_orders", order_id)
    db.update("custom_orders", order_id, status="accepted" if o["status"] in ("quoted", "pending") else o["status"], deposit_purchase_id=purchase_id, updated_at=now_ts())
    db.insert("custom_messages", order_id=order_id, sender_role="system", body="Deposit received. Work can start.", created_at=now_ts())


def set_status(db, order_id: int, status: str, actor: int, note: str = "") -> None:
    o = db.get("custom_orders", order_id)
    db.update("custom_orders", order_id, status=status, updated_at=now_ts())
    if note:
        db.insert("custom_messages", order_id=order_id, sender_role="creator", body=note, created_at=now_ts())
    db.notify(o["user_id"], "custom", f"{o['public_id']}: {status.replace('_', ' ')}", note, f"/customs/{o['public_id']}")
    db.audit("custom.status", actor_user_id=actor, actor_role="admin", entity_type="custom_order", entity_id=o["public_id"], data={"status": status})


def deliver(db, order_id: int, media_ids: list[int], note: str, actor: int) -> None:
    o = db.get("custom_orders", order_id)
    db.update("custom_orders", order_id, status="delivered", delivery_media_json=json.dumps(media_ids), delivery_note=note,
              delivered_at=now_ts(), updated_at=now_ts())
    db.insert("custom_messages", order_id=order_id, sender_role="creator", body=f"Delivered. {note}".strip(), created_at=now_ts())
    db.notify(o["user_id"], "custom", f"{o['public_id']} delivered", "Pay the balance to download." if balance_cents(o) > 0 else "Download available.",
              f"/customs/{o['public_id']}")


def on_balance_paid(db, order_id: int, purchase_id: int) -> None:
    db.update("custom_orders", order_id, status="completed", balance_purchase_id=purchase_id, updated_at=now_ts())
    db.insert("custom_messages", order_id=order_id, sender_role="system", body="Balance received. Delivery unlocked.", created_at=now_ts())


def request_revision(db, order_id: int, user_id: int, note: str) -> str | None:
    o = db.get("custom_orders", order_id)
    if o["revisions_used"] >= o["revisions_allowed"]:
        return "No revisions left."
    db.update("custom_orders", order_id, revisions_used=int(o["revisions_used"]) + 1, status="in_progress", updated_at=now_ts())
    db.insert("custom_messages", order_id=order_id, sender_role="user", body=f"Revision requested: {note}", created_at=now_ts())
    return None


def can_download(o: sqlite3.Row) -> bool:
    return o["status"] == "completed" or (o["status"] == "delivered" and balance_cents(o) <= 0)


def user_orders(db, user_id: int) -> list[sqlite3.Row]:
    return db.all("SELECT * FROM custom_orders WHERE user_id=? ORDER BY id DESC", (user_id,))


def queue(db, status: str | None = None, limit: int = 100) -> list[sqlite3.Row]:
    where = "WHERE status=?" if status else "WHERE status NOT IN ('completed','declined','canceled')"
    params = (status, limit) if status else (limit,)
    return db.all(f"SELECT o.*, u.username, u.email FROM custom_orders o JOIN users u ON u.id=o.user_id {where}"
                  " ORDER BY CASE o.priority_level WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'priority' THEN 2 ELSE 3 END, o.deadline_at, o.id LIMIT ?", params)


def messages(db, order_id: int) -> list[sqlite3.Row]:
    return db.all("SELECT * FROM custom_messages WHERE order_id=? ORDER BY id", (order_id,))


def attachments(db, o: sqlite3.Row) -> list[sqlite3.Row]:
    ids = loads(o["attachments_json"], [])
    return [m for m in (db.get("media", i) for i in ids) if m]


def deliverables(db, o: sqlite3.Row) -> list[sqlite3.Row]:
    ids = loads(o["delivery_media_json"], [])
    return [m for m in (db.get("media", i) for i in ids) if m]


def overdue(db) -> list[sqlite3.Row]:
    return db.all("SELECT * FROM custom_orders WHERE status IN ('accepted','in_progress') AND deadline_at IS NOT NULL AND deadline_at<?", (now_ts(),))
