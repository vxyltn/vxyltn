"""Background jobs (asyncio tasks inside the web process; single-instance deployment).

Jobs: payment reconciliation, stale purchases, request-system expiry, membership housekeeping,
automation runs, scheduled mass messages, drops tick, call reminders/holds, story expiry, daily backup, daily report.
"""
from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timedelta, timezone

from . import calls, community, members, messaging
from .util import now_ts

log = logging.getLogger(__name__)


class Scheduler:
    def __init__(self, core):
        self.core = core
        self._tasks: list[asyncio.Task] = []
        self._stop = asyncio.Event()

    def start(self) -> None:
        self._stop = asyncio.Event()
        self._tasks = [
            asyncio.create_task(self._every(60, self.minute_jobs, "minute")),
            asyncio.create_task(self._every(300, self.reconcile, "reconcile")),
            asyncio.create_task(self._every(3600, self.hourly_jobs, "hourly")),
            asyncio.create_task(self._daily(self.core.cfg.backup_hour_local, self.backup, "backup")),
            asyncio.create_task(self._daily(self.core.cfg.report_hour_local, self.daily_report, "report")),
        ]

    async def stop(self) -> None:
        self._stop.set()
        for t in self._tasks:
            t.cancel()
        for t in self._tasks:
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass

    async def _every(self, seconds: int, fn, name: str) -> None:
        await asyncio.sleep(5)
        while not self._stop.is_set():
            try:
                await fn()
            except Exception:  # pragma: no cover
                log.exception("job %s failed", name)
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=seconds)
            except asyncio.TimeoutError:
                pass

    async def _daily(self, hour_local: int, fn, name: str) -> None:
        while not self._stop.is_set():
            now = datetime.now(self.core.tz)
            nxt = now.replace(hour=hour_local, minute=0, second=0, microsecond=0)
            if nxt <= now:
                nxt += timedelta(days=1)
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=(nxt - now).total_seconds())
                return
            except asyncio.TimeoutError:
                pass
            try:
                await fn()
            except Exception:  # pragma: no cover
                log.exception("daily job %s failed", name)

    # ------------------------------------------------------------ jobs
    async def minute_jobs(self) -> None:
        db = self.core.db
        from .requestsys.service import RequestService
        rs = RequestService(self.core)
        rs.expire_sessions()
        members.run_automation(self.core)
        messaging.due_mass_messages(db)
        community.drop_tick(db)
        calls.release_stale_holds(db)
        # publish scheduled posts (published_at in the past but marked scheduled)
        db.execute("UPDATE posts SET scheduled_at=NULL WHERE scheduled_at IS NOT NULL AND published_at<=?", (now_ts(),))

    async def reconcile(self) -> None:
        await self.core.payments.reconcile_pending()
        self.core.payments.expire_stale()

    async def hourly_jobs(self) -> None:
        from .requestsys.service import RequestService
        rs = RequestService(self.core)
        rs.expire_orders()
        rs.discard_stale()
        members.run_membership_housekeeping(self.core)
        calls.due_reminders(self.core)
        db = self.core.db
        # media expiry (vault rules)
        for m in db.all("SELECT * FROM media WHERE expires_at IS NOT NULL AND expires_at<? AND archived_at IS NULL", (now_ts(),)):
            db.update("media", m["id"], archived_at=now_ts())
        # custom order deadline reminders
        from . import customs
        for o in customs.overdue(db):
            db.audit("custom.overdue", entity_type="custom_order", entity_id=o["public_id"])
        # purge old rate-limit rows
        db.execute("DELETE FROM rate_limit WHERE window_start<?", (now_ts() - 3600,))

    async def backup(self) -> None:
        cfg = self.core.cfg
        os.makedirs(cfg.backups_dir, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        path = os.path.join(cfg.backups_dir, f"vxyltn-{stamp}.sqlite3")
        await asyncio.to_thread(self.core.db.backup_to, path)
        # keep the last 14 local backups
        files = sorted(f for f in os.listdir(cfg.backups_dir) if f.endswith(".sqlite3"))
        for old in files[:-14]:
            try:
                os.remove(os.path.join(cfg.backups_dir, old))
            except OSError:
                pass
        self.core.db.audit("backup.done", actor_role="system", entity_type="backup", entity_id=stamp)
        if self.core.notifier.tg_enabled:
            with open(path, "rb") as fh:
                await self.core.notifier.backup_document(fh.read(), os.path.basename(path), f"#backup {stamp}")
        if os.environ.get("BACKUP_S3_BUCKET"):
            # aws cli on the host/container copies the file; keeps boto3 out of the app
            bucket = os.environ["BACKUP_S3_BUCKET"]
            proc = await asyncio.create_subprocess_exec("aws", "s3", "cp", path, f"s3://{bucket}/backups/{os.path.basename(path)}",
                                                        stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
            _, err = await proc.communicate()
            if proc.returncode != 0:
                log.warning("s3 backup upload failed: %s", err.decode()[:300])

    async def daily_report(self) -> None:
        from . import reports
        rep = reports.build(self.core, *reports.range_bounds(self.core, "yesterday")[:2])
        text = reports.text_summary(self.core, rep, "daily report")
        await self.core.notifier.admin(f"<pre>{text}</pre>")
