"""Money helpers. All amounts are integer cents of the pricing currency (USDC, 1 USDC = 1 USD)."""
from __future__ import annotations

import os
from decimal import ROUND_CEILING, Decimal
from fractions import Fraction

LABEL = os.environ.get("CURRENCY_LABEL", "usdc").strip().lower() or "usdc"


def usd(cents: int | None, decimals: int = 2, label: str | None = None) -> str:
    """Format cents as '1,000 usdc' (whole amounts drop the decimals)."""
    if cents is None:
        return "-"
    label = LABEL if label is None else label
    neg = cents < 0
    cents = abs(int(cents))
    whole, frac = divmod(cents, 100)
    out = f"{whole:,}" if (decimals == 0 or frac == 0) else f"{whole:,}.{frac:02d}"
    out = f"{out} {label}" if label else out
    return f"-{out}" if neg else out


fmt = usd


def usd_plain(cents: int) -> str:
    """'1000000.00' for payment APIs."""
    return f"{Decimal(int(cents)) / 100:.2f}"


def ceil_mul(cents: int, mult: float) -> int:
    frac = Fraction(str(mult))
    return -((-cents * frac.numerator) // frac.denominator)


def ceil_pct(cents: int, pct: int | float) -> int:
    frac = Fraction(str(pct)) / 100 + 1
    return -((-cents * frac.numerator) // frac.denominator)


def round_up_to(cents: int, step: int) -> int:
    if step <= 1:
        return cents
    return -((-cents) // step) * step


def split_amount(total: int, max_per: int) -> list[int]:
    if total <= 0:
        return []
    if max_per <= 0 or total <= max_per:
        return [total]
    parts = [max_per] * (total // max_per)
    rest = total % max_per
    if rest:
        parts.append(rest)
    return parts


def convert(cents: int, rate: float, decimals: int = 2) -> str:
    val = (Decimal(cents) / 100) * Decimal(str(rate))
    q = Decimal(1).scaleb(-decimals)
    return f"{val.quantize(q, rounding=ROUND_CEILING):,}"


def display_prices(cents: int, rates: dict[str, float], currencies: tuple[str, ...]) -> list[tuple[str, str]]:
    out = [(LABEL.upper(), usd(cents, label=""))]
    for c in currencies:
        if c in ("USDC", LABEL.upper()):
            continue
        rate = rates.get(c)
        if not rate:
            continue
        decimals = 8 if c in ("BTC",) else (6 if c in ("ETH",) else 2)
        out.append((c, convert(cents, rate, decimals)))
    return out
