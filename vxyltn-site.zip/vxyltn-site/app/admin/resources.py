"""Declarative admin resources: one spec per table drives generic list / create / edit / delete views."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Field:
    name: str
    label: str = ""
    kind: str = "text"          # text, textarea, int, cents, float, bool, select, datetime, json, slug, media, media_list, user, pct, readonly
    options: list = field(default_factory=list)   # for select: [(value, label)]
    help: str = ""
    required: bool = False
    default: object = None

    def __post_init__(self):
        self.label = self.label or self.name.replace("_", " ")


@dataclass
class Resource:
    key: str
    table: str
    title: str
    fields: list
    list_columns: list                 # column names shown in the list
    search: list = field(default_factory=list)
    filters: dict = field(default_factory=dict)   # column -> [(value,label)]
    order: str = "id DESC"
    soft_delete: str | None = None     # column set to now_ts() instead of DELETE
    slug_from: str | None = None       # auto slug source column
    creatable: bool = True
    deletable: bool = True
    description: str = ""
    row_links: dict = field(default_factory=dict)  # column -> url template e.g. "/admin/users/{user_id}"
    created_at: bool = True
    derive: object = None              # callable(values) -> values, for computed columns

    def field(self, name: str) -> Field | None:
        return next((f for f in self.fields if f.name == name), None)


TIER_SELECT = "__tiers__"
VIS = [("public", "public"), ("follower", "follower"), ("member", "member"), ("tier", "tier (min rank)"), ("ppv", "pay-per-view")]
KINDS_MEDIA = [("image", "image"), ("video", "video"), ("audio", "audio"), ("document", "document"), ("other", "other")]

RESOURCES: dict[str, Resource] = {}


def _r(res: Resource) -> Resource:
    RESOURCES[res.key] = res
    return res


_r(Resource("tiers", "tiers", "tiers", [
    Field("name", required=True), Field("slug", kind="slug"), Field("description", kind="textarea"), Field("icon", help="short text or emoji"),
    Field("price_month_cents", "price / 28 days", "cents", required=True), Field("price_year_cents", "price / year", "cents"),
    Field("intro_price_cents", "intro price", "cents"), Field("intro_periods", "intro periods", "int", default=0),
    Field("rank", kind="int", default=1, help="higher rank includes lower-rank content"), Field("max_members", kind="int"),
    Field("perks_json", "perks (json)", "json", help='{"dm_price_cents": 0, "ppv_discount_pct": 25, "priority_eligible": true, "early_drop_hours": 24, "comments_free": true, "tip_min_cents": 2000, "call_access": true, "custom_orders": true}'),
    Field("welcome_template", "welcome message", "textarea", help="{name} and {tier} are replaced"), Field("is_active", kind="bool", default=1),
], ["id", "name", "rank", "price_month_cents", "is_active"], search=["name"], slug_from="name", order="rank, id"))

_r(Resource("bundles", "bundles", "bundles", [
    Field("name", required=True), Field("tier_id", "tier", "select", options=TIER_SELECT, required=True), Field("months", kind="int", required=True, default=3),
    Field("price_cents", "price", "cents", required=True), Field("kind", kind="select", options=[("months", "multi-month"), ("event", "event bundle")], default="months"),
    Field("includes_json", "includes (json)", "json"), Field("starts_at", kind="datetime"), Field("ends_at", kind="datetime"), Field("is_active", kind="bool", default=1),
], ["id", "name", "tier_id", "months", "price_cents", "is_active"], search=["name"]))

_r(Resource("promos", "promo_codes", "promo codes", [
    Field("code", required=True), Field("kind", kind="select", options=[("percent", "percent off"), ("fixed", "fixed amount off (cents)"), ("trial", "100% off")], default="percent"),
    Field("value", kind="int", required=True, help="percent, or cents for fixed"), Field("applies_to", kind="select", options=[("all", "everything"), ("tier", "memberships"), ("shop", "shop"), ("post", "ppv posts")], default="all"),
    Field("entity_id", "limit to id", "int"), Field("max_uses", kind="int"), Field("per_user_limit", kind="int", default=1),
    Field("starts_at", kind="datetime"), Field("ends_at", kind="datetime"), Field("is_active", kind="bool", default=1),
], ["id", "code", "kind", "value", "uses", "max_uses", "is_active"], search=["code"]))

_r(Resource("collections", "collections", "collections / series / bundles", [
    Field("name", required=True), Field("slug", kind="slug"), Field("description", kind="textarea"),
    Field("kind", kind="select", options=[("collection", "collection"), ("series", "series"), ("bundle", "unlock bundle")], default="collection"),
    Field("price_cents", "member price (whole collection)", "cents"), Field("public_price_cents", "public price", "cents"), Field("follower_price_cents", "follower price", "cents"),
    Field("min_tier_rank", kind="int", default=0), Field("cover_media_id", kind="media"), Field("is_active", kind="bool", default=1),
], ["id", "name", "kind", "price_cents", "is_active"], search=["name"], slug_from="name"))

_r(Resource("streams", "streams", "livestreams", [
    Field("title", required=True), Field("description", kind="textarea"),
    Field("access_mode", kind="select", options=[("members", "all members"), ("tier", "tier (min rank)"), ("priority", "priority list only"), ("ticket", "ticket (members/followers)"), ("public_ticket", "ticket (anyone)")], default="members"),
    Field("min_tier_rank", kind="int", default=0), Field("ticket_price_cents", "ticket price (member)", "cents"), Field("public_ticket_price_cents", "ticket price (public)", "cents"),
    Field("scheduled_at", kind="datetime"), Field("embed_url", help="player embed url from your provider (livekit/mux/cloudflare/youtube unlisted)"),
    Field("playback_url", help="direct hls/mp4 url (optional)"), Field("stream_key_note", "stream key / obs notes", "textarea"),
    Field("chat_enabled", kind="bool", default=1), Field("tip_goal_cents", "tip goal", "cents"),
    Field("milestones_json", "milestones (json)", "json", help='[{"cents": 50000, "label": "unlock extra set", "reward": "..."}]'),
    Field("offers_json", "live offers (json)", "json", help='[{"title": "flash set", "price_cents": 9900, "url": "/drops/x", "until": 1760000000}]'),
    Field("pinned_price_cents", "paid pin price", "cents"), Field("highlight_price_cents", "highlight price", "cents"),
    Field("viewer_cap", kind="int"), Field("waiting_room", kind="bool", default=1), Field("channel_id", "channel id", "int"), Field("recording_media_id", kind="media"),
], ["id", "title", "status", "access_mode", "scheduled_at", "tips_total_cents"], search=["title"], filters={"status": [("scheduled", "scheduled"), ("live", "live"), ("ended", "ended"), ("canceled", "canceled")]}))

_r(Resource("call_slots", "call_slots", "call slots", [
    Field("kind", kind="select", options=[("audio", "audio"), ("video", "video")], default="video", required=True), Field("start_at", kind="datetime", required=True),
    Field("duration_min", kind="int", default=15, required=True), Field("price_cents", "fixed price", "cents"), Field("per_minute_cents", "or per minute", "cents"),
    Field("min_tier_rank", kind="int", default=0), Field("priority_only", kind="bool", default=0), Field("buffer_min", kind="int", default=10), Field("notes", kind="textarea"),
    Field("status", kind="select", options=[("open", "open"), ("blocked", "blocked"), ("booked", "booked"), ("done", "done")], default="open"),
], ["id", "kind", "start_at", "duration_min", "price_cents", "status"], filters={"status": [("open", "open"), ("booked", "booked"), ("blocked", "blocked"), ("done", "done")]}, order="start_at DESC",
   derive=lambda v: {**v, "end_at": int(v["start_at"]) + int(v["duration_min"] or 15) * 60}))

_r(Resource("campaigns", "campaigns", "fundraising campaigns", [
    Field("title", required=True), Field("slug", kind="slug"), Field("description", kind="textarea"), Field("goal_cents", "goal", "cents", required=True),
    Field("starts_at", kind="datetime"), Field("ends_at", kind="datetime"),
    Field("milestones_json", "milestones (json)", "json", help='[{"cents": 100000, "label": "teaser", "reward": "..."}]'),
    Field("status", kind="select", options=[("active", "active"), ("funded", "funded"), ("closed", "closed")], default="active"), Field("donor_list_public", kind="bool", default=1),
], ["id", "title", "goal_cents", "raised_cents", "status"], search=["title"], slug_from="title"))

_r(Resource("channels", "channels", "private channels", [
    Field("name", required=True), Field("slug", kind="slug"), Field("description", kind="textarea"),
    Field("kind", kind="select", options=[("tier", "tier-exclusive"), ("paid", "paid entry"), ("priority", "priority list only"), ("drop", "temporary (drop)")], default="tier"),
    Field("min_tier_rank", kind="int", default=0), Field("entry_price_cents", "entry price", "cents"), Field("upgrade_price_cents", "role upgrade price", "cents"),
    Field("expires_at", kind="datetime"), Field("member_cap", kind="int"), Field("is_active", kind="bool", default=1),
], ["id", "name", "kind", "min_tier_rank", "entry_price_cents", "is_active"], search=["name"], slug_from="name"))

_r(Resource("drops", "drops", "drops", [
    Field("title", required=True), Field("slug", kind="slug"), Field("description", kind="textarea"),
    Field("kind", kind="select", options=[("content", "content"), ("merch", "merch")], default="content"), Field("media_ids_json", "media", "media_list"),
    Field("product_id", "product id (merch)", "int"), Field("price_cents", "member price", "cents", required=True), Field("public_price_cents", "public price", "cents"),
    Field("follower_price_cents", "follower price", "cents"), Field("quantity_cap", kind="int"), Field("starts_at", kind="datetime"), Field("ends_at", kind="datetime"),
    Field("early_access_hours", kind="int", default=24), Field("min_tier_rank", kind="int", default=0),
    Field("included_tier_ranks_json", "included for tier ranks (json list)", "json", help="[3] = inner circle gets it free"),
    Field("status", kind="select", options=[("scheduled", "scheduled"), ("live", "live"), ("sold_out", "sold out"), ("ended", "ended")], default="scheduled"),
], ["id", "title", "status", "price_cents", "sold", "quantity_cap", "starts_at"], search=["title"], slug_from="title"))

_r(Resource("products", "products", "shop products", [
    Field("name", required=True), Field("slug", kind="slug"), Field("description", kind="textarea"),
    Field("kind", kind="select", options=[("physical", "physical"), ("digital", "digital")], default="physical"), Field("price_cents", "member price", "cents", required=True),
    Field("public_price_cents", "public price", "cents"), Field("follower_price_cents", "follower price", "cents"), Field("compare_at_cents", "compare-at price", "cents"),
    Field("media_ids_json", "photos", "media_list"), Field("digital_media_id", "digital file", "media"), Field("variants_json", "variants (json list)", "json", help='["s", "m", "l"]'),
    Field("inventory", kind="int"), Field("low_stock_at", kind="int", default=3), Field("signed", kind="bool", default=0), Field("personalization", kind="bool", default=0),
    Field("coa", "certificate of authenticity", "bool", default=0), Field("weight_g", kind="int"), Field("shipping_class", default="standard"), Field("tax_class", default="standard"),
    Field("min_tier_rank", kind="int", default=0), Field("is_active", kind="bool", default=1), Field("shopify_id", help="optional mapping for the shopify sync adapter"),
], ["id", "name", "kind", "price_cents", "inventory", "is_active"], search=["name"], slug_from="name"))

_r(Resource("tax_rates", "tax_rates", "tax rates", [
    Field("country", required=True, help="2-letter code"), Field("region"), Field("tax_class", default="standard"), Field("rate_pct", kind="float", required=True), Field("label"),
], ["id", "country", "region", "tax_class", "rate_pct"], search=["country"], created_at=False))

_r(Resource("shipping_rates", "shipping_rates", "shipping rates", [
    Field("zone", required=True, help="'world' matches everything"), Field("countries_json", "countries (json list)", "json", help='["US", "CA"]'),
    Field("shipping_class", default="standard"), Field("price_cents", "price", "cents", required=True), Field("per_item_cents", "per extra item", "cents", default=0), Field("label"),
], ["id", "zone", "shipping_class", "price_cents", "per_item_cents"], created_at=False))

_r(Resource("automation", "automation_rules", "automation rules", [
    Field("kind", kind="select", options=[("welcome", "welcome (on join)"), ("followup", "follow-up"), ("drip", "drip content"), ("upsell", "upsell"), ("first_tip_incentive", "first tip incentive"), ("renewal_offer", "renewal offer (period ended)"), ("winback", "win-back (expired)")], required=True),
    Field("name"), Field("tier_id", "tier (blank = all)", "select", options=TIER_SELECT), Field("delay_hours", kind="int", default=0), Field("template", kind="textarea", help="{name}, {tier}"),
    Field("media_id", kind="media"), Field("conditions_json", "conditions (json)", "json", help='{"if_no_interaction_hours": 72}'), Field("is_active", kind="bool", default=1),
], ["id", "kind", "name", "tier_id", "delay_hours", "is_active"], search=["name"]))

_r(Resource("segments", "segments", "fan segments", [
    Field("name", required=True), Field("rules_json", "rules (json)", "json", required=True,
          help='{"tier_ranks": [2,3], "members": true, "followers_only": false, "priority": false, "min_spend_cents": 10000, "joined_after": 1760000000, "inactive_days": 30, "user_ids": []}'),
    Field("is_dynamic", kind="bool", default=1),
], ["id", "name", "is_dynamic"], search=["name"]))

_r(Resource("message_packs", "message_packs", "message packs", [
    Field("name", required=True), Field("count", kind="int", required=True), Field("price_cents", "price", "cents", required=True), Field("days_valid", kind="int", default=30), Field("is_active", kind="bool", default=1),
], ["id", "name", "count", "price_cents", "days_valid", "is_active"]))

_r(Resource("calendar", "calendar_events", "calendar events", [
    Field("kind", kind="select", options=[("post", "post"), ("drop", "drop"), ("stream", "stream"), ("call", "call"), ("other", "other")], default="other"), Field("title", required=True),
    Field("start_at", kind="datetime", required=True), Field("end_at", kind="datetime"), Field("notes", kind="textarea"), Field("is_public", kind="bool", default=0),
], ["id", "kind", "title", "start_at", "is_public"], search=["title"], order="start_at DESC"))

_r(Resource("links", "link_hub", "link hub", [Field("label", required=True), Field("url", required=True), Field("position", kind="int", default=0), Field("is_active", kind="bool", default=1)],
            ["id", "label", "url", "clicks", "is_active"], order="position, id", created_at=False))

_r(Resource("counters", "social_counters", "social counters", [Field("platform", required=True), Field("label"), Field("value"), Field("url"), Field("position", kind="int", default=0)],
            ["id", "platform", "label", "value"], order="position, id", created_at=False))

_r(Resource("leaks", "leak_alerts", "leak alerts", [Field("source"), Field("url"), Field("media_id", kind="int"), Field("fingerprint", help="watermark fingerprint found in the leaked file"),
                                                  Field("status", kind="select", options=[("new", "new"), ("confirmed", "confirmed"), ("takedown_sent", "takedown sent"), ("resolved", "resolved")], default="new")],
            ["id", "source", "url", "fingerprint", "status"], filters={"status": [("new", "new"), ("confirmed", "confirmed"), ("takedown_sent", "takedown sent"), ("resolved", "resolved")]}))

_r(Resource("moderation", "moderation_flags", "moderation flags", [Field("entity_type", required=True), Field("entity_id", kind="int", required=True), Field("provider"), Field("scores_json", "scores (json)", "json"),
                                                                 Field("status", kind="select", options=[("review", "review"), ("approved", "approved"), ("removed", "removed")], default="review")],
            ["id", "entity_type", "entity_id", "provider", "status"], filters={"status": [("review", "review"), ("approved", "approved"), ("removed", "removed")]}))
