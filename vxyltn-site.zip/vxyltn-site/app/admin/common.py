"""Admin helpers: navigation, rendering, generic field parsing."""
from __future__ import annotations

import json

from starlette.requests import Request

from ..util import parse_dt_local, parse_int, parse_money_cents, slugify
from ..web import files_of, fval, render
from .resources import RESOURCES, TIER_SELECT, Field, Resource

NAV = [
    ("dashboard", "/admin"), ("request system", "/admin/requests"), ("purchases", "/admin/purchases"), ("users", "/admin/users"),
    ("messages", "/admin/messages"), ("mass messages", "/admin/mass"), ("posts", "/admin/posts"), ("vault", "/admin/vault"),
    ("tiers", "/admin/r/tiers"), ("bundles", "/admin/r/bundles"), ("promo codes", "/admin/r/promos"), ("collections", "/admin/r/collections"),
    ("live", "/admin/live"), ("calls", "/admin/calls"), ("custom orders", "/admin/customs"), ("campaigns", "/admin/r/campaigns"),
    ("channels", "/admin/channels"), ("drops", "/admin/r/drops"), ("shop", "/admin/r/products"), ("shop orders", "/admin/shop-orders"),
    ("priority list", "/admin/priority"), ("kyc", "/admin/kyc"), ("contact & manual", "/admin/contact"), ("dmca & leaks", "/admin/dmca"),
    ("automation", "/admin/r/automation"), ("segments", "/admin/r/segments"), ("calendar", "/admin/r/calendar"), ("link hub", "/admin/r/links"),
    ("reports", "/admin/reports"), ("audit log", "/admin/audit"), ("settings", "/admin/settings"), ("request pricing", "/admin/pricing"),
    ("backups & export", "/admin/backups"), ("integrations", "/admin/integrations"),
]


def arender(request: Request, name: str, **ctx):
    ctx.setdefault("nav", NAV)
    ctx.setdefault("resources", RESOURCES)
    return render(request, name, admin=True, **ctx)


def options_for(core, f: Field) -> list:
    if f.options == TIER_SELECT:
        return [("", "— all / none —")] + [(str(t["id"]), t["name"]) for t in core.db.all("SELECT id, name FROM tiers ORDER BY rank")]
    return f.options


async def parse_fields(core, request: Request, res: Resource, form: dict, existing=None) -> tuple[dict, str | None]:
    """Convert submitted form values into DB values according to each field kind. Returns (values, error)."""
    values: dict = {}
    for f in res.fields:
        raw = fval(form, f.name, "")
        kind = f.kind
        try:
            if kind == "readonly":
                continue
            if kind in ("text", "slug"):
                values[f.name] = raw or None
            elif kind == "textarea":
                values[f.name] = raw or None
            elif kind == "int":
                v = parse_int(raw)
                values[f.name] = v if raw != "" else None
                if raw and v is None:
                    return {}, f"{f.label}: enter a whole number."
            elif kind == "pct":
                values[f.name] = parse_int(raw)
            elif kind == "cents":
                v = parse_money_cents(raw)
                values[f.name] = v if raw != "" else None
                if raw and v is None:
                    return {}, f"{f.label}: enter an amount in usd."
            elif kind == "float":
                values[f.name] = float(raw) if raw else None
            elif kind == "bool":
                values[f.name] = 1 if str(raw).lower() in ("1", "on", "true", "yes") else 0
            elif kind == "select":
                values[f.name] = raw or None
                if f.options == TIER_SELECT and raw:
                    values[f.name] = int(raw)
            elif kind == "datetime":
                values[f.name] = parse_dt_local(raw, core.tz) if raw else None
                if raw and values[f.name] is None:
                    return {}, f"{f.label}: use yyyy-mm-dd hh:mm."
            elif kind == "json":
                if raw:
                    json.loads(raw)
                values[f.name] = raw or None
            elif kind == "media":
                mid = parse_int(raw)
                ups = files_of(form, f"{f.name}__upload")
                if ups:
                    mid = await core.media.save_upload(ups[0], request.state.viewer.user_id, folder=res.key, source="admin")
                values[f.name] = mid
            elif kind == "media_list":
                ids = [int(x) for x in raw.replace(" ", "").split(",") if x.strip().isdigit()] if raw else []
                for up in files_of(form, f"{f.name}__upload"):
                    ids.append(await core.media.save_upload(up, request.state.viewer.user_id, folder=res.key, source="admin"))
                values[f.name] = json.dumps(ids)
            elif kind == "user":
                values[f.name] = parse_int(raw)
            else:
                values[f.name] = raw or None
        except json.JSONDecodeError as exc:
            return {}, f"{f.label}: invalid json ({exc.msg})."
        except ValueError as exc:
            return {}, f"{f.label}: {exc}"
        if values.get(f.name) is None and f.default is not None:
            values[f.name] = f.default
        if f.required and values.get(f.name) in (None, ""):
            return {}, f"{f.label} is required."
    if res.slug_from and not values.get("slug") and values.get(res.slug_from):
        values["slug"] = slugify(values[res.slug_from])
    if res.derive:
        try:
            values = res.derive(values)
        except ValueError as exc:
            return {}, str(exc)
    return values, None


def field_value(row, f: Field, core):
    if row is None:
        return f.default if f.default is not None else ""
    v = row[f.name] if f.name in row.keys() else ""
    if v is None:
        return ""
    if f.kind == "cents":
        return f"{int(v) / 100:.2f}"
    if f.kind == "datetime":
        from ..util import dt_input_value
        return dt_input_value(v, core.tz)
    if f.kind == "media_list":
        try:
            return ",".join(str(x) for x in json.loads(v))
        except (TypeError, ValueError):
            return ""
    return v
