"""Admin panel: dashboard, generic CRUD, requests, purchases, users, messages, posts, vault (part 1)."""
from __future__ import annotations

import asyncio
import json

from starlette.requests import Request
from starlette.responses import Response, StreamingResponse
from starlette.routing import Route

from .. import content, members, messaging, reports
from ..access import active_membership
from ..money import usd
from ..requestsys.pricing import Quote
from ..requestsys.service import RequestService
from ..util import loads, now_ts, parse_dt_local
from ..web import admin_required, fbool, fcents, files_of, fint, form_data, fval, page_args, redirect
from .common import arender, field_value, options_for, parse_fields
from .resources import RESOURCES


# ------------------------------------------------------------------ dashboard
@admin_required
async def dashboard(request: Request):
    core = request.app.state.core
    db = core.db
    blocks = []
    for key in ("today", "7d", "28d", "all"):
        s, e, label = reports.range_bounds(core, key)
        blocks.append({"label": label, "revenue": int(db.scalar("SELECT COALESCE(SUM(amount_cents),0) FROM invoices WHERE status='paid' AND paid_at>=? AND paid_at<?", (s, e))),
                       "purchases": int(db.scalar("SELECT COUNT(*) FROM purchases WHERE status='paid' AND paid_at>=? AND paid_at<?", (s, e))),
                       "new_users": int(db.scalar("SELECT COUNT(*) FROM users WHERE created_at>=? AND created_at<?", (s, e))),
                       "new_members": int(db.scalar("SELECT COUNT(*) FROM memberships WHERE created_at>=? AND created_at<?", (s, e)))})
    ts = now_ts()
    counts = {
        "rq_new": db.count("rq_orders", "status='paid' AND kind<>'activation' AND admin_status='new'"),
        "rq_open": db.count("rq_orders", "status='paid' AND kind<>'activation' AND admin_status IN ('new','reviewed','in_progress')"),
        "dm_unread": db.count("messages", "sender_role='user' AND read_at IS NULL AND deleted_at IS NULL"),
        "customs_pending": db.count("custom_orders", "status IN ('pending','accepted','in_progress')"),
        "customs_quoted": db.count("custom_orders", "status='quoted'"),
        "pending_purchases": db.count("purchases", "status IN ('pending','partial')"),
        "kyc": db.count("users", "kyc_status IN ('required','pending')"),
        "priority_apps": db.count("priority_applications", "status='pending'"),
        "contact": db.count("contact_requests", "status='new'"),
        "dmca": db.count("dmca_notices", "status='new'"),
        "shop_fulfill": db.count("shop_orders", "status='fulfilling'"),
        "bookings": db.count("call_bookings", "status='confirmed'"),
        "live_now": db.count("streams", "status='live'"),
        "members": db.count("memberships", "status IN ('active','grace') AND current_period_end>?", (ts,)),
        "users": db.count("users", "deleted_at IS NULL"),
        "followers": db.count("users", "is_follower=1 AND deleted_at IS NULL"),
        "priority": db.count("users", "priority_status='approved'"),
    }
    recent_paid = db.all("SELECT p.*, u.email FROM purchases p LEFT JOIN users u ON u.id=p.user_id WHERE p.status='paid' ORDER BY p.paid_at DESC LIMIT 12")
    recent_audit = db.all("SELECT * FROM audit_log ORDER BY id DESC LIMIT 15")
    by_kind = db.all("SELECT kind, COUNT(*) n, COALESCE(SUM(total_cents),0) cents FROM purchases WHERE status='paid' AND paid_at>=? GROUP BY kind ORDER BY cents DESC LIMIT 10", (ts - 28 * 86400,))
    maxc = max([r["cents"] for r in by_kind] or [1])
    return arender(request, "admin/dashboard.html", blocks=blocks, counts=counts, recent_paid=recent_paid, recent_audit=recent_audit, by_kind=by_kind, maxc=maxc,
                   kind_labels=reports.KIND_LABELS, payments_enabled=core.np.enabled, email_enabled=core.emailer.enabled, tg=core.notifier.tg_enabled)


# ------------------------------------------------------------------ generic CRUD
@admin_required
async def res_list(request: Request):
    core = request.app.state.core
    res = RESOURCES.get(request.path_params["key"])
    if res is None:
        return redirect("/admin")
    page, size, offset = page_args(request, 40)
    q = request.query_params.get("q", "").strip()
    where, params = ["1=1"], []
    if res.soft_delete:
        where.append(f"{res.soft_delete} IS NULL")
    if q and res.search:
        where.append("(" + " OR ".join(f"{c} LIKE ?" for c in res.search) + ")")
        params += [f"%{q}%"] * len(res.search)
    active_filters = {}
    for col in res.filters:
        v = request.query_params.get(col)
        if v:
            where.append(f"{col}=?"); params.append(v); active_filters[col] = v
    rows = core.db.all(f"SELECT * FROM {res.table} WHERE {' AND '.join(where)} ORDER BY {res.order} LIMIT ? OFFSET ?", params + [size + 1, offset])
    tiers = {t["id"]: t["name"] for t in core.db.all("SELECT id, name FROM tiers")}
    return arender(request, "admin/list.html", res=res, rows=rows[:size], has_more=len(rows) > size, page=page, q=q, active_filters=active_filters, tiers=tiers)


@admin_required
async def res_form(request: Request):
    core = request.app.state.core
    res = RESOURCES.get(request.path_params["key"])
    if res is None:
        return redirect("/admin")
    rid = request.path_params.get("rid")
    row = core.db.get(res.table, int(rid)) if rid else None
    if rid and row is None:
        return redirect(f"/admin/r/{res.key}", request, "not found.")
    if request.method == "POST":
        f = await form_data(request)
        if fval(f, "action") == "delete" and res.deletable and row is not None:
            if res.soft_delete:
                core.db.update(res.table, row["id"], **{res.soft_delete: now_ts()})
            else:
                core.db.delete(res.table, row["id"])
            core.db.audit(f"{res.table}.deleted", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type=res.table, entity_id=row["id"])
            return redirect(f"/admin/r/{res.key}", request, "deleted.", "ok")
        values, err = await parse_fields(core, request, res, f, row)
        if err:
            return arender(request, "admin/form.html", res=res, row=row, error=err, values=f, options_for=lambda fld: options_for(core, fld), field_value=lambda r, fld: fval(f, fld.name, ""))
        if row is None:
            if res.created_at and "created_at" in core.db.columns(res.table):
                values["created_at"] = now_ts()
            new_id = core.db.insert(res.table, **values)
            core.db.audit(f"{res.table}.created", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type=res.table, entity_id=new_id, data=values)
            return redirect(f"/admin/r/{res.key}/{new_id}", request, "created.", "ok")
        core.db.update(res.table, row["id"], **values)
        core.db.audit(f"{res.table}.updated", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type=res.table, entity_id=row["id"], data=values)
        return redirect(f"/admin/r/{res.key}/{row['id']}", request, "saved.", "ok")
    return arender(request, "admin/form.html", res=res, row=row, options_for=lambda fld: options_for(core, fld), field_value=lambda r, fld: field_value(r, fld, core))


# ------------------------------------------------------------------ requests ($1M system)
@admin_required
async def rq_list(request: Request):
    core = request.app.state.core
    page, size, offset = page_args(request, 40)
    status = request.query_params.get("status", "")
    admin_status = request.query_params.get("admin_status", "")
    kind = request.query_params.get("kind", "")
    where, params = ["1=1"], []
    if status:
        where.append("o.status=?"); params.append(status)
    if admin_status:
        where.append("o.admin_status=?"); params.append(admin_status)
    if kind:
        where.append("o.kind=?"); params.append(kind)
    rows = core.db.all(f"SELECT o.*, u.email, u.username FROM rq_orders o LEFT JOIN users u ON u.id=o.user_id WHERE {' AND '.join(where)} ORDER BY o.id DESC LIMIT ? OFFSET ?", params + [size + 1, offset])
    totals = core.db.one("SELECT COUNT(*) n, COALESCE(SUM(total_cents),0) cents FROM rq_orders WHERE status IN ('paid','expired')")
    return arender(request, "admin/rq_list.html", rows=rows[:size], has_more=len(rows) > size, page=page, status=status, admin_status=admin_status, kind=kind, totals=totals)


@admin_required
async def rq_detail(request: Request):
    core = request.app.state.core
    db = core.db
    svc = RequestService(core)
    order = svc.order_by_public(request.path_params["public_id"])
    if order is None:
        return redirect("/admin/requests", request, "not found.")
    if request.method == "POST":
        f = await form_data(request)
        action = fval(f, "action")
        actor = request.state.viewer.user_id
        if action == "status":
            db.update("rq_orders", order["id"], admin_status=fval(f, "admin_status"), updated_at=now_ts())
            db.audit("rq.admin_status", actor_user_id=actor, actor_role="admin", entity_type="rq_order", entity_id=order["public_id"], data={"admin_status": fval(f, "admin_status")})
        elif action == "note":
            db.update("rq_orders", order["id"], admin_note=fval(f, "note")[:4000], updated_at=now_ts())
            db.audit("rq.note", actor_user_id=actor, actor_role="admin", entity_type="rq_order", entity_id=order["public_id"])
        elif action == "message":
            body = fval(f, "body")
            if body:
                messaging.send(db, order["user_id"], "creator", body)
                db.audit("rq.message_sent", actor_user_id=actor, actor_role="admin", entity_type="rq_order", entity_id=order["public_id"])
        elif action == "pdf":
            from ..pdfgen import build_request_pdf
            data = await asyncio.to_thread(build_request_pdf, core, order)
            return Response(data, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{order["invoice_no"]}.pdf"'})
        elif action == "resend_admin":
            await svc.admin_report(order)
        return redirect(f"/admin/requests/{order['public_id']}", request, "done.", "ok")
    user = db.get("users", order["user_id"])
    purchase = db.get("purchases", order["purchase_id"]) if order["purchase_id"] else None
    invoices = core.payments.invoices(purchase["id"]) if purchase else []
    audit = db.all("SELECT * FROM audit_log WHERE entity_type='rq_order' AND entity_id=? ORDER BY id DESC LIMIT 100", (order["public_id"],))
    return arender(request, "admin/rq_detail.html", o=order, user=user, purchase=purchase, invoices=invoices, details=svc.details(order["id"]),
                   quote=Quote.from_json(order["quote_json"]), audit=audit, session=db.get("rq_sessions", order["session_id"]) if order["session_id"] else None)


# ------------------------------------------------------------------ purchases
@admin_required
async def purchases(request: Request):
    core = request.app.state.core
    page, size, offset = page_args(request, 50)
    status = request.query_params.get("status", "")
    kind = request.query_params.get("kind", "")
    q = request.query_params.get("q", "").strip()
    where, params = ["1=1"], []
    if status:
        where.append("p.status=?"); params.append(status)
    if kind:
        where.append("p.kind=?"); params.append(kind)
    if q:
        where.append("(p.public_id LIKE ? OR u.email LIKE ? OR p.title LIKE ?)"); params += [f"%{q}%"] * 3
    rows = core.db.all(f"SELECT p.*, u.email FROM purchases p LEFT JOIN users u ON u.id=p.user_id WHERE {' AND '.join(where)} ORDER BY p.id DESC LIMIT ? OFFSET ?", params + [size + 1, offset])
    kinds = [r["kind"] for r in core.db.all("SELECT DISTINCT kind FROM purchases ORDER BY kind")]
    return arender(request, "admin/purchases.html", rows=rows[:size], has_more=len(rows) > size, page=page, status=status, kind=kind, q=q, kinds=kinds, kind_labels=reports.KIND_LABELS)


@admin_required
async def purchase_detail(request: Request):
    core = request.app.state.core
    db = core.db
    p = db.one("SELECT * FROM purchases WHERE public_id=?", (request.path_params["public_id"],))
    if p is None:
        return redirect("/admin/purchases", request, "not found.")
    if request.method == "POST":
        f = await form_data(request)
        action = fval(f, "action")
        if action == "manual_paid":
            await core.payments.simulate_paid(p, request.state.viewer.user_id)
            return redirect(f"/admin/purchases/{p['public_id']}", request, "marked paid (manual settlement) and fulfilled.", "ok")
        if action == "cancel":
            core.payments.cancel_pending(p, "admin")
            return redirect(f"/admin/purchases/{p['public_id']}", request, "canceled.", "ok")
        if action == "poll":
            n = 0
            for inv in core.payments.invoices(p["id"]):
                if inv["np_payment_id"] and inv["status"] != "paid":
                    data = await core.np.payment_status(inv["np_payment_id"]) if core.np.enabled else None
                    if data:
                        await core.payments.apply_status(inv, data, "admin_poll"); n += 1
            return redirect(f"/admin/purchases/{p['public_id']}", request, f"polled {n} invoice(s).", "ok")
    invoices = core.payments.invoices(p["id"])
    events = {inv["id"]: core.payments.events(inv["id"]) for inv in invoices}
    user = db.get("users", p["user_id"]) if p["user_id"] else None
    return arender(request, "admin/purchase_detail.html", p=p, invoices=invoices, events=events, user=user, meta=loads(p["meta_json"], {}),
                   audit=db.all("SELECT * FROM audit_log WHERE entity_type IN ('purchase','invoice') AND (entity_id=? OR entity_id LIKE ?) ORDER BY id DESC", (p["public_id"], p["public_id"] + "-%")))


# ------------------------------------------------------------------ users
@admin_required
async def users(request: Request):
    core = request.app.state.core
    page, size, offset = page_args(request, 50)
    q = request.query_params.get("q", "").strip()
    flt = request.query_params.get("f", "")
    where, params = ["u.deleted_at IS NULL"], []
    if q:
        where.append("(u.email LIKE ? OR u.username LIKE ? OR u.display_name LIKE ? OR CAST(u.id AS TEXT)=?)"); params += [f"%{q}%"] * 3 + [q]
    ts = now_ts()
    if flt == "members":
        where.append("u.id IN (SELECT user_id FROM memberships WHERE status IN ('active','grace') AND current_period_end>?)"); params.append(ts)
    elif flt == "priority":
        where.append("u.priority_status='approved'")
    elif flt == "blocked":
        where.append("u.blocked=1")
    elif flt == "kyc":
        where.append("u.kyc_status IN ('required','pending')")
    elif flt == "spenders":
        where.append("u.total_spent_cents>0")
    order = {"spent": "u.total_spent_cents DESC", "new": "u.created_at DESC", "seen": "u.last_seen_at DESC"}.get(request.query_params.get("sort", ""), "u.last_seen_at DESC")
    rows = core.db.all(f"SELECT u.*, (SELECT t.name FROM memberships m JOIN tiers t ON t.id=m.tier_id WHERE m.user_id=u.id AND m.status IN ('active','grace') AND m.current_period_end>? ORDER BY t.rank DESC LIMIT 1) AS tier_name"
                       f" FROM users u WHERE {' AND '.join(where)} ORDER BY {order} LIMIT ? OFFSET ?", [ts] + params + [size + 1, offset])
    return arender(request, "admin/users.html", rows=rows[:size], has_more=len(rows) > size, page=page, q=q, flt=flt, sort=request.query_params.get("sort", ""))


@admin_required
async def user_detail(request: Request):
    core = request.app.state.core
    db = core.db
    u = db.get("users", int(request.path_params["user_id"]))
    if u is None:
        return redirect("/admin/users", request, "not found.")
    actor = request.state.viewer.user_id
    if request.method == "POST":
        f = await form_data(request)
        action = fval(f, "action")
        if action == "block":
            db.update("users", u["id"], blocked=1, blocked_reason=fval(f, "reason")[:300])
            from .. import auth
            auth.revoke_all_sessions(db, u["id"])
            db.audit("user.blocked", actor_user_id=actor, actor_role="admin", entity_type="user", entity_id=u["id"], data={"reason": fval(f, "reason")})
        elif action == "unblock":
            db.update("users", u["id"], blocked=0, blocked_reason=None)
            db.audit("user.unblocked", actor_user_id=actor, actor_role="admin", entity_type="user", entity_id=u["id"])
        elif action == "mute":
            hours = fint(f, "hours", 24) or 24
            db.update("users", u["id"], muted_until=now_ts() + hours * 3600)
            db.audit("user.muted", actor_user_id=actor, actor_role="admin", entity_type="user", entity_id=u["id"], data={"hours": hours})
        elif action == "priority":
            st = fval(f, "priority_status")
            db.update("users", u["id"], priority_status=st, priority_at=now_ts() if st == "approved" else None)
            db.audit("user.priority", actor_user_id=actor, actor_role="admin", entity_type="user", entity_id=u["id"], data={"status": st})
        elif action == "kyc":
            db.update("users", u["id"], kyc_status=fval(f, "kyc_status"), kyc_note=fval(f, "kyc_note")[:500])
            db.insert("kyc_checks", user_id=u["id"], provider="manual", status=fval(f, "kyc_status"), reference=fval(f, "kyc_note")[:200], created_at=now_ts())
            db.audit("user.kyc", actor_user_id=actor, actor_role="admin", entity_type="user", entity_id=u["id"], data={"status": fval(f, "kyc_status")})
        elif action == "note":
            db.update("users", u["id"], admin_note=fval(f, "note")[:4000])
            db.audit("user.note", actor_user_id=actor, actor_role="admin", entity_type="user", entity_id=u["id"])
        elif action == "credit":
            cents = fcents(f, "amount") or 0
            if cents:
                db.wallet_apply(u["id"], cents, f"admin adjustment: {fval(f, 'reason')[:100]}", "admin", actor)
                db.audit("user.credit", actor_user_id=actor, actor_role="admin", entity_type="user", entity_id=u["id"], data={"cents": cents})
        elif action == "grant":
            tier = db.get("tiers", fint(f, "tier_id") or 0)
            if tier:
                members.grant_period(core, u["id"], tier["id"], (fint(f, "days", 28) or 28) * 86400, 0, None, "admin")
                db.audit("user.membership_granted", actor_user_id=actor, actor_role="admin", entity_type="user", entity_id=u["id"], data={"tier": tier["id"], "days": fint(f, "days", 28)})
        elif action == "role":
            if u["id"] != actor:
                db.update("users", u["id"], role=fval(f, "role") if fval(f, "role") in ("user", "admin") else "user")
                db.audit("user.role", actor_user_id=actor, actor_role="admin", entity_type="user", entity_id=u["id"], data={"role": fval(f, "role")})
        elif action == "message":
            body = fval(f, "body")
            if body:
                messaging.send(db, u["id"], "creator", body, price_cents=fcents(f, "price") or None)
        elif action == "ai_note":
            note = await _ai_summary(core, u)
            if note:
                db.insert("ai_notes", user_id=u["id"], note=note, created_at=now_ts())
        return redirect(f"/admin/users/{u['id']}", request, "done.", "ok")
    m, tier = active_membership(db, u["id"])
    return arender(request, "admin/user_detail.html", u=u, membership=m, tier=tier, tiers=members.tiers(db, False),
                   memberships=db.all("SELECT m.*, t.name AS tier_name FROM memberships m JOIN tiers t ON t.id=m.tier_id WHERE m.user_id=? ORDER BY m.id DESC", (u["id"],)),
                   purchases=db.all("SELECT * FROM purchases WHERE user_id=? ORDER BY id DESC LIMIT 100", (u["id"],)),
                   tips=db.all("SELECT * FROM tips WHERE user_id=? ORDER BY id DESC LIMIT 50", (u["id"],)),
                   rq=db.all("SELECT * FROM rq_orders WHERE user_id=? ORDER BY id DESC", (u["id"],)),
                   customs=db.all("SELECT * FROM custom_orders WHERE user_id=? ORDER BY id DESC", (u["id"],)),
                   bookings=db.all("SELECT b.*, s.start_at FROM call_bookings b JOIN call_slots s ON s.id=b.slot_id WHERE b.user_id=? ORDER BY s.start_at DESC", (u["id"],)),
                   sessions=db.all("SELECT * FROM sessions WHERE user_id=? ORDER BY last_seen_at DESC LIMIT 20", (u["id"],)),
                   audit=db.all("SELECT * FROM audit_log WHERE actor_user_id=? OR (entity_type='user' AND entity_id=?) ORDER BY id DESC LIMIT 100", (u["id"], str(u["id"]))),
                   wallet=db.all("SELECT * FROM wallet_ledger WHERE user_id=? ORDER BY id DESC LIMIT 30", (u["id"],)),
                   ai_notes=db.all("SELECT * FROM ai_notes WHERE user_id=? ORDER BY id DESC LIMIT 5", (u["id"],)),
                   referrals=db.all("SELECT r.*, x.email FROM referrals r JOIN users x ON x.id=r.referred_id WHERE r.referrer_id=?", (u["id"],)),
                   custom=loads(u["custom_fields_json"], {}), ai_enabled=bool(core.cfg.openai_api_key))


async def _ai_summary(core, u) -> str | None:
    """Optional AI subscriber note (OpenAI-compatible chat API). Disabled without OPENAI_API_KEY."""
    if not core.cfg.openai_api_key:
        return None
    import httpx
    db = core.db
    facts = {
        "spent": usd(u["total_spent_cents"]), "purchases": u["purchases_count"], "created": core.local(u["created_at"]), "priority": u["priority_status"],
        "recent_messages": [m["body"][:200] for m in db.all("SELECT body FROM messages WHERE thread_user_id=? AND sender_role='user' ORDER BY id DESC LIMIT 10", (u["id"],))],
        "recent_purchases": [f"{p['kind']} {usd(p['total_cents'])}" for p in db.all("SELECT kind, total_cents FROM purchases WHERE user_id=? AND status='paid' ORDER BY id DESC LIMIT 10", (u["id"],))],
    }
    prompt = ("summarize this fan for the creator in 4 short lowercase lines: spend pattern, interests from messages, risk flags, one suggested upsell. "
              "no names. facts: " + json.dumps(facts))
    try:
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.post("https://api.openai.com/v1/chat/completions", headers={"Authorization": f"Bearer {core.cfg.openai_api_key}"},
                             json={"model": "gpt-4o-mini", "messages": [{"role": "user", "content": prompt}], "max_tokens": 250})
            return r.json()["choices"][0]["message"]["content"].strip()
    except Exception:
        return None


# ------------------------------------------------------------------ messages
@admin_required
async def inbox(request: Request):
    core = request.app.state.core
    page, size, offset = page_args(request, 40)
    unread = request.query_params.get("unread") == "1"
    rows = messaging.inbox(core.db, size + 1, offset, unread_only=unread)
    return arender(request, "admin/inbox.html", rows=rows[:size], has_more=len(rows) > size, page=page, unread=unread)


@admin_required
async def thread(request: Request):
    core = request.app.state.core
    db = core.db
    u = db.get("users", int(request.path_params["user_id"]))
    if u is None:
        return redirect("/admin/messages")
    if request.method == "POST":
        f = await form_data(request)
        body = fval(f, "body")
        media_id = None
        ups = files_of(f, "file")
        if ups:
            media_id = await core.media.save_upload(ups[0], request.state.viewer.user_id, folder="dm_out", source="admin")
        vault_id = fint(f, "vault_media_id")
        if vault_id and db.get("media", vault_id):
            media_id = vault_id
        if body or media_id:
            scheduled = parse_dt_local(fval(f, "scheduled_at"), core.tz) if fval(f, "scheduled_at") else None
            messaging.send(db, u["id"], "creator", body, media_id=media_id, is_voice=fbool(f, "voice"), price_cents=fcents(f, "price") or None, scheduled_at=scheduled)
            db.audit("dm.sent", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type="user", entity_id=u["id"], data={"price": fcents(f, "price"), "media": media_id})
        return redirect(f"/admin/messages/{u['id']}")
    rows = messaging.thread(db, u["id"], limit=300)
    messaging.mark_read(db, u["id"], "creator")
    m, tier = active_membership(db, u["id"])
    return arender(request, "admin/thread.html", u=u, rows=rows, tier=tier, summary=messaging.thread_summary(db, u["id"]),
                   recent_vault=core.media.search("", limit=12))


@admin_required
async def inbox_events(request: Request):
    return StreamingResponse(messaging.subscribe("admin:inbox"), media_type="text/event-stream", headers={"Cache-Control": "no-cache"})


@admin_required
async def mass(request: Request):
    core = request.app.state.core
    db = core.db
    if request.method == "POST":
        f = await form_data(request)
        rules = {}
        seg = fint(f, "segment_id")
        if seg:
            s = db.get("segments", seg)
            rules = loads(s["rules_json"], {}) if s else {}
        else:
            if fval(f, "tier_ranks"):
                rules["tier_ranks"] = [int(x) for x in fval(f, "tier_ranks").split(",") if x.strip().isdigit()]
            if fval(f, "audience") == "members":
                rules["members"] = True
            elif fval(f, "audience") == "followers":
                rules["members"] = False
            if fbool(f, "priority"):
                rules["priority"] = True
            if fint(f, "inactive_days"):
                rules["inactive_days"] = fint(f, "inactive_days")
        media_id = None
        ups = files_of(f, "file")
        if ups:
            media_id = await core.media.save_upload(ups[0], request.state.viewer.user_id, folder="mass", source="admin")
        if fint(f, "vault_media_id"):
            media_id = fint(f, "vault_media_id")
        mid = db.insert("mass_messages", title=fval(f, "title")[:200], body_template=fval(f, "body"), media_id=media_id, price_cents=fcents(f, "price") or None,
                        segment_json=json.dumps(rules), scheduled_at=parse_dt_local(fval(f, "scheduled_at"), core.tz) if fval(f, "scheduled_at") else None,
                        variant=fval(f, "variant")[:10] or None, created_at=now_ts())
        if fval(f, "action") == "send_now":
            n = messaging.send_mass(db, mid)
            return redirect("/admin/mass", request, f"sent to {n} users.", "ok")
        preview = len(members.segment_user_ids(db, rules))
        return redirect("/admin/mass", request, f"saved. {preview} recipients match. it sends at the scheduled time." if rules else "saved.", "ok")
    rows = db.all("SELECT * FROM mass_messages ORDER BY id DESC LIMIT 50")
    return arender(request, "admin/mass.html", rows=rows, segments=db.all("SELECT * FROM segments ORDER BY id"), tiers=members.tiers(db, False))


@admin_required
async def mass_send(request: Request):
    core = request.app.state.core
    n = messaging.send_mass(core.db, int(request.path_params["mass_id"]))
    return redirect("/admin/mass", request, f"sent to {n} users.", "ok")


# ------------------------------------------------------------------ posts
@admin_required
async def posts(request: Request):
    core = request.app.state.core
    page, size, offset = page_args(request, 40)
    rows = core.db.all("SELECT * FROM posts WHERE deleted_at IS NULL ORDER BY id DESC LIMIT ? OFFSET ?", (size + 1, offset))
    return arender(request, "admin/posts.html", rows=rows[:size], has_more=len(rows) > size, page=page)


@admin_required
async def post_form(request: Request):
    core = request.app.state.core
    db = core.db
    pid = request.path_params.get("post_id")
    post = db.get("posts", int(pid)) if pid else None
    if request.method == "POST":
        f = await form_data(request)
        action = fval(f, "action")
        if post is not None and action == "delete":
            db.update("posts", post["id"], deleted_at=now_ts(), updated_at=now_ts())
            db.audit("post.deleted", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type="post", entity_id=post["id"])
            return redirect("/admin/posts", request, "deleted.", "ok")
        if post is not None and action in ("pin", "unpin"):
            err = content.set_pin(db, core.settings, post["id"], action == "pin")
            return redirect(f"/admin/posts/{post['id']}", request, err or "done.", "error" if err else "ok")
        media_ids = [int(x) for x in fval(f, "media_ids").replace(" ", "").split(",") if x.isdigit()]
        for up in files_of(f, "files"):
            media_ids.append(await core.media.save_upload(up, request.state.viewer.user_id, folder="posts", source="admin"))
        data = {
            "type": fval(f, "type"), "title": fval(f, "title"), "body_md": fval(f, "body_md"), "visibility": fval(f, "visibility"),
            "min_tier_rank": fint(f, "min_tier_rank", 0), "ppv_price_cents": fcents(f, "ppv_price_cents"), "public_price_cents": fcents(f, "public_price_cents"),
            "follower_price_cents": fcents(f, "follower_price_cents"), "published_at": parse_dt_local(fval(f, "published_at"), core.tz),
            "expires_at": parse_dt_local(fval(f, "expires_at"), core.tz), "story": fbool(f, "story"), "collection_id": fint(f, "collection_id"),
            "series_order": fint(f, "series_order"), "allow_comments": fbool(f, "allow_comments"), "comments_price_cents": fcents(f, "comments_price_cents"),
            "watermark": fbool(f, "watermark"), "teaser_text": fval(f, "teaser_text"), "tags": [t.strip() for t in fval(f, "tags").split(",") if t.strip()],
            "poll_question": fval(f, "poll_question"), "poll_options": fval(f, "poll_options").split("\n"), "poll_multiple": fbool(f, "poll_multiple"),
            "poll_anonymous": fbool(f, "poll_anonymous"), "poll_closes_at": parse_dt_local(fval(f, "poll_closes_at"), core.tz),
        }
        if post is None:
            new_id = content.create_post(db, core.settings, data, media_ids, request.state.viewer.user_id)
            return redirect(f"/admin/posts/{new_id}", request, "post created.", "ok")
        db.update("posts", post["id"], type=data["type"], title=data["title"], body_md=data["body_md"], visibility=data["visibility"], min_tier_rank=data["min_tier_rank"],
                  ppv_price_cents=data["ppv_price_cents"], public_price_cents=data["public_price_cents"], follower_price_cents=data["follower_price_cents"],
                  published_at=data["published_at"] or post["published_at"], expires_at=data["expires_at"], collection_id=data["collection_id"], series_order=data["series_order"],
                  allow_comments=1 if data["allow_comments"] else 0, comments_price_cents=data["comments_price_cents"], watermark=1 if data["watermark"] else 0,
                  teaser_text=data["teaser_text"], tags_json=json.dumps(data["tags"]), is_archived=1 if fbool(f, "archived") else 0, updated_at=now_ts())
        db.execute("DELETE FROM post_media WHERE post_id=?", (post["id"],))
        for i, mid in enumerate(media_ids):
            db.execute("INSERT OR IGNORE INTO post_media(post_id, media_id, position, is_preview) VALUES (?,?,?,?)", (post["id"], mid, i, 1 if i == 0 else 0))
        db.audit("post.updated", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type="post", entity_id=post["id"])
        return redirect(f"/admin/posts/{post['id']}", request, "saved.", "ok")
    media = db.all("SELECT m.* FROM post_media pm JOIN media m ON m.id=pm.media_id WHERE pm.post_id=? ORDER BY pm.position", (post["id"],)) if post else []
    poll = db.one("SELECT * FROM polls WHERE post_id=?", (post["id"],)) if post else None
    return arender(request, "admin/post_form.html", post=post, media=media, poll=poll, poll_options="\n".join(loads(poll["options_json"], [])) if poll else "",
                   collections=db.all("SELECT * FROM collections ORDER BY id DESC"), types=content.POST_TYPES, vis=content.VISIBILITIES,
                   tags=",".join(loads(post["tags_json"], [])) if post else "", recent_vault=core.media.search("", limit=24))


# ------------------------------------------------------------------ vault
@admin_required
async def vault(request: Request):
    core = request.app.state.core
    db = core.db
    if request.method == "POST":
        f = await form_data(request)
        action = fval(f, "action")
        if action == "upload":
            n = 0
            tags = [t.strip() for t in fval(f, "tags").split(",") if t.strip()]
            for up in files_of(f, "files"):
                await core.media.save_upload(up, request.state.viewer.user_id, folder=fval(f, "folder") or None, title=fval(f, "title") or None,
                                             caption=fval(f, "caption") or None, tags=tags, source="vault")
                n += 1
            return redirect("/admin/vault", request, f"uploaded {n} file(s).", "ok")
        ids = [int(x) for x in (f.get("ids") or []) if str(x).isdigit()] if isinstance(f.get("ids"), list) else ([int(f["ids"])] if f.get("ids") and str(f["ids"]).isdigit() else [])
        if action == "delete":
            for mid in ids:
                m = db.get("media", mid)
                if m:
                    core.media.delete_files(m)
                    db.update("media", mid, deleted_at=now_ts())
            db.audit("media.deleted", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type="media", entity_id=",".join(map(str, ids)))
            return redirect("/admin/vault", request, f"deleted {len(ids)}.", "ok")
        if action == "export":
            data = await asyncio.to_thread(core.media.export_zip, ids)
            return Response(data, media_type="application/zip", headers={"Content-Disposition": 'attachment; filename="vault-export.zip"'})
        if action == "move":
            for mid in ids:
                db.update("media", mid, folder=fval(f, "folder") or None)
            return redirect("/admin/vault", request, "moved.", "ok")
        if action == "expire":
            exp = parse_dt_local(fval(f, "expires_at"), core.tz)
            for mid in ids:
                db.update("media", mid, expires_at=exp)
            return redirect("/admin/vault", request, "expiry set.", "ok")
    q = request.query_params.get("q", "")
    kind = request.query_params.get("kind") or None
    folder = request.query_params.get("folder") or None
    page, size, offset = page_args(request, 60)
    rows = core.media.search(q, kind, folder, limit=size + 1, offset=offset)
    folders = [r["folder"] for r in db.all("SELECT DISTINCT folder FROM media WHERE folder IS NOT NULL AND deleted_at IS NULL ORDER BY folder")]
    stats = db.one("SELECT COUNT(*) n, COALESCE(SUM(size),0) bytes FROM media WHERE deleted_at IS NULL")
    return arender(request, "admin/vault.html", rows=rows[:size], has_more=len(rows) > size, page=page, q=q, kind=kind, folder=folder, folders=folders, stats=stats)


@admin_required
async def vault_item(request: Request):
    core = request.app.state.core
    db = core.db
    m = db.get("media", int(request.path_params["media_id"]))
    if m is None:
        return redirect("/admin/vault")
    if request.method == "POST":
        f = await form_data(request)
        tags = [t.strip() for t in fval(f, "tags").split(",") if t.strip()]
        db.update("media", m["id"], title=fval(f, "title") or None, caption=fval(f, "caption") or None, alt=fval(f, "alt") or None, folder=fval(f, "folder") or None,
                  tags_json=json.dumps(tags), is_public=1 if fbool(f, "is_public") else 0, expires_at=parse_dt_local(fval(f, "expires_at"), core.tz))
        db.execute("DELETE FROM media_fts WHERE rowid=?", (m["id"],))
        db.execute("INSERT INTO media_fts(rowid, title, caption, tags, filename) VALUES (?,?,?,?,?)", (m["id"], fval(f, "title"), fval(f, "caption"), " ".join(tags), m["filename"]))
        return redirect(f"/admin/vault/{m['id']}", request, "saved.", "ok")
    usage = {"posts": db.all("SELECT p.id, p.title FROM post_media pm JOIN posts p ON p.id=pm.post_id WHERE pm.media_id=?", (m["id"],)),
             "messages": db.count("messages", "media_id=?", (m["id"],)), "views": db.count("watermark_log", "media_id=?", (m["id"],))}
    return arender(request, "admin/vault_item.html", m=m, tags=",".join(loads(m["tags_json"], [])), usage=usage,
                   fingerprints=db.all("SELECT * FROM watermark_log WHERE media_id=? ORDER BY id DESC LIMIT 50", (m["id"],)))


@admin_required
async def fingerprint_lookup(request: Request):
    core = request.app.state.core
    fp = request.query_params.get("fp", "").strip()
    rows = core.db.all("SELECT w.*, u.email, m.filename FROM watermark_log w LEFT JOIN users u ON u.id=w.user_id LEFT JOIN media m ON m.id=w.media_id WHERE w.fingerprint LIKE ? ORDER BY w.id DESC LIMIT 50", (f"%{fp}%",)) if fp else []
    return arender(request, "admin/fingerprint.html", fp=fp, rows=rows)


from .routes2 import routes as routes2  # noqa: E402

routes = [
    Route("/admin", dashboard), Route("/admin/r/{key}", res_list), Route("/admin/r/{key}/new", res_form, methods=["GET", "POST"]),
    Route("/admin/r/{key}/{rid:int}", res_form, methods=["GET", "POST"]),
    Route("/admin/requests", rq_list), Route("/admin/requests/{public_id}", rq_detail, methods=["GET", "POST"]),
    Route("/admin/purchases", purchases), Route("/admin/purchases/{public_id}", purchase_detail, methods=["GET", "POST"]),
    Route("/admin/users", users), Route("/admin/users/{user_id:int}", user_detail, methods=["GET", "POST"]),
    Route("/admin/messages", inbox), Route("/admin/messages/events", inbox_events), Route("/admin/messages/{user_id:int}", thread, methods=["GET", "POST"]),
    Route("/admin/mass", mass, methods=["GET", "POST"]), Route("/admin/mass/{mass_id:int}/send", mass_send, methods=["POST"]),
    Route("/admin/posts", posts), Route("/admin/posts/new", post_form, methods=["GET", "POST"]), Route("/admin/posts/{post_id:int}", post_form, methods=["GET", "POST"]),
    Route("/admin/vault", vault, methods=["GET", "POST"]), Route("/admin/vault/{media_id:int}", vault_item, methods=["GET", "POST"]), Route("/admin/fingerprint", fingerprint_lookup),
] + routes2
