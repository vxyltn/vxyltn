"""Admin panel part 2: live, calls, customs, shop orders, priority/kyc/contact/dmca, channels, reports, audit, settings, pricing, backups, integrations."""
from __future__ import annotations

import asyncio
import csv
import io
import os

from starlette.requests import Request
from starlette.responses import FileResponse, Response
from starlette.routing import Route

from .. import community, customs, live, members, reports
from ..money import usd
from ..requestsys import catalog as rq_catalog
from ..requestsys.pricing import RqPricing
from ..settings import EDITABLE
from ..util import loads, now_ts, parse_dt_local, parse_int, parse_money_cents
from ..web import admin_required, fbool, fcents, files_of, fint, form_data, fval, page_args, redirect
from .common import arender


# ------------------------------------------------------------------ live
@admin_required
async def live_admin(request: Request):
    core = request.app.state.core
    db = core.db
    if request.method == "POST":
        f = await form_data(request)
        sid = fint(f, "stream_id")
        s = db.get("streams", sid) if sid else None
        action = fval(f, "action")
        if s is None:
            return redirect("/admin/live")
        if action in ("live", "ended", "canceled", "scheduled"):
            live.set_status(db, s["id"], action, request.state.viewer.user_id)
        elif action == "recording":
            ups = files_of(f, "file")
            mid = fint(f, "media_id")
            if ups:
                mid = await core.media.save_upload(ups[0], request.state.viewer.user_id, folder="recordings", source="recording")
            if mid:
                live.attach_recording(db, s["id"], mid, request.state.viewer.user_id)
        elif action == "hide_chat":
            db.update("stream_chat", fint(f, "chat_id"), hidden=1)
        elif action == "say":
            if fval(f, "body"):
                live.post_chat(db, s["id"], request.state.viewer.user_id, fval(f, "body"), kind="system" if fbool(f, "system") else "chat")
        return redirect(f"/admin/live?stream={s['id']}", request, "done.", "ok")
    streams = db.all("SELECT * FROM streams ORDER BY CASE status WHEN 'live' THEN 0 WHEN 'scheduled' THEN 1 ELSE 2 END, scheduled_at DESC LIMIT 100")
    sid = parse_int(request.query_params.get("stream"))
    s = db.get("streams", sid) if sid else None
    chat = live.chat(db, s["id"], limit=200) if s else []
    tickets = db.count("stream_tickets", "stream_id=?", (s["id"],)) if s else 0
    rsvps = db.count("stream_rsvps", "stream_id=?", (s["id"],)) if s else 0
    return arender(request, "admin/live.html", streams=streams, s=s, chat=chat, tickets=tickets, rsvps=rsvps, viewers=live.viewers_now(db, s["id"]) if s else 0,
                   provider=core.cfg.livestream_provider)


# ------------------------------------------------------------------ calls
@admin_required
async def calls_admin(request: Request):
    core = request.app.state.core
    db = core.db
    if request.method == "POST":
        f = await form_data(request)
        action = fval(f, "action")
        if action == "bulk":
            start = parse_dt_local(fval(f, "start"), core.tz)
            count = max(1, min(48, fint(f, "count", 4) or 4))
            dur = fint(f, "duration", 15) or 15
            gap = fint(f, "gap", 10) or 10
            if start:
                t = start
                for _ in range(count):
                    db.insert("call_slots", kind=fval(f, "kind") or "video", start_at=t, end_at=t + dur * 60, duration_min=dur, price_cents=fcents(f, "price"),
                              per_minute_cents=fcents(f, "per_minute"), min_tier_rank=fint(f, "min_tier_rank", 0) or 0, priority_only=1 if fbool(f, "priority_only") else 0,
                              buffer_min=gap, notes=fval(f, "notes") or None, created_at=now_ts())
                    t += (dur + gap) * 60
                db.audit("call_slots.bulk", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type="call_slots", entity_id=count)
            return redirect("/admin/calls", request, f"created {count} slots.", "ok")
        bid = fint(f, "booking_id")
        b = db.get("call_bookings", bid) if bid else None
        if b is not None:
            if action == "join_url":
                db.update("call_bookings", b["id"], join_url=fval(f, "join_url") or None, updated_at=now_ts())
                db.notify(b["user_id"], "call", "call link ready", "", "/calls/mine")
            elif action in ("completed", "no_show", "canceled"):
                db.update("call_bookings", b["id"], status=action, updated_at=now_ts())
                if action == "canceled":
                    db.execute("UPDATE call_slots SET status='open' WHERE id=?", (b["slot_id"],))
                else:
                    db.execute("UPDATE call_slots SET status='done' WHERE id=?", (b["slot_id"],))
            elif action == "notes":
                db.update("call_bookings", b["id"], admin_notes=fval(f, "admin_notes")[:4000], updated_at=now_ts())
            elif action == "recording":
                ups = files_of(f, "file")
                if ups:
                    mid = await core.media.save_upload(ups[0], request.state.viewer.user_id, folder="call_recordings", source="recording")
                    db.update("call_bookings", b["id"], recording_media_id=mid, updated_at=now_ts())
            db.audit(f"call_booking.{action}", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type="call_booking", entity_id=b["id"])
        return redirect("/admin/calls", request, "done.", "ok")
    bookings = db.all("SELECT b.*, s.start_at, s.end_at, s.kind AS slot_kind, u.email FROM call_bookings b JOIN call_slots s ON s.id=b.slot_id JOIN users u ON u.id=b.user_id ORDER BY s.start_at DESC LIMIT 100")
    slots = db.all("SELECT * FROM call_slots WHERE start_at>? ORDER BY start_at LIMIT 100", (now_ts() - 86400,))
    return arender(request, "admin/calls.html", bookings=bookings, slots=slots, provider=core.cfg.call_provider)


# ------------------------------------------------------------------ customs
@admin_required
async def customs_admin(request: Request):
    core = request.app.state.core
    status = request.query_params.get("status") or None
    return arender(request, "admin/customs.html", rows=customs.queue(core.db, status), status=status, statuses=customs.STATUSES)


@admin_required
async def custom_detail(request: Request):
    core = request.app.state.core
    db = core.db
    o = db.one("SELECT * FROM custom_orders WHERE public_id=?", (request.path_params["public_id"],))
    if o is None:
        return redirect("/admin/customs")
    actor = request.state.viewer.user_id
    if request.method == "POST":
        f = await form_data(request)
        action = fval(f, "action")
        if action == "quote":
            customs.quote(db, o["id"], fcents(f, "quote") or 0, parse_dt_local(fval(f, "deadline"), core.tz), fint(f, "revisions", 1) or 1, fval(f, "note"), actor)
            if fint(f, "deposit_pct") is not None:
                db.update("custom_orders", o["id"], deposit_pct=max(0, min(100, fint(f, "deposit_pct"))))
        elif action == "decline":
            customs.decline(db, o["id"], fval(f, "note"), actor)
        elif action == "status":
            customs.set_status(db, o["id"], fval(f, "status"), actor, fval(f, "note"))
        elif action == "deliver":
            ids = [int(x) for x in fval(f, "media_ids").replace(" ", "").split(",") if x.isdigit()]
            for up in files_of(f, "files"):
                ids.append(await core.media.save_upload(up, actor, folder=f"deliveries/{o['public_id']}", source="delivery"))
            customs.deliver(db, o["id"], ids, fval(f, "note"), actor)
        elif action == "message":
            if fval(f, "body"):
                db.insert("custom_messages", order_id=o["id"], sender_role="creator", body=fval(f, "body")[:4000], created_at=now_ts())
                db.notify(o["user_id"], "custom", f"{o['public_id']}: message", fval(f, "body")[:120], f"/customs/{o['public_id']}")
        elif action == "notes":
            db.update("custom_orders", o["id"], creator_notes=fval(f, "creator_notes")[:4000], updated_at=now_ts())
        return redirect(f"/admin/customs/{o['public_id']}", request, "done.", "ok")
    return arender(request, "admin/custom_detail.html", o=o, user=db.get("users", o["user_id"]), specs=loads(o["specs_json"], {}), messages=customs.messages(db, o["id"]),
                   attachments=customs.attachments(db, o), deliverables=customs.deliverables(db, o), deposit=customs.deposit_cents(o), balance=customs.balance_cents(o),
                   statuses=customs.STATUSES, purchases=db.all("SELECT * FROM purchases WHERE entity_type='custom_order' AND entity_id=? ORDER BY id", (o["id"],)))


# ------------------------------------------------------------------ shop orders
@admin_required
async def shop_orders(request: Request):
    core = request.app.state.core
    db = core.db
    if request.method == "POST":
        f = await form_data(request)
        o = db.get("shop_orders", fint(f, "order_id") or 0)
        if o is not None:
            action = fval(f, "action")
            if action == "ship":
                db.update("shop_orders", o["id"], status="shipped", carrier=fval(f, "carrier")[:60], tracking=fval(f, "tracking")[:120], updated_at=now_ts())
                if o["user_id"]:
                    db.notify(o["user_id"], "shop", f"order {o['public_id']} shipped", f"{fval(f, 'carrier')} {fval(f, 'tracking')}", f"/shop/orders/{o['public_id']}")
            elif action in ("delivered", "canceled", "fulfilling"):
                db.update("shop_orders", o["id"], status=action, updated_at=now_ts())
            elif action == "notes":
                db.update("shop_orders", o["id"], notes=fval(f, "notes")[:2000], updated_at=now_ts())
            db.audit(f"shop_order.{action}", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type="shop_order", entity_id=o["public_id"])
        return redirect("/admin/shop-orders", request, "done.", "ok")
    status = request.query_params.get("status", "")
    where, params = ("WHERE status=?", (status,)) if status else ("", ())
    rows = db.all(f"SELECT o.*, u.email AS user_email FROM shop_orders o LEFT JOIN users u ON u.id=o.user_id {where} ORDER BY o.id DESC LIMIT 200", params)
    return arender(request, "admin/shop_orders.html", rows=[dict(r, items=loads(r["items_json"], []), shipping=loads(r["shipping_json"], {}), coa=loads(r["coa_json"], [])) for r in rows], status=status)


@admin_required
async def coa_pdf(request: Request):
    core = request.app.state.core
    serial = request.path_params["serial"]
    row = core.db.one("SELECT * FROM shop_orders WHERE coa_json LIKE ?", (f'%"{serial}"%',))
    if row is None:
        return Response("not found", status_code=404)
    item = next((c for c in loads(row["coa_json"], []) if c["serial"] == serial), None)
    from ..pdfgen import build_coa_pdf
    data = await asyncio.to_thread(build_coa_pdf, core, serial, item["product"], row["email"] or f"order {row['public_id']}", item["issued_at"], row["public_id"])
    return Response(data, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{serial}.pdf"'})


# ------------------------------------------------------------------ priority / kyc / contact / dmca
@admin_required
async def priority_admin(request: Request):
    core = request.app.state.core
    db = core.db
    if request.method == "POST":
        f = await form_data(request)
        members.review_priority(db, fint(f, "app_id") or 0, fval(f, "decision") == "approve", fval(f, "note"), request.state.viewer.user_id)
        return redirect("/admin/priority", request, "reviewed.", "ok")
    apps = db.all("SELECT a.*, u.email, u.total_spent_cents FROM priority_applications a JOIN users u ON u.id=a.user_id ORDER BY CASE a.status WHEN 'pending' THEN 0 ELSE 1 END, a.id DESC LIMIT 200")
    vips = db.all("SELECT id, email, username, total_spent_cents, priority_at FROM users WHERE priority_status='approved' ORDER BY total_spent_cents DESC")
    return arender(request, "admin/priority.html", apps=apps, vips=vips, rules=members.priority_rules(core.settings))


@admin_required
async def kyc_admin(request: Request):
    core = request.app.state.core
    db = core.db
    rows = db.all("SELECT id, email, username, kyc_status, kyc_note, total_spent_cents, country FROM users WHERE kyc_status<>'none' ORDER BY CASE kyc_status WHEN 'required' THEN 0 WHEN 'pending' THEN 1 ELSE 2 END, total_spent_cents DESC")
    checks = db.all("SELECT k.*, u.email FROM kyc_checks k JOIN users u ON u.id=k.user_id ORDER BY k.id DESC LIMIT 100")
    return arender(request, "admin/kyc.html", rows=rows, checks=checks, threshold=core.settings.int("kyc_threshold_cents"), provider=core.cfg.kyc_provider)


@admin_required
async def contact_admin(request: Request):
    core = request.app.state.core
    db = core.db
    if request.method == "POST":
        f = await form_data(request)
        c = db.get("contact_requests", fint(f, "id") or 0)
        if c is not None:
            action = fval(f, "action")
            if action == "status":
                db.update("contact_requests", c["id"], status=fval(f, "status"), admin_note=fval(f, "note")[:2000], updated_at=now_ts())
            elif action == "manual_invoice":
                cents = fcents(f, "amount") or c["amount_cents"] or 0
                if cents > 0:
                    p = core.payments.create_purchase(user_id=c["user_id"], kind=fval(f, "kind") or "wallet", title=fval(f, "title") or f"manual settlement {c['id']}", total_cents=cents,
                                                      exempt_cap=True, guest_email=None if c["user_id"] else c["email"], meta={"contact_request": c["id"]})
                    db.update("contact_requests", c["id"], status="invoiced", admin_note=(c["admin_note"] or "") + f"\npurchase {p['public_id']}", updated_at=now_ts())
                    db.audit("contact.manual_invoice", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type="contact_request", entity_id=c["id"], data={"purchase": p["public_id"], "cents": cents})
                    if c["user_id"]:
                        db.notify(c["user_id"], "payment", "manual invoice ready", usd(cents), f"/pay/{p['public_id']}")
                    return redirect("/admin/contact", request, f"manual purchase {p['public_id']} created (cap exempt). share /pay/{p['public_id']}.", "ok")
            db.audit(f"contact.{action}", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type="contact_request", entity_id=c["id"])
        return redirect("/admin/contact", request, "done.", "ok")
    rows = db.all("SELECT * FROM contact_requests ORDER BY CASE status WHEN 'new' THEN 0 ELSE 1 END, id DESC LIMIT 200")
    return arender(request, "admin/contact.html", rows=rows)


@admin_required
async def dmca_admin(request: Request):
    core = request.app.state.core
    db = core.db
    if request.method == "POST":
        f = await form_data(request)
        n = db.get("dmca_notices", fint(f, "id") or 0)
        if n is not None:
            db.update("dmca_notices", n["id"], status=fval(f, "status"), admin_note=fval(f, "note")[:2000])
            db.audit("dmca.status", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type="dmca", entity_id=n["id"], data={"status": fval(f, "status")})
        return redirect("/admin/dmca", request, "done.", "ok")
    return arender(request, "admin/dmca.html", notices=db.all("SELECT * FROM dmca_notices ORDER BY id DESC LIMIT 200"), leaks=db.all("SELECT * FROM leak_alerts ORDER BY id DESC LIMIT 100"))


# ------------------------------------------------------------------ channels (posting)
@admin_required
async def channels_admin(request: Request):
    core = request.app.state.core
    db = core.db
    if request.method == "POST":
        f = await form_data(request)
        ch = db.get("channels", fint(f, "channel_id") or 0)
        if ch is not None:
            action = fval(f, "action")
            if action == "post":
                mid = None
                ups = files_of(f, "file")
                if ups:
                    mid = await core.media.save_upload(ups[0], request.state.viewer.user_id, folder=f"channels/{ch['slug']}", source="admin")
                if fint(f, "vault_media_id"):
                    mid = fint(f, "vault_media_id")
                db.insert("channel_posts", channel_id=ch["id"], body=fval(f, "body"), media_id=mid, price_cents=fcents(f, "price"), created_at=now_ts())
                for m in db.all("SELECT user_id FROM channel_members WHERE channel_id=?", (ch["id"],)):
                    db.notify(m["user_id"], "channel", f"new in {ch['name']}", fval(f, "body")[:100], f"/channels/{ch['slug']}")
            elif action == "add_member":
                u = db.one("SELECT id FROM users WHERE lower(email)=lower(?) OR username=?", (fval(f, "who"), fval(f, "who")))
                if u:
                    community.join_channel(db, ch["id"], u["id"], None, fval(f, "role") or "member")
            elif action == "remove_member":
                db.execute("DELETE FROM channel_members WHERE channel_id=? AND user_id=?", (ch["id"], fint(f, "user_id")))
            elif action == "hide_chat":
                db.update("channel_chat", fint(f, "chat_id"), hidden=1)
            db.audit(f"channel.{action}", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type="channel", entity_id=ch["id"])
        return redirect(f"/admin/channels?channel={fint(f, 'channel_id')}", request, "done.", "ok")
    chans = db.all("SELECT c.*, (SELECT COUNT(*) FROM channel_members m WHERE m.channel_id=c.id) AS members FROM channels c ORDER BY c.id DESC")
    cid = parse_int(request.query_params.get("channel"))
    ch = db.get("channels", cid) if cid else None
    return arender(request, "admin/channels.html", chans=chans, ch=ch,
                   members_=db.all("SELECT m.*, u.email, u.username FROM channel_members m JOIN users u ON u.id=m.user_id WHERE m.channel_id=? ORDER BY m.joined_at DESC", (ch["id"],)) if ch else [],
                   posts=community.channel_feed(db, ch["id"]) if ch else [], chat=community.channel_chat(db, ch["id"], limit=100) if ch else [])


# ------------------------------------------------------------------ reports / audit
@admin_required
async def reports_page(request: Request):
    core = request.app.state.core
    key = request.query_params.get("range", "28d")
    if key not in reports.RANGES:
        key = "28d"
    since, until, label = reports.range_bounds(core, key)
    custom_from, custom_to = request.query_params.get("from"), request.query_params.get("to")
    if custom_from and custom_to:
        s2, e2 = parse_dt_local(custom_from, core.tz), parse_dt_local(custom_to, core.tz)
        if s2 and e2 and e2 > s2:
            since, until, label = s2, e2, f"{custom_from} → {custom_to}"
    rep = reports.build(core, since, until)
    fmt = request.query_params.get("format")
    if fmt == "pdf":
        from ..pdfgen import build_report_pdf
        data = await asyncio.to_thread(build_report_pdf, core, reports.for_pdf(core, rep), f"report {label}")
        return Response(data, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="report-{key}.pdf"'})
    if fmt == "csv":
        buf = io.StringIO()
        csv.writer(buf).writerows(reports.csv_rows(rep))
        return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="report-{key}.csv"'})
    maxrev = max([d["revenue"] for d in rep["daily"]] or [1]) or 1
    maxkind = max([x["cents"] for x in rep["by_kind"]] or [1]) or 1
    return arender(request, "admin/reports.html", rep=rep, key=key, label=label, ranges=reports.RANGES, kind_labels=reports.KIND_LABELS, maxrev=maxrev, maxkind=maxkind,
                   text=reports.text_summary(core, rep, label))


@admin_required
async def audit(request: Request):
    core = request.app.state.core
    page, size, offset = page_args(request, 100)
    q = request.query_params.get("q", "").strip()
    action = request.query_params.get("action", "").strip()
    where, params = ["1=1"], []
    if q:
        where.append("(entity_id LIKE ? OR data_json LIKE ? OR CAST(actor_user_id AS TEXT)=?)"); params += [f"%{q}%", f"%{q}%", q]
    if action:
        where.append("action LIKE ?"); params.append(action + "%")
    rows = core.db.all(f"SELECT * FROM audit_log WHERE {' AND '.join(where)} ORDER BY id DESC LIMIT ? OFFSET ?", params + [size + 1, offset])
    if request.query_params.get("format") == "csv":
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["id", "ts", "actor_user_id", "actor_role", "action", "entity_type", "entity_id", "ip", "data_json"])
        for r in core.db.all(f"SELECT * FROM audit_log WHERE {' AND '.join(where)} ORDER BY id DESC LIMIT 50000", params):
            w.writerow([r[k] for k in ("id", "ts", "actor_user_id", "actor_role", "action", "entity_type", "entity_id", "ip", "data_json")])
        return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": 'attachment; filename="audit.csv"'})
    return arender(request, "admin/audit.html", rows=rows[:size], has_more=len(rows) > size, page=page, q=q, action=action)


# ------------------------------------------------------------------ settings / pricing
@admin_required
async def settings_page(request: Request):
    core = request.app.state.core
    s = core.settings
    if request.method == "POST":
        f = await form_data(request)
        key = fval(f, "key")
        if key not in EDITABLE:
            return redirect("/admin/settings", request, "unknown setting.", "error")
        if fval(f, "action") == "reset":
            s.reset(key, request.state.viewer.user_id)
            return redirect("/admin/settings", request, f"{key} reset to default.", "ok")
        kind = EDITABLE[key][0]
        raw = fval(f, "value")
        try:
            value = parse_money_cents(raw) if kind == "cents" else (fbool(f, "value") if kind == "bool" else raw)
            if kind == "cents" and value is None:
                raise ValueError("enter an amount in usd")
            s.set(key, value, request.state.viewer.user_id)
        except (ValueError, KeyError) as exc:
            return redirect("/admin/settings", request, f"{key}: {exc}", "error")
        return redirect("/admin/settings", request, f"{key} saved.", "ok")
    return arender(request, "admin/settings.html", groups=s.grouped())


@admin_required
async def pricing_page(request: Request):
    core = request.app.state.core
    p = RqPricing(core.settings)
    if request.method == "POST":
        f = await form_data(request)
        action = fval(f, "action")
        actor = request.state.viewer.user_id
        try:
            if action == "offer":
                key = fval(f, "key")
                if key in rq_catalog.OFFERS:
                    p.set_price(key, parse_money_cents(fval(f, "unit")), parse_money_cents(fval(f, "setup")), actor)
            elif action == "addon":
                lvl = fval(f, "level")
                if lvl in rq_catalog.ADDON_LEVELS:
                    p.set_addon(lvl, float(fval(f, "mult")), parse_money_cents(fval(f, "fee")), actor)
            elif action == "tiers":
                tiers = [(int(a), float(b)) for a, b in (pair.split(":") for pair in fval(f, "tiers").replace(" ", "").split(",") if ":" in pair)]
                p.set_volume_tiers(tiers, actor)
            elif action == "reset":
                for row in core.db.all("SELECT key FROM settings WHERE key LIKE 'rq.%'"):
                    core.db.delete_setting(row["key"])
                core.settings.invalidate()
            core.db.audit("rq.pricing", actor_user_id=actor, actor_role="admin", entity_type="rq_pricing", entity_id=action, data=dict(f) if action != "reset" else {})
        except (ValueError, TypeError) as exc:
            return redirect("/admin/pricing", request, f"invalid value: {exc}", "error")
        return redirect("/admin/pricing", request, "pricing saved.", "ok")
    offers = [(o, p.unit_price(o.key), p.setup_fee(o.key)) for o in rq_catalog.OFFERS.values() if o.kind == "standard"]
    addons = [(lvl, rq_catalog.ADDON_LEVELS[lvl]["name"], *p.addon(lvl)) for lvl in rq_catalog.ADDON_ORDER]
    return arender(request, "admin/pricing.html", offers=offers, addons=addons, tiers=p.volume_tiers(), activation=p.activation_price(), cats=rq_catalog.CATEGORY_BY_KEY)


# ------------------------------------------------------------------ backups / export / integrations
@admin_required
async def backups(request: Request):
    core = request.app.state.core
    cfg = core.cfg
    os.makedirs(cfg.backups_dir, exist_ok=True)
    if request.method == "POST":
        f = await form_data(request)
        action = fval(f, "action")
        if action == "now":
            await request.app.state.scheduler.backup()
            return redirect("/admin/backups", request, "backup written.", "ok")
        if action == "restore":
            ups = files_of(f, "file")
            if ups:
                tmp = os.path.join(cfg.backups_dir, f"restore-{now_ts()}.sqlite3")
                data = await ups[0].read()
                with open(tmp, "wb") as fh:
                    fh.write(data)
                if data[:16] != b"SQLite format 3\x00":
                    os.remove(tmp)
                    return redirect("/admin/backups", request, "not an sqlite file.", "error")
                return redirect("/admin/backups", request, f"uploaded to {tmp}. restore by replacing DB_PATH with this file and restarting (kept manual on purpose).", "warn")
    files = sorted((f for f in os.listdir(cfg.backups_dir) if f.endswith(".sqlite3")), reverse=True)
    sizes = {f: os.path.getsize(os.path.join(cfg.backups_dir, f)) for f in files}
    from ..db import EXPORT_TABLES
    return arender(request, "admin/backups.html", files=files, sizes=sizes, tables=EXPORT_TABLES, s3=os.environ.get("BACKUP_S3_BUCKET", ""))


@admin_required
async def backup_download(request: Request):
    core = request.app.state.core
    name = os.path.basename(request.path_params["name"])
    path = os.path.join(core.cfg.backups_dir, name)
    if not os.path.exists(path):
        return Response("not found", status_code=404)
    core.db.audit("backup.downloaded", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type="backup", entity_id=name)
    return FileResponse(path, filename=name, media_type="application/octet-stream")


@admin_required
async def export_table(request: Request):
    core = request.app.state.core
    table = request.path_params["table"]
    if table == "all.json":
        data = await asyncio.to_thread(core.db.export_json)
        core.db.audit("export.json", actor_user_id=request.state.viewer.user_id, actor_role="admin")
        return Response(data, media_type="application/json", headers={"Content-Disposition": 'attachment; filename="vxyltn-export.json"'})
    try:
        data = await asyncio.to_thread(core.db.export_csv, table)
    except ValueError:
        return Response("unknown table", status_code=404)
    core.db.audit("export.csv", actor_user_id=request.state.viewer.user_id, actor_role="admin", entity_type="table", entity_id=table)
    return Response(data, media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{table}.csv"'})


@admin_required
async def integrations(request: Request):
    core = request.app.state.core
    cfg = core.cfg
    np_status = None
    if request.method == "POST" and core.np.enabled:
        try:
            np_status = await core.np.status()
        except Exception as exc:
            np_status = {"error": str(exc)}
    rows = [
        ("nowpayments", "on" if cfg.np_api_key else "off", "NOWPAYMENTS_API_KEY, NOWPAYMENTS_IPN_SECRET; ipn url " + core.url("/api/nowpayments/ipn")),
        ("nowpayments listing/reconciliation", "on" if cfg.np_email else "off", "NOWPAYMENTS_EMAIL + NOWPAYMENTS_PASSWORD (jwt) enables payment listing by invoice"),
        ("email (smtp)", "on" if cfg.email_enabled else "off", "SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM (amazon ses works)"),
        ("telegram admin alerts", "on" if cfg.tg_bot_token and cfg.tg_admin_chat_id else "off", "TELEGRAM_BOT_TOKEN, TELEGRAM_ADMIN_CHAT_ID, TELEGRAM_DATA_CHAT_ID (mirror + backups)"),
        ("google oauth", "configured" if cfg.google_client_id else "off", "GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET (adapter: enable in routes/account when keys are set)"),
        ("sms (twilio)", "configured" if cfg.twilio_sid else "off", "TWILIO_SID / TWILIO_TOKEN / TWILIO_FROM (adapter)"),
        ("kyc / age verification", cfg.kyc_provider or "manual", "KYC_PROVIDER=jumio|onfido|manual, KYC_WEBHOOK_SECRET; manual review lives under kyc"),
        ("content moderation", cfg.moderation_provider or "off", "MODERATION_PROVIDER=hive|sightengine, MODERATION_API_KEY; flags land in moderation"),
        ("livestream video", cfg.livestream_provider, "LIVESTREAM_PROVIDER=embed|livekit|mux|cloudflare; paste the player embed url per stream"),
        ("calls", cfg.call_provider, "CALL_PROVIDER=link|jitsi|whereby; JITSI_BASE"),
        ("shopify sync", "configured" if cfg.shopify_store else "off", "SHOPIFY_STORE / SHOPIFY_TOKEN; products carry shopify_id"),
        ("ai notes", "on" if cfg.openai_api_key else "off", "OPENAI_API_KEY enables subscriber summaries on user pages"),
        ("s3 backups", "on" if os.environ.get("BACKUP_S3_BUCKET") else "off", "BACKUP_S3_BUCKET + instance role; aws cli copies nightly backups"),
        ("fx display", cfg.fx_provider, "FX_RATES=EUR=0.92,GBP=0.78,CHF=0.88,BTC=0.000015,ETH=0.00035"),
    ]
    return arender(request, "admin/integrations.html", rows=rows, np_status=np_status, base=cfg.base_url)


routes = [
    Route("/admin/live", live_admin, methods=["GET", "POST"]), Route("/admin/calls", calls_admin, methods=["GET", "POST"]),
    Route("/admin/customs", customs_admin), Route("/admin/customs/{public_id}", custom_detail, methods=["GET", "POST"]),
    Route("/admin/shop-orders", shop_orders, methods=["GET", "POST"]), Route("/admin/coa/{serial}.pdf", coa_pdf),
    Route("/admin/priority", priority_admin, methods=["GET", "POST"]), Route("/admin/kyc", kyc_admin), Route("/admin/contact", contact_admin, methods=["GET", "POST"]),
    Route("/admin/dmca", dmca_admin, methods=["GET", "POST"]), Route("/admin/channels", channels_admin, methods=["GET", "POST"]),
    Route("/admin/reports", reports_page), Route("/admin/audit", audit), Route("/admin/settings", settings_page, methods=["GET", "POST"]),
    Route("/admin/pricing", pricing_page, methods=["GET", "POST"]), Route("/admin/backups", backups, methods=["GET", "POST"]),
    Route("/admin/backups/{name}", backup_download), Route("/admin/export/{table}", export_table), Route("/admin/integrations", integrations, methods=["GET", "POST"]),
]
