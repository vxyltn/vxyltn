"""Request-system domain logic: terms, sessions, orders, fulfillment, details, expiry, admin PDFs."""
from __future__ import annotations

import logging
import sqlite3
from datetime import datetime, timezone

from ..money import usd
from ..payments import CapExceeded
from ..util import loads, now_ts
from . import catalog
from .pricing import Quote, RqPricing

log = logging.getLogger(__name__)

TERMS_SHORT = ("Request only. Nothing is guaranteed, approved, delivered, or replied to. "
               "No refunds or returns, ever. 1 month = 28 days.")
TERMS_ACCEPT_LINE = ("I understand this is a request only. Nothing is guaranteed, approved, delivered, or replied to. "
                     "No refunds or returns ever. 1 month = 28 days. All activity stays inside VXYLTN's boundaries and limits.")
PAYMENT_RECEIVED = "Payment received. Request logged. Nothing is guaranteed or promised. No refund."


def terms_full(core) -> list[str]:
    s = core.settings
    p = RqPricing(s)
    act = p.activation_price()
    cap = p.max_per_invoice()
    items = [
        "Everything in the request system is a request. Paying submits a request. It does not buy a result.",
        "Nothing is guaranteed, approved, delivered, or replied to. No timeline is promised.",
        "Prices are in USDC (ERC-20). All payments are prepayments through NOWPayments, in USDC or any coin NOWPayments supports at checkout. "
        "All payments are final. No refunds or returns, ever. Crypto payments are irreversible. Network fees and exchange-rate movement are yours.",
        f"Activation costs {usd(act)}. It is the minimum price in the request system. It unlocks the request menu for "
        f"{s.int('rq_session_hours')} hours or until you start a new session. It buys nothing else. Every new session requires a new activation payment.",
        "Activation is the only thing a payment ever grants. Subscriptions, messages, calls, livestreams, custom items, and add-ons are requests only. "
        "Paying for a subscription request does not add you to any channel, group, or membership.",
        "If access to a channel, group, or membership is offered after a subscription request, it is a second, separate step inside the platform "
        "with its own payment. Paid content inside a channel, group, or membership is also paid separately. The request system does not deliver or refund any of it.",
        "1 month = 28 days.",
        f"Every other request except a contribution is priced above {usd(s.int('rq_min_total_cents'))} before add-ons.",
    ]
    if cap:
        items.append(f"If a total is above {usd(cap)}, it is split into sequential payments of at most {usd(cap)}. A request is recorded only after all parts are paid. Paid parts are not refunded if you stop.")
    items += [
        f"Paid units expire {s.int('rq_unit_expiry_days')} days after payment if unused.",
        "A paid request cannot be edited or canceled.",
        "Contributions are contributions. No goods or services are attached. No limit: any amount.",
        "An outgoing message request pays for the right to submit that message to VXYLTN. Nothing more.",
        "English (US) only.",
        "Everything stays inside VXYLTN's boundaries and limits. Requests outside them are declined without reply and without refund.",
        "Content published in VXYLTN's channel, group, or membership is separate from the request system. Anything not published there can be requested here.",
    ]
    return items


class RequestService:
    def __init__(self, core):
        self.core = core
        self.db = core.db
        self.pricing = RqPricing(core.settings)

    # ------------------------------------------------------------ terms
    def terms_accepted(self, user_id: int) -> bool:
        return self.db.one("SELECT 1 FROM rq_terms WHERE user_id=? AND version=?", (user_id, self.core.cfg.rq_terms_version)) is not None

    def accept_terms(self, user_id: int, ip: str | None) -> None:
        self.db.execute("INSERT OR IGNORE INTO rq_terms(user_id, version, accepted_at, ip) VALUES (?,?,?,?)",
                        (user_id, self.core.cfg.rq_terms_version, now_ts(), ip))
        self.db.audit("rq.terms_accepted", actor_user_id=user_id, actor_role="user", entity_type="rq_terms", entity_id=user_id, ip=ip,
                      data={"version": self.core.cfg.rq_terms_version})

    # ------------------------------------------------------------ sessions
    def current_session(self, user_id: int) -> sqlite3.Row | None:
        return self.db.one("SELECT * FROM rq_sessions WHERE user_id=? ORDER BY id DESC LIMIT 1", (user_id,))

    def session_active(self, sess: sqlite3.Row | None) -> bool:
        return sess is not None and sess["status"] == "active" and sess["expires_at"] and sess["expires_at"] > now_ts()

    def active_session(self, user_id: int) -> sqlite3.Row | None:
        s = self.current_session(user_id)
        return s if self.session_active(s) else None

    def new_session(self, user_id: int, reason: str = "start") -> sqlite3.Row:
        ts = now_ts()
        self.db.execute("UPDATE rq_sessions SET status='ended', ended_at=?, ended_reason=? WHERE user_id=? AND status IN ('pending_activation','active')",
                        (ts, reason, user_id))
        self.discard_unpaid(user_id, reason)
        sid = self.db.insert("rq_sessions", user_id=user_id, status="pending_activation", started_at=ts)
        self.db.audit("rq.session_new", actor_user_id=user_id, actor_role="user", entity_type="rq_session", entity_id=sid)
        return self.db.get("rq_sessions", sid)

    def discard_unpaid(self, user_id: int, reason: str) -> int:
        rows = self.db.all("SELECT * FROM rq_orders WHERE user_id=? AND status IN ('awaiting_payment','partial')", (user_id,))
        ts = now_ts()
        for o in rows:
            purchase = self.db.get("purchases", o["purchase_id"]) if o["purchase_id"] else None
            if purchase and purchase["parts_paid"] == 0:
                self.core.payments.cancel_pending(purchase, reason)
                self.db.update("rq_orders", o["id"], status="discarded", updated_at=ts)
            else:
                self.db.update("rq_orders", o["id"], status="partial_abandoned", updated_at=ts)
            self.db.audit("rq.order_discarded", actor_user_id=user_id, entity_type="rq_order", entity_id=o["public_id"], data={"reason": reason})
        return len(rows)

    # ------------------------------------------------------------ orders
    def _public_id(self) -> str:
        return self.db.public_id("VX", datetime.now(timezone.utc).year)

    def create_order(self, user_id: int, session_id: int | None, quote: Quote, ip: str | None = None) -> tuple[sqlite3.Row, sqlite3.Row]:
        """Create the rq_order and its purchase. Returns (order, purchase)."""
        offer = catalog.get_offer(quote.offer_key)
        pid = self._public_id()
        ts = now_ts()
        oid = self.db.insert("rq_orders", public_id=pid, user_id=user_id, session_id=session_id, offer_key=offer.key, offer_name=offer.name,
                             category=offer.category, kind=quote.kind, units=quote.units, unit_label=quote.unit_label, priority=quote.priority,
                             quote_json=quote.to_json(), total_cents=quote.total, status="awaiting_payment", created_at=ts, updated_at=ts,
                             attached_to=quote.attached_order_id, invoice_no=f"INV-{pid}")
        kind = "rq_activation" if quote.kind == "activation" else "rq_order"
        try:
            purchase = self.core.payments.create_purchase(
                user_id=user_id, kind=kind, title=f"{offer.name} {pid}", total_cents=quote.total, entity_type="rq_order", entity_id=oid,
                description=f"{quote.units:,} {quote.unit_label}. {TERMS_SHORT}", meta={"public_id": pid, "offer_key": offer.key},
                parts_max_cents=self.pricing.max_per_invoice(), exempt_cap=True, ip=ip,
                ttl_seconds=self.core.settings.int("rq_invoice_ttl_hours") * 3600)
        except CapExceeded:  # exempt_cap=True, cannot happen; kept for safety
            raise
        self.db.update("rq_orders", oid, purchase_id=purchase["id"], updated_at=now_ts())
        self.db.audit("rq.order_created", actor_user_id=user_id, actor_role="user", entity_type="rq_order", entity_id=pid, ip=ip,
                      data={"offer": offer.key, "units": quote.units, "priority": quote.priority, "total_cents": quote.total})
        return self.db.get("rq_orders", oid), purchase

    def start_activation(self, user_id: int, session: sqlite3.Row, ip: str | None = None) -> tuple[sqlite3.Row, sqlite3.Row]:
        order, purchase = self.create_order(user_id, session["id"], self.pricing.quote_activation(), ip)
        self.db.update("rq_sessions", session["id"], activation_order_id=order["id"])
        return order, purchase

    def order_by_public(self, public_id: str) -> sqlite3.Row | None:
        return self.db.one("SELECT * FROM rq_orders WHERE upper(public_id)=upper(?)", (public_id.strip(),))

    def user_orders(self, user_id: int, limit: int = 50) -> list[sqlite3.Row]:
        return self.db.all("SELECT * FROM rq_orders WHERE user_id=? ORDER BY id DESC LIMIT ?", (user_id, limit))

    def pending_orders(self, user_id: int) -> list[sqlite3.Row]:
        return self.db.all("SELECT * FROM rq_orders WHERE user_id=? AND status IN ('awaiting_payment','partial') ORDER BY id DESC", (user_id,))

    # ------------------------------------------------------------ fulfillment (called by payments.fulfill)
    async def on_purchase_paid(self, purchase: sqlite3.Row) -> None:
        order = self.db.get("rq_orders", purchase["entity_id"])
        if order is None:
            return
        ts = now_ts()
        if order["kind"] == "activation":
            sess = self.db.get("rq_sessions", order["session_id"]) if order["session_id"] else None
            hours = self.core.settings.int("rq_session_hours")
            if sess is None or sess["status"] not in ("pending_activation", "active"):
                sid = self.db.insert("rq_sessions", user_id=order["user_id"], status="active", started_at=ts)
                sess = self.db.get("rq_sessions", sid)
            self.db.update("rq_sessions", sess["id"], status="active", activated_at=ts, expires_at=ts + hours * 3600, activation_order_id=order["id"])
            self.db.update("rq_orders", order["id"], status="paid", paid_at=ts, updated_at=ts)
            self.db.audit("rq.session_activated", actor_user_id=order["user_id"], entity_type="rq_session", entity_id=sess["id"],
                          data={"expires_at": ts + hours * 3600})
            self.db.notify(order["user_id"], "rq", "Request system activated", f"Active until {self.core.local(ts + hours * 3600)}.", "/request/menu")
        else:
            expiry = ts + self.core.settings.int("rq_unit_expiry_days") * 86400
            offer = catalog.get_offer(order["offer_key"])
            details_status = "pending" if (offer and offer.needs_details) else "none"
            self.db.update("rq_orders", order["id"], status="paid", paid_at=ts, expires_at=expiry, updated_at=ts, details_status=details_status)
            if order["kind"] == "addon" and order["attached_to"]:
                base = self.order_by_public(order["attached_to"])
                level = catalog.addon_level_from_offer_key(order["offer_key"])
                if base and level:
                    self.db.update("rq_orders", base["id"], priority=level, updated_at=ts)
                    self.db.audit("rq.addon_applied", actor_user_id=order["user_id"], entity_type="rq_order", entity_id=base["public_id"],
                                  data={"addon_order": order["public_id"], "level": level})
            self.db.notify(order["user_id"], "rq", f"Request {order['public_id']} logged", PAYMENT_RECEIVED, f"/request/orders/{order['public_id']}")
        await self.admin_report(self.db.get("rq_orders", order["id"]))

    async def admin_report(self, order: sqlite3.Row) -> None:
        from ..pdfgen import build_request_pdf
        import asyncio
        user = self.db.get("users", order["user_id"])
        quote = Quote.from_json(order["quote_json"])
        head = "ACTIVATION PAID" if order["kind"] == "activation" else "REQUEST PAID"
        who = f"{user['id']} {user['email'] or ''} {user['username'] or ''}".strip() if user else str(order["user_id"])
        text = (f"<b>{head}</b> {order['public_id']}\n{order['offer_name']}\nUser: {who}\n"
                f"Units: {order['units']:,} {order['unit_label']} | Add-on: {order['priority']}\nTotal: {usd(order['total_cents'])}\n"
                f"Details: {order['details_status']}\n<pre>{quote.breakdown_text()}</pre>")
        pdf = None
        try:
            pdf = await asyncio.to_thread(build_request_pdf, self.core, order)
        except Exception:  # pragma: no cover
            log.exception("request PDF failed for %s", order["public_id"])
        await self.core.notifier.admin(text, document=(pdf, f"{order['invoice_no']}.pdf") if pdf else None)
        if pdf:
            try:
                mid = self.core.media.ingest_bytes(pdf, f"{order['invoice_no']}.pdf", "application/pdf", None, folder="invoices",
                                                   title=order["invoice_no"], source="generated")
                self.db.update("rq_orders", order["id"], admin_note=order["admin_note"])
                self.db.audit("rq.pdf_stored", entity_type="rq_order", entity_id=order["public_id"], data={"media_id": mid})
            except Exception:  # pragma: no cover
                log.exception("storing PDF failed")
        await self.core.notifier.mirror("rq_order", order["public_id"], f"{head} {order['public_id']} {usd(order['total_cents'])}", dict(order))

    # ------------------------------------------------------------ details
    def add_detail(self, order: sqlite3.Row, user_id: int, kind: str, text: str | None, media_id: int | None) -> int:
        ts = now_ts()
        did = self.db.insert("rq_details", order_id=order["id"], user_id=user_id, kind=kind, text=text, media_id=media_id, created_at=ts)
        self.db.update("rq_orders", order["id"], details_count=int(order["details_count"]) + 1, details_status="received", updated_at=ts)
        self.db.audit("rq.detail_added", actor_user_id=user_id, actor_role="user", entity_type="rq_order", entity_id=order["public_id"],
                      data={"kind": kind, "media_id": media_id})
        return did

    def details(self, order_id: int) -> list[sqlite3.Row]:
        return self.db.all("SELECT d.*, m.filename, m.kind AS media_kind FROM rq_details d LEFT JOIN media m ON m.id=d.media_id WHERE d.order_id=? ORDER BY d.id", (order_id,))

    async def finish_details(self, order: sqlite3.Row, skipped: bool) -> None:
        count = int(order["details_count"])
        status = "received" if count else ("skipped" if skipped else "pending")
        self.db.update("rq_orders", order["id"], details_status=status, updated_at=now_ts())
        if count:
            await self.core.notifier.admin(f"<b>DETAILS</b> {order['public_id']} ({order['offer_name']}): {count} item(s). "
                                           f"{self.core.url('/admin/requests/' + order['public_id'])}")

    # ------------------------------------------------------------ housekeeping
    def expire_sessions(self) -> int:
        ts = now_ts()
        rows = self.db.all("SELECT id, user_id FROM rq_sessions WHERE status='active' AND expires_at<=?", (ts,))
        for r in rows:
            self.db.update("rq_sessions", r["id"], status="expired", ended_at=ts, ended_reason="timeout")
            self.db.audit("rq.session_expired", actor_user_id=r["user_id"], entity_type="rq_session", entity_id=r["id"])
        return len(rows)

    def expire_orders(self) -> int:
        ts = now_ts()
        rows = self.db.all("SELECT * FROM rq_orders WHERE status='paid' AND kind<>'activation' AND expires_at IS NOT NULL AND expires_at<=?", (ts,))
        for o in rows:
            self.db.update("rq_orders", o["id"], status="expired", updated_at=ts)
            self.db.audit("rq.order_expired", actor_user_id=o["user_id"], entity_type="rq_order", entity_id=o["public_id"])
            self.db.notify(o["user_id"], "rq", f"Request {o['public_id']} expired", "Paid units were unused within the expiry period. No refund.")
        return len(rows)

    def discard_stale(self) -> int:
        ttl = self.core.settings.int("rq_invoice_ttl_hours") * 3600
        rows = self.db.all("SELECT * FROM rq_orders WHERE status='awaiting_payment' AND created_at<?", (now_ts() - ttl,))
        n = 0
        for o in rows:
            purchase = self.db.get("purchases", o["purchase_id"]) if o["purchase_id"] else None
            if purchase and purchase["parts_paid"] == 0:
                self.core.payments.cancel_pending(purchase, "ttl")
                self.db.update("rq_orders", o["id"], status="discarded", updated_at=now_ts())
                n += 1
        return n

    # ------------------------------------------------------------ presentation helpers
    def offers_grouped(self) -> list[dict]:
        out = []
        for cat in catalog.CATEGORIES:
            out.append({"cat": cat, "offers": [(o, self.pricing.unit_price_label(o)) for o in catalog.offers_in_category(cat.key)]})
        return out

    @staticmethod
    def quote_of(order: sqlite3.Row) -> Quote:
        return Quote.from_json(order["quote_json"])

    @staticmethod
    def meta(order: sqlite3.Row) -> dict:
        return loads(order["quote_json"], {})
