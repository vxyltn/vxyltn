"""Request-system catalog (USDC, 1 USDC = 1 USD). Every offer is a request. Nothing is granted or guaranteed.

Activation = USD 1,000,000: the minimum price in the request system. Every other request
is priced above it. Contributions are exempt from the floor. Admin can change any
unit price, setup fee, multiplier or fee at runtime (Admin -> Request pricing).
"""
from __future__ import annotations

from dataclasses import dataclass

ACTIVATION_KEY = "activation"
CONTRIBUTION_KEY = "contribution"
M = 100  # cents per dollar


@dataclass(frozen=True)
class Category:
    key: str
    name: str
    blurb: str


@dataclass(frozen=True)
class Offer:
    key: str
    name: str
    category: str
    unit: str
    unit_plural: str
    unit_price_cents: int
    setup_fee_cents: int
    max_units: int
    kind: str = "standard"      # standard | contribution | addon | activation
    needs_details: bool = True
    details_prompt: str = ""
    description: str = ""
    unit_prompt: str = ""


CATEGORIES: tuple[Category, ...] = (
    Category("subs", "Subscriptions", "Requests for channel, group, or membership subscription periods. 1 month = 28 days. "
             "Request only. Access, if offered, is a separate step inside the platform with its own payment."),
    Category("out", "Outgoing messages", "Requests to send a message from you to VXYLTN."),
    Category("custom", "Custom", "Requests for custom content."),
    Category("calls", "Calls & livestream", "Requests for calls and livestream time."),
    Category("contrib", "Contribution", "A contribution. No goods or services are attached."),
    Category("addons", "Add-ons", "Priority add-ons for a request you already paid."),
)
CATEGORY_BY_KEY = {c.key: c for c in CATEGORIES}

_D_SUB = ("Details for this subscription request: which channel, group, or membership, your account, and any notes. "
          "Request only. Access, if offered, is a separate step with its own payment.")
_D_OUT = "The content of the message you are requesting to send to VXYLTN, plus any notes. Text and files."
_D_CUSTOM = "Describe the custom request: what you are requesting, format, length, and any notes. Text and files."
_D_CALL = "Preferred date and time with your time zone, your account, and any notes."
_D_LIVE = "Preferred date and time with your time zone and any notes about the livestream request."

# key, name, category, unit, unit_plural, unit_price USD, setup fee USD, max units, details prompt, description, unit prompt
_RAW = (
    ("channel_sub", "Channel subscription request", "subs", "month (28 days)", "months (28 days each)", 6_000_000, 1_000_000, 120, _D_SUB,
     "Request for channel subscription time. Per month. 1 month = 28 days.", "Number of months (1-120). 1 month = 28 days."),
    ("group_sub", "Group subscription request", "subs", "month (28 days)", "months (28 days each)", 5_000_000, 1_000_000, 120, _D_SUB,
     "Request for group subscription time. Per month. 1 month = 28 days.", "Number of months (1-120). 1 month = 28 days."),
    ("membership_sub", "Membership subscription request", "subs", "month (28 days)", "months (28 days each)", 10_000_000, 2_000_000, 120, _D_SUB,
     "Request for membership subscription time. Per month. 1 month = 28 days.", "Number of months (1-120). 1 month = 28 days."),
    ("out_text", "Outgoing text message", "out", "text", "texts", 1_200_000, 250_000, 500, _D_OUT,
     "Request to send one text message from you to VXYLTN. Per text.", "Number of texts (1-500)."),
    ("out_audio", "Outgoing audio message", "out", "minute", "minutes", 1_600_000, 350_000, 600, _D_OUT,
     "Request to send an audio message from you to VXYLTN. Per minute.", "Number of minutes (1-600)."),
    ("out_gif", "Outgoing GIF message", "out", "GIF", "GIFs", 1_400_000, 300_000, 500, _D_OUT,
     "Request to send a GIF from you to VXYLTN. Per GIF.", "Number of GIFs (1-500)."),
    ("out_photo", "Outgoing photo message", "out", "photo", "photos", 1_600_000, 350_000, 500, _D_OUT,
     "Request to send a photo message from you to VXYLTN. Per photo.", "Number of photos (1-500)."),
    ("out_video", "Outgoing video message", "out", "video", "videos", 2_800_000, 600_000, 200, _D_OUT,
     "Request to send a video from you to VXYLTN. Per video.", "Number of videos (1-200)."),
    ("out_pdf", "Outgoing PDF message", "out", "PDF", "PDFs", 2_000_000, 400_000, 200, _D_OUT,
     "Request to send a PDF from you to VXYLTN. Per PDF.", "Number of PDFs (1-200)."),
    ("out_other", "Outgoing other-format message", "out", "item", "items", 2_800_000, 600_000, 200, _D_OUT,
     "Request to send a message in another format from you to VXYLTN. Per item.", "Number of items (1-200)."),
    ("out_audio_call", "Outgoing audio call", "calls", "minute", "minutes", 4_000_000, 1_000_000, 600, _D_CALL,
     "Request for an audio call from you to VXYLTN. Per minute.", "Number of minutes (1-600)."),
    ("out_video_call", "Outgoing video call", "calls", "minute", "minutes", 6_000_000, 1_500_000, 600, _D_CALL,
     "Request for a video call from you to VXYLTN. Per minute.", "Number of minutes (1-600)."),
    ("custom_audio_call", "Custom audio call", "calls", "minute", "minutes", 7_500_000, 2_000_000, 600, _D_CALL,
     "Request for a custom audio call. Per minute.", "Number of minutes (1-600)."),
    ("custom_video_call", "Custom video call", "calls", "minute", "minutes", 10_000_000, 2_500_000, 600, _D_CALL,
     "Request for a custom video call. Per minute.", "Number of minutes (1-600)."),
    ("livestream", "Livestream", "calls", "minute", "minutes", 5_000_000, 2_000_000, 1_440, _D_LIVE,
     "Request for livestream time. Per minute.", "Number of minutes (1-1440)."),
    ("custom_livestream", "Custom livestream", "calls", "minute", "minutes", 12_500_000, 4_000_000, 1_440, _D_LIVE,
     "Request for custom livestream time. Per minute.", "Number of minutes (1-1440)."),
    ("custom_text", "Custom text", "custom", "text", "texts", 3_000_000, 600_000, 200, _D_CUSTOM,
     "Request for a custom text. Per text.", "Number of texts (1-200)."),
    ("custom_audio", "Custom audio", "custom", "audio", "audios", 5_000_000, 1_000_000, 200, _D_CUSTOM,
     "Request for a custom audio. Per audio.", "Number of audios (1-200)."),
    ("custom_gif", "Custom GIF", "custom", "GIF", "GIFs", 4_000_000, 800_000, 200, _D_CUSTOM,
     "Request for a custom GIF. Per GIF.", "Number of GIFs (1-200)."),
    ("custom_photo", "Custom photo", "custom", "photo", "photos", 5_000_000, 1_000_000, 200, _D_CUSTOM,
     "Request for a custom photo. Per photo.", "Number of photos (1-200)."),
    ("custom_video", "Custom video", "custom", "video", "videos", 10_000_000, 2_000_000, 100, _D_CUSTOM,
     "Request for a custom video. Per video.", "Number of videos (1-100)."),
    ("custom_pdf", "Custom PDF", "custom", "PDF", "PDFs", 6_000_000, 1_200_000, 100, _D_CUSTOM,
     "Request for a custom PDF. Per PDF.", "Number of PDFs (1-100)."),
    ("custom_other", "Custom other", "custom", "item", "items", 7_500_000, 1_500_000, 100, _D_CUSTOM,
     "Request for a custom item in another format. Per item.", "Number of items (1-100)."),
)

OFFERS: dict[str, Offer] = {}
for _r in _RAW:
    OFFERS[_r[0]] = Offer(key=_r[0], name=_r[1], category=_r[2], unit=_r[3], unit_plural=_r[4], unit_price_cents=_r[5] * M,
                          setup_fee_cents=_r[6] * M, max_units=_r[7], kind="standard", needs_details=True,
                          details_prompt=_r[8], description=_r[9], unit_prompt=_r[10])

OFFERS[CONTRIBUTION_KEY] = Offer(key=CONTRIBUTION_KEY, name="Contribution", category="contrib", unit="usdc", unit_plural="usdc",
                                 unit_price_cents=100, setup_fee_cents=0, max_units=10 ** 15, kind="contribution", needs_details=False,
                                 description="A contribution of any amount. No limit. No goods or services are attached.",
                                 unit_prompt="Contribution amount in usdc.")
OFFERS[ACTIVATION_KEY] = Offer(key=ACTIVATION_KEY, name="Request-system activation", category="system", unit="activation",
                               unit_plural="activations", unit_price_cents=1_000_000 * M, setup_fee_cents=0, max_units=1,
                               kind="activation", needs_details=False,
                               description="Unlocks the request menu for one session. Buys nothing else. The minimum price in the request system.")

ADDON_LEVELS: dict[str, dict] = {
    "none": {"name": "No add-on", "mult": 1.0, "fee_cents": 0, "rank": 0},
    "priority": {"name": "Priority add-on", "mult": 1.5, "fee_cents": 1_000_000 * M, "rank": 1},
    "high": {"name": "High-priority add-on", "mult": 2.0, "fee_cents": 2_500_000 * M, "rank": 2},
    "urgent": {"name": "Urgent add-on", "mult": 3.0, "fee_cents": 5_000_000 * M, "rank": 3},
}
ADDON_ORDER = ("priority", "high", "urgent")
for _lvl in ADDON_ORDER:
    _m = ADDON_LEVELS[_lvl]
    OFFERS[f"addon_{_lvl}"] = Offer(key=f"addon_{_lvl}", name=_m["name"], category="addons", unit="request", unit_plural="requests",
                                    unit_price_cents=_m["fee_cents"], setup_fee_cents=0, max_units=1, kind="addon", needs_details=False,
                                    description=f"{_m['name']} for a request you already paid. x{_m['mult']:g} on the request subtotal plus a fixed fee.",
                                    unit_prompt="Request ID to attach this add-on to (for example VX-2026-000012).")

DEFAULT_VOLUME_TIERS: tuple[tuple[int, float], ...] = ((1, 1.0), (5, 1.10), (10, 1.25), (25, 1.50), (100, 2.0))


def offers_in_category(cat_key: str) -> list[Offer]:
    return [o for o in OFFERS.values() if o.category == cat_key]


def get_offer(key: str) -> Offer | None:
    return OFFERS.get(key)


def addon_level_from_offer_key(key: str) -> str | None:
    if key.startswith("addon_") and key[6:] in ADDON_LEVELS:
        return key[6:]
    return None
