"""Request-system web flow: terms -> activation ($1,000,000) -> menu -> units -> add-on -> confirm -> pay -> details."""
from __future__ import annotations

import base64
import json

from starlette.requests import Request
from starlette.routing import Route

from .. import auth
from ..lang import is_english
from ..util import now_ts, parse_int, parse_money_cents
from ..web import files_of, form_data, fval, login_required, redirect, render
from . import catalog
from .pricing import Quote
from .service import PAYMENT_RECEIVED, TERMS_ACCEPT_LINE, TERMS_SHORT, RequestService, terms_full

QUOTE_MAX_AGE = 15 * 60


def _svc(request: Request) -> RequestService:
    return RequestService(request.app.state.core)


def _sign_quote(request: Request, quote: Quote, attached_to: str | None) -> str:
    payload = base64.urlsafe_b64encode(json.dumps({"q": quote.to_json(), "a": attached_to, "t": now_ts()}).encode()).decode()
    return auth.sign(request.app.state.core.cfg.secret_key, payload)


def _load_quote(request: Request, signed: str) -> tuple[Quote | None, str | None, bool]:
    payload = auth.unsign(request.app.state.core.cfg.secret_key, signed)
    if not payload:
        return None, None, False
    try:
        data = json.loads(base64.urlsafe_b64decode(payload.encode()).decode())
        return Quote.from_json(data["q"]), data.get("a"), (now_ts() - int(data["t"])) <= QUOTE_MAX_AGE
    except Exception:
        return None, None, False


def _ctx(request: Request, svc: RequestService) -> dict:
    viewer = request.state.viewer
    uid = viewer.user_id
    sess = svc.current_session(uid) if uid else None
    return {"accepted": svc.terms_accepted(uid) if uid else False, "sess": sess, "active": svc.session_active(sess),
            "activation": svc.pricing.activation_price(), "terms_short": TERMS_SHORT, "accept_line": TERMS_ACCEPT_LINE}


# ------------------------------------------------------------------ pages
async def landing(request: Request):
    svc = _svc(request)
    ctx = _ctx(request, svc)
    pending = svc.pending_orders(request.state.viewer.user_id) if request.state.viewer.user_id else []
    return render(request, "request/landing.html", pending=pending, groups=svc.offers_grouped(), **ctx)


async def offers(request: Request):
    svc = _svc(request)
    return render(request, "request/offers.html", groups=svc.offers_grouped(), activation=svc.pricing.activation_price(),
                  addons=[(lvl, catalog.ADDON_LEVELS[lvl]["name"], svc.pricing.addon(lvl)) for lvl in catalog.ADDON_ORDER],
                  tiers=svc.pricing.volume_tiers(), s=request.app.state.core.settings)


async def terms(request: Request):
    svc = _svc(request)
    core = request.app.state.core
    if request.method == "POST":
        if request.state.viewer.user is None:
            return redirect("/login?next=/request/terms", request, "log in first.")
        f = await form_data(request)
        if fval(f, "accept") != "1":
            return redirect("/request/terms", request, "tick the box to accept.", "error")
        svc.accept_terms(request.state.viewer.user_id, request.state.ip)
        return redirect("/request/start", request, "terms accepted.", "ok")
    return render(request, "request/terms.html", items=terms_full(core), **_ctx(request, svc))


@login_required
async def start(request: Request):
    """GET: confirm page (if a session is active). POST: new session + activation purchase -> pay."""
    svc = _svc(request)
    core = request.app.state.core
    uid = request.state.viewer.user_id
    ctx = _ctx(request, svc)
    if not ctx["accepted"]:
        return redirect("/request/terms", request, "accept the request-system terms first.")
    if core.settings.bool("require_email_verification") and core.emailer.enabled and not request.state.viewer.email_verified:
        return redirect("/verify", request, "confirm your email before paying.")
    if request.method == "GET":
        if ctx["active"] and core.settings.bool("rq_start_confirm_restart"):
            return render(request, "request/restart.html", **ctx)
        if ctx["sess"] is not None and ctx["sess"]["status"] == "pending_activation":
            order = core.db.get("rq_orders", ctx["sess"]["activation_order_id"]) if ctx["sess"]["activation_order_id"] else None
            purchase = core.db.get("purchases", order["purchase_id"]) if order and order["purchase_id"] else None
            if purchase and purchase["status"] in ("pending", "partial"):
                return render(request, "request/activate.html", purchase=purchase, order=order, **ctx)
        return render(request, "request/activate.html", purchase=None, order=None, **ctx)
    sess = svc.new_session(uid, "start")
    order, purchase = svc.start_activation(uid, sess, request.state.ip)
    return redirect(f"/pay/{purchase['public_id']}")


def _require_active(request: Request, svc: RequestService):
    uid = request.state.viewer.user_id
    sess = svc.active_session(uid)
    if sess is None:
        prev = svc.current_session(uid)
        msg = "your activation expired. activate again." if prev and prev["status"] == "expired" else "not activated. activate first."
        return None, redirect("/request", request, msg)
    return sess, None


@login_required
async def menu(request: Request):
    svc = _svc(request)
    sess, resp = _require_active(request, svc)
    if resp:
        return resp
    return render(request, "request/menu.html", groups=svc.offers_grouped(), categories=catalog.CATEGORIES, **_ctx(request, svc))


@login_required
async def offer(request: Request):
    svc = _svc(request)
    core = request.app.state.core
    sess, resp = _require_active(request, svc)
    if resp:
        return resp
    o = catalog.get_offer(request.path_params["key"])
    if o is None or o.kind == "activation":
        return redirect("/request/menu", request, "unknown offer.")
    ctx = _ctx(request, svc)
    if request.method == "GET":
        return render(request, "request/offer.html", o=o, price_label=svc.pricing.unit_price_label(o),
                      addons=[(lvl, catalog.ADDON_LEVELS[lvl]["name"], svc.pricing.addon(lvl)) for lvl in catalog.ADDON_ORDER], **ctx)
    f = await form_data(request)
    uid = request.state.viewer.user_id
    try:
        if o.kind == "contribution":
            cents = parse_money_cents(fval(f, "amount"))
            if cents is None:
                raise ValueError("enter the contribution amount in usd.")
            quote = svc.pricing.quote_contribution(cents)
            attached = None
        elif o.kind == "addon":
            base = svc.order_by_public(fval(f, "order_id") or "")
            if base is None or base["user_id"] != uid or base["status"] != "paid":
                raise ValueError("request not found. add-ons attach only to your own paid requests.")
            if base["kind"] != "standard":
                raise ValueError("add-ons attach to standard requests only.")
            level = catalog.addon_level_from_offer_key(o.key)
            quote = svc.pricing.quote_addon_upgrade(Quote.from_json(base["quote_json"]), level, base["public_id"])
            attached = base["public_id"]
        else:
            units = parse_int(fval(f, "units"))
            if units is None:
                raise ValueError("enter a whole number.")
            level = fval(f, "priority") or "none"
            if level not in catalog.ADDON_LEVELS:
                level = "none"
            quote = svc.pricing.quote_standard(o, units, level, core.now_local())
            attached = None
    except ValueError as exc:
        return render(request, "request/offer.html", o=o, price_label=svc.pricing.unit_price_label(o), error=str(exc), form=f,
                      addons=[(lvl, catalog.ADDON_LEVELS[lvl]["name"], svc.pricing.addon(lvl)) for lvl in catalog.ADDON_ORDER], **ctx)
    return render(request, "request/confirm.html", o=o, quote=quote, signed=_sign_quote(request, quote, attached), attached=attached,
                  expiry_days=core.settings.int("rq_unit_expiry_days"), is_sub=o.key in ("channel_sub", "group_sub", "membership_sub"), **ctx)


@login_required
async def confirm(request: Request):
    svc = _svc(request)
    sess, resp = _require_active(request, svc)
    if resp:
        return resp
    f = await form_data(request)
    quote, attached, fresh = _load_quote(request, fval(f, "signed"))
    if quote is None:
        return redirect("/request/menu", request, "this confirmation is no longer valid. start again.", "error")
    if not fresh:
        return redirect(f"/request/offer/{quote.offer_key}", request, "the quote expired. enter the units again.", "warn")
    uid = request.state.viewer.user_id
    if attached:
        base = svc.order_by_public(attached)
        if base is None or base["user_id"] != uid or base["status"] != "paid":
            return redirect("/request/menu", request, "request not found.", "error")
    discarded = svc.discard_unpaid(uid, "new_order")
    order, purchase = svc.create_order(uid, sess["id"], quote, request.state.ip)
    msg = "previous unpaid request discarded. " if discarded else ""
    return redirect(f"/pay/{purchase['public_id']}", request, msg + f"request {order['public_id']} created. pay to submit it.") if msg else redirect(f"/pay/{purchase['public_id']}")


@login_required
async def order_page(request: Request):
    svc = _svc(request)
    core = request.app.state.core
    uid = request.state.viewer.user_id
    order = svc.order_by_public(request.path_params["public_id"])
    if order is None or (order["user_id"] != uid and not request.state.viewer.is_admin):
        return redirect("/request/status", request, "request not found.")
    o = catalog.get_offer(order["offer_key"])
    purchase = core.db.get("purchases", order["purchase_id"]) if order["purchase_id"] else None
    if request.method == "POST":
        f = await form_data(request)
        action = fval(f, "action")
        if order["status"] != "paid":
            return redirect(f"/request/orders/{order['public_id']}", request, "details can be added after payment.", "warn")
        if action == "add":
            text = fval(f, "text")
            if text and not is_english(text):
                return redirect(f"/request/orders/{order['public_id']}", request, "english (us) only.", "error")
            files = files_of(f, "files")
            if not text and not files:
                return redirect(f"/request/orders/{order['public_id']}", request, "send text or a file.", "warn")
            if text:
                svc.add_detail(order, uid, "text", text[:8000], None)
                order = svc.order_by_public(order["public_id"])
            for up in files[:10]:
                try:
                    mid = await core.media.save_upload(up, uid, folder=f"requests/{order['public_id']}", source="request_detail")
                except ValueError as exc:
                    return redirect(f"/request/orders/{order['public_id']}", request, str(exc), "error")
                svc.add_detail(order, uid, "file", up.filename, mid)
                order = svc.order_by_public(order["public_id"])
            return redirect(f"/request/orders/{order['public_id']}", request, "saved.", "ok")
        if action in ("done", "skip"):
            await svc.finish_details(order, skipped=(action == "skip"))
            return redirect(f"/request/orders/{order['public_id']}", request, "details stored. nothing is guaranteed or promised. no refund." if action == "done" else "no details stored. you can add them later.", "ok")
    return render(request, "request/order.html", order=order, o=o, purchase=purchase, quote=Quote.from_json(order["quote_json"]),
                  details=svc.details(order["id"]), payment_received=PAYMENT_RECEIVED, **_ctx(request, svc))


@login_required
async def status(request: Request):
    svc = _svc(request)
    uid = request.state.viewer.user_id
    orders = svc.user_orders(uid)
    return render(request, "request/status.html", orders=orders, pending=svc.pending_orders(uid), **_ctx(request, svc))


routes = [
    Route("/request", landing), Route("/request/offers", offers), Route("/request/terms", terms, methods=["GET", "POST"]),
    Route("/request/start", start, methods=["GET", "POST"]), Route("/request/menu", menu), Route("/request/offer/{key}", offer, methods=["GET", "POST"]),
    Route("/request/confirm", confirm, methods=["POST"]), Route("/request/orders/{public_id}", order_page, methods=["GET", "POST"]),
    Route("/request/status", status),
]
