"""Request-system pricing engine (USD cents).

Standard request: unit price x units -> volume multiplier -> + setup fee -> x add-on multiplier + add-on fee
-> + off-hours % -> + weekend % -> + processing % -> + request fee -> round up -> floor (USD 1,000,000) -> split.
Contribution: exact amount. Activation: fixed price (USD 1,000,000 default).
Add-on upgrade: difference between the paid request and the request re-quoted with the new add-on level.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime

from ..money import ceil_mul, ceil_pct, round_up_to, split_amount, usd
from . import catalog
from .catalog import Offer


def is_offhours(local_dt: datetime, start: int, end: int) -> bool:
    h = local_dt.hour
    if start == end:
        return False
    return start <= h < end if start < end else (h >= start or h < end)


def is_weekend(local_dt: datetime) -> bool:
    return local_dt.weekday() >= 5


@dataclass
class Line:
    code: str
    label: str
    delta: int
    running: int
    note: str = ""


@dataclass
class Quote:
    offer_key: str
    offer_name: str
    kind: str
    units: int
    unit_label: str
    priority: str
    lines: list
    total: int
    parts: list
    factors: dict = field(default_factory=dict)
    attached_order_id: str | None = None

    @property
    def parts_count(self) -> int:
        return len(self.parts)

    def to_json(self) -> str:
        return json.dumps(asdict(self), default=str)

    @staticmethod
    def from_json(raw: str) -> "Quote":
        data = json.loads(raw)
        data["lines"] = [Line(**ln) for ln in data.get("lines", [])]
        return Quote(**data)

    def rows(self) -> list[dict]:
        out = []
        for ln in self.lines:
            base = ln.code in {"subtotal", "amount", "activation", "base_total", "new_total"}
            out.append({"label": ln.label + (f" ({ln.note})" if ln.note else ""),
                        "delta": "" if base else ("+" if ln.delta >= 0 else "-") + usd(abs(ln.delta)),
                        "running": usd(ln.running)})
        return out

    def breakdown_text(self) -> str:
        return "\n".join(f"{r['label']}: {r['delta'] + ' -> ' if r['delta'] else ''}{r['running']}" for r in self.rows())


class RqPricing:
    """Reads prices from Settings overrides (keys rq.price.<offer>.unit / .setup, rq.addon.<lvl>.mult/.fee, rq.volume_tiers)."""

    def __init__(self, settings):
        self.s = settings

    def _ov(self) -> dict:
        return self.s._overrides()

    def unit_price(self, key: str) -> int:
        return int(self._ov().get(f"rq.price.{key}.unit", catalog.OFFERS[key].unit_price_cents))

    def setup_fee(self, key: str) -> int:
        return int(self._ov().get(f"rq.price.{key}.setup", catalog.OFFERS[key].setup_fee_cents))

    def addon(self, level: str) -> tuple[float, int]:
        m = catalog.ADDON_LEVELS[level]
        return float(self._ov().get(f"rq.addon.{level}.mult", m["mult"])), int(self._ov().get(f"rq.addon.{level}.fee", m["fee_cents"]))

    def volume_tiers(self) -> list[tuple[int, float]]:
        raw = self._ov().get("rq.volume_tiers")
        tiers = [(int(a), float(b)) for a, b in raw] if raw else list(catalog.DEFAULT_VOLUME_TIERS)
        tiers.sort()
        return tiers

    def volume_multiplier(self, units: int) -> float:
        mult = 1.0
        for threshold, m in self.volume_tiers():
            if units >= threshold:
                mult = m
        return mult

    def set_price(self, key: str, unit: int | None = None, setup: int | None = None, actor: int | None = None) -> None:
        if unit is not None:
            self.s.db.set_setting(f"rq.price.{key}.unit", int(unit), actor)
        if setup is not None:
            self.s.db.set_setting(f"rq.price.{key}.setup", int(setup), actor)
        self.s.invalidate()

    def set_addon(self, level: str, mult: float | None = None, fee: int | None = None, actor: int | None = None) -> None:
        if mult is not None:
            self.s.db.set_setting(f"rq.addon.{level}.mult", float(mult), actor)
        if fee is not None:
            self.s.db.set_setting(f"rq.addon.{level}.fee", int(fee), actor)
        self.s.invalidate()

    def set_volume_tiers(self, tiers: list[tuple[int, float]], actor: int | None = None) -> None:
        self.s.db.set_setting("rq.volume_tiers", [[int(a), float(b)] for a, b in tiers], actor)
        self.s.invalidate()

    def activation_price(self) -> int:
        return self.s.int("rq_activation_cents")

    def max_per_invoice(self) -> int:
        return self.s.int("max_usd_per_invoice_cents")

    # ---------------------------------------------------------------- quotes
    def time_factors(self, when_local: datetime) -> dict:
        oh, wk = self.s.int("rq_offhours_pct"), self.s.int("rq_weekend_pct")
        return {"offhours": bool(oh) and is_offhours(when_local, self.s.int("rq_offhours_start"), self.s.int("rq_offhours_end")),
                "offhours_pct": oh, "weekend": bool(wk) and is_weekend(when_local), "weekend_pct": wk,
                "quoted_at_local": when_local.isoformat(timespec="seconds")}

    def quote_activation(self) -> Quote:
        price = self.activation_price()
        offer = catalog.OFFERS[catalog.ACTIVATION_KEY]
        return Quote(offer_key=offer.key, offer_name=offer.name, kind="activation", units=1, unit_label=offer.unit, priority="none",
                     lines=[Line("activation", "Request-system activation (minimum price)", price, price)], total=price,
                     parts=split_amount(price, self.max_per_invoice()), factors={"max_per_invoice": self.max_per_invoice()})

    def quote_contribution(self, cents: int) -> Quote:
        offer = catalog.OFFERS[catalog.CONTRIBUTION_KEY]
        lo, hi = self.s.int("rq_contribution_min_cents"), self.s.int("rq_contribution_max_cents")
        if cents < lo or cents > hi:
            raise ValueError(f"Contribution must be between {usd(lo)} and {usd(hi)}.")
        return Quote(offer_key=offer.key, offer_name=offer.name, kind="contribution", units=cents, unit_label="usdc", priority="none",
                     lines=[Line("amount", "Contribution amount", cents, cents)], total=cents,
                     parts=split_amount(cents, self.max_per_invoice()), factors={"max_per_invoice": self.max_per_invoice()})

    def quote_standard(self, offer: Offer, units: int, priority: str, when_local: datetime, factors: dict | None = None) -> Quote:
        if offer.kind != "standard":
            raise ValueError("Not a standard offer")
        if units < 1 or units > offer.max_units:
            raise ValueError(f"Units must be between 1 and {offer.max_units:,}.")
        if priority not in catalog.ADDON_LEVELS:
            raise ValueError("Unknown add-on level")
        tf = factors or self.time_factors(when_local)
        unit_price, setup_fee = self.unit_price(offer.key), self.setup_fee(offer.key)
        vol = self.volume_multiplier(units)
        a_mult, a_fee = self.addon(priority)
        proc, req_fee = self.s.int("rq_processing_pct"), self.s.int("rq_request_fee_cents")
        step, floor = self.s.int("rq_rounding_cents"), self.s.int("rq_min_total_cents")
        lines: list[Line] = []
        running = unit_price * units
        lines.append(Line("subtotal", f"{units:,} x {usd(unit_price)}", running, running, note=f"per {offer.unit}"))
        if vol != 1.0:
            new = ceil_mul(running, vol); lines.append(Line("volume", f"Volume multiplier x{vol:g}", new - running, new)); running = new
        if setup_fee:
            running += setup_fee; lines.append(Line("setup", "Setup fee", setup_fee, running))
        if priority != "none":
            name = catalog.ADDON_LEVELS[priority]["name"]
            new = ceil_mul(running, a_mult); lines.append(Line("addon_mult", f"{name} x{a_mult:g}", new - running, new)); running = new
            if a_fee:
                running += a_fee; lines.append(Line("addon_fee", f"{name} fee", a_fee, running))
        if tf.get("offhours"):
            new = ceil_pct(running, int(tf["offhours_pct"])); lines.append(Line("offhours", f"Off-hours surcharge +{tf['offhours_pct']}%", new - running, new)); running = new
        if tf.get("weekend"):
            new = ceil_pct(running, int(tf["weekend_pct"])); lines.append(Line("weekend", f"Weekend surcharge +{tf['weekend_pct']}%", new - running, new)); running = new
        if proc:
            new = ceil_pct(running, proc); lines.append(Line("processing", f"Processing fee +{proc}%", new - running, new)); running = new
        if req_fee:
            running += req_fee; lines.append(Line("request_fee", "Request fee", req_fee, running))
        rounded = round_up_to(running, step)
        if rounded != running:
            lines.append(Line("rounding", f"Rounded up to {usd(step)}", rounded - running, rounded)); running = rounded
        if running < floor:
            lines.append(Line("minimum", f"Minimum total {usd(floor)}", floor - running, floor)); running = floor
        factors_all = dict(tf)
        factors_all.update(unit_price=unit_price, setup_fee=setup_fee, volume_mult=vol, addon_mult=a_mult, addon_fee=a_fee,
                           processing_pct=proc, request_fee=req_fee, rounding=step, min_total=floor, max_per_invoice=self.max_per_invoice())
        return Quote(offer_key=offer.key, offer_name=offer.name, kind="standard", units=units,
                     unit_label=offer.unit if units == 1 else offer.unit_plural, priority=priority, lines=lines, total=running,
                     parts=split_amount(running, self.max_per_invoice()), factors=factors_all)

    def quote_addon_upgrade(self, base: Quote, new_level: str, base_public_id: str) -> Quote:
        if base.kind != "standard":
            raise ValueError("Add-ons attach to standard requests only.")
        if catalog.ADDON_LEVELS[new_level]["rank"] <= catalog.ADDON_LEVELS[base.priority]["rank"]:
            raise ValueError("That request already has this add-on level or a higher one.")
        offer = catalog.OFFERS[base.offer_key]
        factors = {k: base.factors.get(k) for k in ("offhours", "offhours_pct", "weekend", "weekend_pct", "quoted_at_local")}
        upgraded = self.quote_standard(offer, base.units, new_level, datetime.now(), factors=factors)
        delta = upgraded.total - base.total
        if delta <= 0:
            raise ValueError("No additional charge results from this add-on.")
        addon_offer = catalog.OFFERS[f"addon_{new_level}"]
        lines = [Line("base_total", f"Request {base_public_id} total as paid", base.total, base.total),
                 Line("new_total", f"Total with {addon_offer.name}", upgraded.total, upgraded.total),
                 Line("delta", "Add-on charge (difference)", delta, delta)]
        return Quote(offer_key=addon_offer.key, offer_name=addon_offer.name, kind="addon", units=1, unit_label="request",
                     priority=new_level, lines=lines, total=delta, parts=split_amount(delta, self.max_per_invoice()),
                     factors={"base_total": base.total, "upgraded_total": upgraded.total, "base_order": base_public_id,
                              "max_per_invoice": self.max_per_invoice()}, attached_order_id=base_public_id)

    def unit_price_label(self, offer: Offer) -> str:
        if offer.kind == "standard":
            return f"{usd(self.unit_price(offer.key))} / {offer.unit}"
        if offer.kind == "contribution":
            return "any amount"
        if offer.kind == "addon":
            mult, fee = self.addon(catalog.addon_level_from_offer_key(offer.key) or "none")
            return f"x{mult:g} + {usd(fee)}"
        if offer.kind == "activation":
            return usd(self.activation_price())
        return ""
