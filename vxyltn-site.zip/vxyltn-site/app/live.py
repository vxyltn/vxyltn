"""Livestreams: sessions, access modes, tickets, chat (SSE), paid pins/highlights, tip goals, milestones, offers, recordings."""
from __future__ import annotations

import json
import sqlite3

from .messaging import publish
from .util import loads, now_ts


def upcoming(db, limit: int = 20) -> list[sqlite3.Row]:
    return db.all("SELECT * FROM streams WHERE status IN ('scheduled','live') ORDER BY CASE status WHEN 'live' THEN 0 ELSE 1 END, scheduled_at LIMIT ?", (limit,))


def past(db, limit: int = 50) -> list[sqlite3.Row]:
    return db.all("SELECT * FROM streams WHERE status='ended' ORDER BY ended_at DESC LIMIT ?", (limit,))


def chat(db, stream_id: int, after_id: int = 0, limit: int = 200) -> list[sqlite3.Row]:
    return db.all("SELECT c.*, u.username, u.display_name, u.priority_status, u.role FROM stream_chat c LEFT JOIN users u ON u.id=c.user_id"
                  " WHERE c.stream_id=? AND c.id>? AND c.hidden=0 ORDER BY c.id LIMIT ?", (stream_id, after_id, limit))


def pinned(db, stream_id: int) -> list[sqlite3.Row]:
    return db.all("SELECT c.*, u.username, u.display_name FROM stream_chat c LEFT JOIN users u ON u.id=c.user_id"
                  " WHERE c.stream_id=? AND c.kind='pinned' AND c.pinned_until>? AND c.hidden=0 ORDER BY c.amount_cents DESC", (stream_id, now_ts()))


def post_chat(db, stream_id: int, user_id: int | None, body: str, kind: str = "chat", amount_cents: int | None = None,
              pin_minutes: int = 0) -> int:
    ts = now_ts()
    cid = db.insert("stream_chat", stream_id=stream_id, user_id=user_id, body=body[:500], kind=kind, amount_cents=amount_cents,
                    pinned_until=(ts + pin_minutes * 60) if pin_minutes else None, created_at=ts)
    publish(f"stream:{stream_id}", {"type": "chat", "id": cid, "kind": kind})
    return cid


def touch_viewer(db, stream_id: int, user_id: int) -> None:
    ts = now_ts()
    db.execute("INSERT INTO stream_viewers(stream_id, user_id, joined_at, last_seen_at) VALUES (?,?,?,?)"
               " ON CONFLICT(stream_id, user_id) DO UPDATE SET last_seen_at=excluded.last_seen_at", (stream_id, user_id, ts, ts))


def viewers_now(db, stream_id: int) -> int:
    return db.count("stream_viewers", "stream_id=? AND last_seen_at>?", (stream_id, now_ts() - 90))


def add_tip(db, stream_id: int, user_id: int | None, amount_cents: int, message: str | None, kind: str = "tip") -> dict:
    """Record a stream tip on the goal meter; returns milestone info."""
    s = db.get("streams", stream_id)
    total = int(s["tips_total_cents"]) + amount_cents
    db.update("streams", stream_id, tips_total_cents=total)
    milestones = loads(s["milestones_json"], [])
    hit = []
    for m in milestones:
        if not m.get("hit") and total >= int(m.get("cents", 0)):
            m["hit"] = True
            m["hit_at"] = now_ts()
            hit.append(m)
    if hit:
        db.update("streams", stream_id, milestones_json=json.dumps(milestones))
    post_chat(db, stream_id, user_id, message or "", kind=kind, amount_cents=amount_cents)
    publish(f"stream:{stream_id}", {"type": "goal", "total_cents": total, "goal_cents": s["tip_goal_cents"], "hit": [m.get("label") for m in hit]})
    return {"total_cents": total, "hit": hit}


def set_status(db, stream_id: int, status: str, actor: int) -> None:
    ts = now_ts()
    fields = {"status": status}
    if status == "live":
        fields["started_at"] = ts
    if status == "ended":
        fields["ended_at"] = ts
    db.update("streams", stream_id, **fields)
    db.audit(f"stream.{status}", actor_user_id=actor, actor_role="admin", entity_type="stream", entity_id=stream_id)
    publish(f"stream:{stream_id}", {"type": "status", "status": status})
    if status == "live":
        s = db.get("streams", stream_id)
        for r in db.all("SELECT user_id FROM stream_rsvps WHERE stream_id=?", (stream_id,)):
            db.notify(r["user_id"], "live", f"Live now: {s['title']}", "", f"/live/{stream_id}")


def grant_ticket(db, stream_id: int, user_id: int, purchase_id: int | None) -> None:
    db.execute("INSERT OR IGNORE INTO stream_tickets(stream_id, user_id, purchase_id, created_at) VALUES (?,?,?,?)", (stream_id, user_id, purchase_id, now_ts()))


def offers_active(stream: sqlite3.Row) -> list[dict]:
    ts = now_ts()
    out = []
    for o in loads(stream["offers_json"], []):
        if o.get("until") and int(o["until"]) < ts:
            continue
        out.append(o)
    return out


def attach_recording(db, stream_id: int, media_id: int, actor: int) -> None:
    db.update("streams", stream_id, recording_media_id=media_id)
    db.execute("UPDATE media SET folder='recordings', source='recording' WHERE id=?", (media_id,))
    db.audit("stream.recording_attached", actor_user_id=actor, actor_role="admin", entity_type="stream", entity_id=stream_id, data={"media_id": media_id})
