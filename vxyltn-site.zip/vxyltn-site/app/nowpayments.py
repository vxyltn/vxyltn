"""NOWPayments client (crypto checkout) and IPN signature verification.

Prices are denominated in USDC (ERC-20) by default (``PRICE_CURRENCY=usdc``); the payer picks any
coin NOWPayments supports on the hosted checkout page, converted at the processor's rate.

Flow used by the site:
  1. POST /v1/invoice  -> hosted checkout page (invoice_url); we redirect the payer there.
  2. NOWPayments calls our IPN URL with x-nowpayments-sig (HMAC-SHA512 over the sorted JSON body).
  3. We verify the signature, then confirm the status with GET /v1/payment/{payment_id}
     (authoritative when an API key is configured), and credit the purchase when the
     status is in the configured paid set ("finished" by default).
  4. A scheduler job polls pending payments as a fallback if an IPN was missed.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
from typing import Any

import httpx

from .config import Config

log = logging.getLogger(__name__)

PAID = {"finished"}
PENDING = {"waiting", "confirming", "confirmed", "sending", "partially_paid"}
DEAD = {"failed", "expired", "refunded"}
STATUS_HELP = {
    "waiting": "Waiting for the payment to arrive.",
    "confirming": "Payment seen on the blockchain, waiting for confirmations.",
    "confirmed": "Confirmed on the blockchain.",
    "sending": "Funds are being settled.",
    "partially_paid": "Less than the full amount was received. Send the remainder to the same address within the time limit.",
    "finished": "Payment completed.",
    "failed": "Payment failed.",
    "refunded": "Refunded by the processor.",
    "expired": "The payment window expired.",
}


class _RawNum(str):
    """A number kept exactly as it appeared in the JSON body."""


def _parse_raw(body: bytes) -> Any:
    return json.loads(body.decode("utf-8"), parse_float=_RawNum, parse_int=_RawNum, parse_constant=_RawNum)


def _ser(obj: Any, ensure_ascii: bool, sort_nested: bool, top_keys: set | None = None) -> str:
    if isinstance(obj, _RawNum):
        return str(obj)
    if obj is None:
        return "null"
    if obj is True:
        return "true"
    if obj is False:
        return "false"
    if isinstance(obj, (int, float)):
        return json.dumps(obj)
    if isinstance(obj, str):
        return json.dumps(obj, ensure_ascii=ensure_ascii)
    if isinstance(obj, list):
        return "[" + ",".join(_ser(x, ensure_ascii, sort_nested, top_keys) for x in obj) + "]"
    if isinstance(obj, dict):
        keys = list(obj.keys())
        if sort_nested:
            keys = sorted(keys)
        if top_keys is not None:
            keys = [k for k in keys if k in top_keys]
        return "{" + ",".join(f"{json.dumps(k, ensure_ascii=ensure_ascii)}:{_ser(obj[k], ensure_ascii, sort_nested, top_keys)}" for k in keys) + "}"
    return json.dumps(str(obj), ensure_ascii=ensure_ascii)


def ipn_candidates(body: bytes) -> list[str]:
    """Serializations that different NOWPayments SDK examples sign (PHP ksort+json_encode, Node JSON.stringify with sorted replacer)."""
    data = _parse_raw(body)
    if not isinstance(data, dict):
        return [body.decode("utf-8", "replace")]
    top_sorted = {k: data[k] for k in sorted(data)}
    top_keys = set(data.keys())
    out = [
        _ser(top_sorted, True, False),                 # PHP: ksort (top-level) + json_encode (escapes unicode)
        _ser(top_sorted, False, False),                # same, unicode unescaped
        _ser(top_sorted, True, True),                  # recursive sort
        _ser(top_sorted, False, True),
        _ser(top_sorted, False, True, top_keys),       # Node replacer-array quirk: nested filtered to top-level keys
        _ser(top_sorted, True, True, top_keys),
    ]
    seen, uniq = set(), []
    for s in out:
        if s not in seen:
            seen.add(s)
            uniq.append(s)
    return uniq


def verify_ipn(secret: str, body: bytes, signature: str | None) -> bool:
    if not secret or not signature:
        return False
    for candidate in ipn_candidates(body):
        digest = hmac.new(secret.encode("utf-8"), candidate.encode("utf-8"), hashlib.sha512).hexdigest()
        if hmac.compare_digest(digest, signature.strip().lower()):
            return True
    return False


def sign_ipn(secret: str, payload: dict) -> str:
    """Used by tests: sign the way the PHP example does (top-level sorted, escaped unicode)."""
    body = json.dumps(payload, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    cand = ipn_candidates(body)[0]
    return hmac.new(secret.encode("utf-8"), cand.encode("utf-8"), hashlib.sha512).hexdigest()


class NowPayments:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self._client: httpx.AsyncClient | None = None
        self._jwt: str | None = None
        self._jwt_at: float = 0.0
        self.price_currency = cfg.price_currency or "usd"

    @property
    def enabled(self) -> bool:
        return bool(self.cfg.np_api_key)

    def _c(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(base_url=self.cfg.np_base, timeout=30,
                                             headers={"x-api-key": self.cfg.np_api_key, "Content-Type": "application/json"})
        return self._client

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()

    async def status(self) -> dict:
        r = await self._c().get("/status")
        return r.json()

    async def currencies(self) -> list[str]:
        r = await self._c().get("/merchant/coins")
        if r.status_code != 200:
            r = await self._c().get("/currencies")
        data = r.json()
        return [str(c).lower() for c in (data.get("selectedCurrencies") or data.get("currencies") or [])]

    async def verify_price_currency(self) -> str:
        """Confirm the configured price currency (usdc) is accepted; otherwise fall back to fiat usd so invoices never fail."""
        if not self.enabled:
            return self.price_currency
        try:
            available = await self.currencies()
        except Exception as exc:  # pragma: no cover - network
            log.warning("could not list NOWPayments currencies: %s", exc)
            return self.price_currency
        if available and self.price_currency != "usd" and self.price_currency not in available:
            log.warning("price currency %s not in NOWPayments currency list; falling back to usd", self.price_currency)
            self.price_currency = "usd"
        return self.price_currency

    async def min_amount(self, currency_from: str, currency_to: str | None = None) -> dict:
        currency_to = currency_to or self.price_currency
        r = await self._c().get("/min-amount", params={"currency_from": currency_from, "currency_to": currency_to,
                                                       "fiat_equivalent": "usd", "is_fee_paid_by_user": str(self.cfg.np_fee_paid_by_user).lower()})
        return r.json()

    async def estimate(self, amount_usd: str, currency_to: str) -> dict:
        r = await self._c().get("/estimate", params={"amount": amount_usd, "currency_from": self.price_currency, "currency_to": currency_to})
        return r.json()

    async def create_invoice(self, amount_usd: str, order_ref: str, description: str, ipn_url: str, success_url: str,
                             cancel_url: str, pay_currency: str | None = None, fixed_rate: bool | None = None,
                             fee_paid_by_user: bool | None = None) -> dict:
        body: dict[str, Any] = {
            "price_amount": amount_usd, "price_currency": self.price_currency, "order_id": order_ref,
            "order_description": description[:200], "ipn_callback_url": ipn_url,
            "success_url": success_url, "cancel_url": cancel_url,
            "is_fixed_rate": self.cfg.np_fixed_rate if fixed_rate is None else fixed_rate,
            "is_fee_paid_by_user": self.cfg.np_fee_paid_by_user if fee_paid_by_user is None else fee_paid_by_user,
        }
        pc = pay_currency or self.cfg.np_default_pay_currency
        if pc:
            body["pay_currency"] = pc
        r = await self._c().post("/invoice", json=body)
        data = r.json()
        if r.status_code >= 400 or not data.get("invoice_url"):
            raise NowPaymentsError(f"invoice creation failed: {r.status_code} {data}")
        return data

    async def create_payment(self, amount_usd: str, pay_currency: str, order_ref: str, description: str, ipn_url: str) -> dict:
        body = {"price_amount": amount_usd, "price_currency": self.price_currency, "pay_currency": pay_currency, "order_id": order_ref,
                "order_description": description[:200], "ipn_callback_url": ipn_url,
                "is_fixed_rate": self.cfg.np_fixed_rate, "is_fee_paid_by_user": self.cfg.np_fee_paid_by_user}
        r = await self._c().post("/payment", json=body)
        data = r.json()
        if r.status_code >= 400 or not data.get("payment_id"):
            raise NowPaymentsError(f"payment creation failed: {r.status_code} {data}")
        return data

    async def payment_status(self, payment_id: str) -> dict | None:
        r = await self._c().get(f"/payment/{payment_id}")
        if r.status_code == 200:
            return r.json()
        log.warning("payment status %s -> %s %s", payment_id, r.status_code, r.text[:200])
        return None

    async def _bearer(self) -> str | None:
        import time
        if not (self.cfg.np_email and self.cfg.np_password):
            return None
        if self._jwt and time.time() - self._jwt_at < 240:
            return self._jwt
        r = await self._c().post("/auth", json={"email": self.cfg.np_email, "password": self.cfg.np_password})
        if r.status_code == 200 and r.json().get("token"):
            self._jwt = r.json()["token"]
            self._jwt_at = time.time()
            return self._jwt
        return None

    async def list_payments(self, limit: int = 100, page: int = 0, invoice_id: str | None = None, date_from: str | None = None) -> list[dict]:
        token = await self._bearer()
        if not token:
            return []
        params: dict[str, Any] = {"limit": limit, "page": page, "sortBy": "created_at", "orderBy": "desc"}
        if invoice_id:
            params["invoiceId"] = invoice_id
        if date_from:
            params["dateFrom"] = date_from
        r = await self._c().get("/payment/", params=params, headers={"Authorization": f"Bearer {token}"})
        if r.status_code != 200:
            return []
        return r.json().get("data") or []


class NowPaymentsError(RuntimeError):
    pass
