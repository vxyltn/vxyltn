"""Application context shared by routes, services and jobs."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from .config import Config
from .db import Database
from .emailer import Emailer
from .media import MediaStore
from .notify import Notifier
from .nowpayments import NowPayments
from .settings import Settings
from .util import fmt_local, now_ts


@dataclass
class Core:
    cfg: Config
    db: Database
    settings: Settings
    media: MediaStore
    emailer: Emailer
    notifier: Notifier
    np: NowPayments
    payments: Any = None          # app.payments.Payments (set after construction)
    started_at: int = field(default_factory=now_ts)
    extras: dict = field(default_factory=dict)

    @property
    def tz(self):
        return self.cfg.tz

    def local(self, ts) -> str:
        return fmt_local(ts, self.tz)

    def now_local(self) -> datetime:
        return datetime.now(self.tz)

    def url(self, path: str) -> str:
        return f"{self.cfg.base_url}{path}"


def build_core(cfg: Config) -> Core:
    db = Database(cfg.db_path)
    settings = Settings(cfg, db)
    core = Core(cfg=cfg, db=db, settings=settings, media=MediaStore(cfg, db), emailer=Emailer(cfg, db),
                notifier=Notifier(cfg, db), np=NowPayments(cfg))
    from .payments import Payments  # local import: payments imports core types
    core.payments = Payments(core)
    return core
