/* request.vxyltn.com — small, dependency-free enhancements. */
(function () {
  'use strict';
  var body = document.body;
  var CSRF = (document.querySelector('meta[name="csrf"]') || {}).content || '';

  // confirm dialogs
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (f.dataset && f.dataset.confirm && !window.confirm(f.dataset.confirm)) e.preventDefault();
  });

  // countdowns: <time data-countdown="unixts">
  function tick() {
    document.querySelectorAll('[data-countdown]').forEach(function (el) {
      var t = parseInt(el.getAttribute('data-countdown'), 10) * 1000 - Date.now();
      if (t <= 0) { el.textContent = el.getAttribute('data-done') || 'now'; if (el.dataset.reload && !el.dataset.reloaded) { el.dataset.reloaded = '1'; setTimeout(function () { location.reload(); }, 1500); } return; }
      var s = Math.floor(t / 1000), d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60), sec = s % 60;
      el.textContent = (d ? d + 'd ' : '') + String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':' + String(sec).padStart(2, '0');
    });
  }
  tick(); setInterval(tick, 1000);

  // payment status polling: <div data-pay-status="/api/pay/PX..">
  var ps = document.querySelector('[data-pay-status]');
  if (ps) {
    var poll = function () {
      fetch(ps.getAttribute('data-pay-status'), { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) {
        if (j.status && j.status !== ps.getAttribute('data-current')) { location.reload(); }
      }).catch(function () {});
    };
    setInterval(poll, 8000);
  }

  // SSE live feeds: <div data-sse="/live/1/events" data-target="#chat" data-src="/live/1/chat?after=">
  document.querySelectorAll('[data-sse]').forEach(function (box) {
    if (!window.EventSource) return;
    var target = document.querySelector(box.getAttribute('data-target') || '#chat');
    var src = box.getAttribute('data-src');
    var es = new EventSource(box.getAttribute('data-sse'));
    var refresh = function () {
      if (!target || !src) return;
      var last = target.getAttribute('data-last') || '0';
      fetch(src + last, { credentials: 'same-origin' }).then(function (r) { return r.text(); }).then(function (html) {
        if (!html.trim()) return;
        var tmp = document.createElement('div'); tmp.innerHTML = html;
        var lastId = tmp.querySelector('[data-id]:last-child');
        while (tmp.firstChild) target.appendChild(tmp.firstChild);
        if (lastId) target.setAttribute('data-last', lastId.getAttribute('data-id'));
        target.scrollTop = target.scrollHeight;
      });
    };
    es.addEventListener('chat', refresh); es.addEventListener('message', refresh);
    es.addEventListener('goal', function (e) {
      try { var d = JSON.parse(e.data); var g = document.querySelector('[data-goal]'); if (g && d.goal_cents) { g.style.width = Math.min(100, 100 * d.total_cents / d.goal_cents) + '%'; var t = document.querySelector('[data-goal-text]'); if (t) t.textContent = '$' + (d.total_cents / 100).toLocaleString() + ' / $' + (d.goal_cents / 100).toLocaleString(); } } catch (err) {}
    });
    es.addEventListener('status', function () { setTimeout(function () { location.reload(); }, 800); });
    refresh();
  });

  // chat forms posting via fetch (keeps scroll)
  document.querySelectorAll('form[data-async]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var fd = new FormData(f);
      fetch(f.action, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-CSRF': CSRF } }).then(function (r) {
        if (r.redirected) { location.href = r.url; return; }
        if (r.status >= 400) { r.text().then(function (t) { alert(t.slice(0, 200)); }); return; }
        f.reset();
        var box = document.querySelector('[data-sse]'); if (box) { box.dispatchEvent(new Event('refresh')); }
      });
    });
  });

  // screenshot deterrence (deterrent only): blur on PrintScreen / hidden tab / devtools-ish shortcuts, block context menu on protected media
  if (body.classList.contains('deter')) {
    document.addEventListener('contextmenu', function (e) { if (e.target.closest('.protect')) e.preventDefault(); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'PrintScreen' || (e.metaKey && e.shiftKey && ['3', '4', '5', 'S', 's'].indexOf(e.key) >= 0) || (e.ctrlKey && e.key.toLowerCase() === 'p')) {
        body.classList.add('blur-all'); setTimeout(function () { body.classList.remove('blur-all'); }, 2500);
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText('').catch(function () {});
      }
    });
    document.addEventListener('visibilitychange', function () { body.classList.toggle('blur-all', document.hidden); });
    window.addEventListener('blur', function () { body.classList.add('blur-all'); });
    window.addEventListener('focus', function () { body.classList.remove('blur-all'); });
    document.querySelectorAll('.protect img').forEach(function (img) { img.setAttribute('draggable', 'false'); });
  }

  // copy buttons
  document.querySelectorAll('[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () { navigator.clipboard.writeText(b.getAttribute('data-copy')).then(function () { b.textContent = 'Copied'; }); });
  });

  // crypto volatility acknowledgement
  var ack = document.querySelector('[data-crypto-ack]');
  if (ack) { var btn = ack.closest('form').querySelector('button[type=submit]'); if (btn) { btn.disabled = !ack.checked; ack.addEventListener('change', function () { btn.disabled = !ack.checked; }); } }

  // local time rendering: <time data-ts="unix">
  document.querySelectorAll('time[data-ts]').forEach(function (el) {
    var d = new Date(parseInt(el.getAttribute('data-ts'), 10) * 1000);
    el.title = d.toString(); if (el.dataset.localize) el.textContent = d.toLocaleString();
  });
})();
