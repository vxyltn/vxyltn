"""Environment configuration for request.vxyltn.com.

Read once at startup. Admin-editable knobs (prices, multipliers, limits, toggles)
default from here and are overridden at runtime through app.settings.
"""
from __future__ import annotations

import os
import secrets
from dataclasses import dataclass, field
from zoneinfo import ZoneInfo


def _env(name: str, default: str = "") -> str:
    v = os.environ.get(name)
    return default if v is None or v.strip() == "" else v.strip()


def _int(name: str, default: int) -> int:
    raw = _env(name)
    if not raw:
        return default
    try:
        return int(raw.replace("_", "").replace(",", ""))
    except ValueError as exc:
        raise SystemExit(f"{name} must be an integer, got {raw!r}") from exc


def _float(name: str, default: float) -> float:
    raw = _env(name)
    return float(raw) if raw else default


def _bool(name: str, default: bool) -> bool:
    raw = _env(name).lower()
    return default if not raw else raw in {"1", "true", "yes", "on", "y"}


def _list(name: str, default: tuple[str, ...] = ()) -> tuple[str, ...]:
    raw = _env(name)
    if not raw:
        return default
    return tuple(x.strip() for x in raw.replace(";", ",").split(",") if x.strip())


@dataclass(frozen=True)
class Config:
    # --- identity / brand ------------------------------------------------
    site_name: str = "VXYLTN"
    creator_handle: str = "@vxyltn"
    site_domain: str = "request.vxyltn.com"
    base_url: str = "https://request.vxyltn.com"
    main_site: str = "vxyltn.com"
    legal_entity: str = "VXYLTN"
    legal_email: str = "legal@vxyltn.com"
    support_email: str = "support@vxyltn.com"
    dmca_agent: str = "legal@vxyltn.com"

    # --- security --------------------------------------------------------
    secret_key: str = ""
    admin_email: str = ""
    admin_password: str = ""            # bootstrap only; change after first login
    admin_require_2fa: bool = True
    session_days: int = 30
    cookie_secure: bool = True
    trusted_proxy: bool = True          # trust X-Forwarded-For / CF-Connecting-IP (Caddy on EC2, ALB, Cloudflare)
    rate_limit_per_minute: int = 120
    max_upload_mb: int = 2048
    allowed_countries_block: tuple[str, ...] = ()   # ISO country codes to geo-block

    # --- storage ---------------------------------------------------------
    data_dir: str = "data"
    db_path: str = "data/vxyltn.sqlite3"
    uploads_dir: str = "data/uploads"
    backups_dir: str = "data/backups"
    tz_name: str = "Europe/Istanbul"

    # --- payments (NOWPayments only) --------------------------------------
    np_api_key: str = ""
    np_ipn_secret: str = ""
    np_sandbox: bool = False
    np_email: str = ""                  # optional: enables payment listing/reconciliation via JWT
    np_password: str = ""
    np_fixed_rate: bool = False
    np_fee_paid_by_user: bool = True
    np_default_pay_currency: str = ""   # empty = payer picks any coin on the NOWPayments page
    price_currency: str = "usdc"        # NOWPayments price_currency: usdc (erc-20) is the main currency; "usd" = fiat-denominated
    currency: str = "USDC"
    currency_label: str = "usdc"
    display_currencies: tuple[str, ...] = ("USDC", "USD", "EUR", "GBP", "CHF", "BTC", "ETH")
    platform_tx_cap_cents: int = 100_000_000         # 1,000,000 automated cap for platform purchases
    platform_min_cents: int = 100_000                # every in-app purchase starts at 1,000 (contributions exempt)
    max_usd_per_invoice_cents: int = 0               # 0 = no splitting; else split requests into parts
    paid_statuses: tuple[str, ...] = ("finished",)   # add "confirmed" to credit before payout

    # --- request system ($1M minimum) ---------------------------------------
    rq_activation_cents: int = 100_000_000           # USD 1,000,000
    rq_min_total_cents: int = 100_000_000
    rq_session_hours: int = 24
    rq_unit_expiry_days: int = 56
    rq_invoice_ttl_hours: int = 48
    rq_processing_pct: int = 15
    rq_request_fee_cents: int = 20_000_000           # USD 200,000
    rq_offhours_pct: int = 25
    rq_offhours_start: int = 22
    rq_offhours_end: int = 8
    rq_weekend_pct: int = 25
    rq_rounding_cents: int = 1_000_000               # round up to USD 10,000
    rq_contribution_min_cents: int = 1               # contributions: no limit (1 cent technical floor)
    rq_contribution_max_cents: int = 10 ** 15
    rq_terms_version: str = "2026-10-21"
    rq_start_confirm_restart: bool = True

    # --- audience pricing (platform) --------------------------------------
    public_mult: float = 3.0
    follower_mult: float = 2.0
    preview_pass_hours: int = 24
    preview_pass_cents: int = 100_000
    public_question_cents: int = 100_000
    follower_badge_cents: int = 100_000
    priority_dm_cents: int = 100_000
    kyc_threshold_cents: int = 10_000_000            # 100,000 cumulative spend triggers KYC flag
    tip_presets_cents: tuple[int, ...] = (100_000, 250_000, 500_000, 1_000_000, 2_500_000)

    # --- email (SMTP adapter) --------------------------------------------
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = ""
    smtp_tls: bool = True

    # --- optional integrations (adapters) ----------------------------------
    google_client_id: str = ""
    google_client_secret: str = ""
    apple_client_id: str = ""
    twilio_sid: str = ""
    twilio_token: str = ""
    twilio_from: str = ""
    kyc_provider: str = ""              # jumio | onfido | manual
    kyc_webhook_secret: str = ""
    moderation_provider: str = ""       # hive | sightengine
    moderation_api_key: str = ""
    livestream_provider: str = "embed"  # embed | livekit | mux | cloudflare
    livestream_api_key: str = ""
    call_provider: str = "link"         # link | jitsi | whereby
    jitsi_base: str = "https://meet.jit.si"
    shopify_store: str = ""
    shopify_token: str = ""
    openai_api_key: str = ""
    fx_provider: str = "static"         # static | ecb
    fx_rates: dict = field(default_factory=lambda: {"USD": 1.0, "EUR": 0.92, "GBP": 0.78, "CHF": 0.88})
    ffmpeg_path: str = "ffmpeg"

    # --- telegram notifier (optional) --------------------------------------
    tg_bot_token: str = ""
    tg_admin_chat_id: str = ""
    tg_data_chat_id: str = ""

    # --- ops -------------------------------------------------------------
    port: int = 8080
    backup_hour_local: int = 3
    report_hour_local: int = 9
    log_level: str = "INFO"
    debug: bool = False

    @property
    def tz(self) -> ZoneInfo:
        return ZoneInfo(self.tz_name)

    @property
    def np_base(self) -> str:
        return "https://api-sandbox.nowpayments.io/v1" if self.np_sandbox else "https://api.nowpayments.io/v1"

    @property
    def email_enabled(self) -> bool:
        return bool(self.smtp_host and self.smtp_from)

    @property
    def payments_enabled(self) -> bool:
        return bool(self.np_api_key)


def load_config() -> Config:
    secret = _env("SECRET_KEY")
    if not secret:
        # Dev fallback; production must set SECRET_KEY or sessions reset on every restart.
        secret = secrets.token_hex(32)
    data_dir = _env("DATA_DIR", "data")
    fx = {}
    for pair in _list("FX_RATES"):
        if "=" in pair:
            k, v = pair.split("=", 1)
            try:
                fx[k.strip().upper()] = float(v)
            except ValueError:
                pass
    tz_name = _env("TZ_NAME", "Europe/Istanbul")
    ZoneInfo(tz_name)
    return Config(
        site_name=_env("SITE_NAME", "VXYLTN"),
        creator_handle=_env("CREATOR_HANDLE", "@vxyltn"),
        site_domain=_env("SITE_DOMAIN", "request.vxyltn.com"),
        base_url=_env("BASE_URL", "https://request.vxyltn.com").rstrip("/"),
        main_site=_env("MAIN_SITE", "vxyltn.com"),
        legal_entity=_env("LEGAL_ENTITY", "VXYLTN"),
        legal_email=_env("LEGAL_EMAIL", "legal@vxyltn.com"),
        support_email=_env("SUPPORT_EMAIL", "support@vxyltn.com"),
        dmca_agent=_env("DMCA_AGENT_EMAIL", _env("LEGAL_EMAIL", "legal@vxyltn.com")),
        secret_key=secret,
        admin_email=_env("ADMIN_EMAIL"),
        admin_password=_env("ADMIN_PASSWORD"),
        admin_require_2fa=_bool("ADMIN_REQUIRE_2FA", True),
        session_days=_int("SESSION_DAYS", 30),
        cookie_secure=_bool("COOKIE_SECURE", True),
        trusted_proxy=_bool("TRUSTED_PROXY", True),
        rate_limit_per_minute=_int("RATE_LIMIT_PER_MINUTE", 120),
        max_upload_mb=_int("MAX_UPLOAD_MB", 2048),
        allowed_countries_block=tuple(c.upper() for c in _list("GEO_BLOCK_COUNTRIES")),
        data_dir=data_dir,
        db_path=_env("DB_PATH", f"{data_dir}/vxyltn.sqlite3"),
        uploads_dir=_env("UPLOADS_DIR", f"{data_dir}/uploads"),
        backups_dir=_env("BACKUPS_DIR", f"{data_dir}/backups"),
        tz_name=tz_name,
        np_api_key=_env("NOWPAYMENTS_API_KEY"),
        np_ipn_secret=_env("NOWPAYMENTS_IPN_SECRET"),
        np_sandbox=_bool("NOWPAYMENTS_SANDBOX", False),
        np_email=_env("NOWPAYMENTS_EMAIL"),
        np_password=_env("NOWPAYMENTS_PASSWORD"),
        np_fixed_rate=_bool("NOWPAYMENTS_FIXED_RATE", False),
        np_fee_paid_by_user=_bool("NOWPAYMENTS_FEE_PAID_BY_USER", True),
        np_default_pay_currency=_env("NOWPAYMENTS_PAY_CURRENCY"),
        price_currency=_env("PRICE_CURRENCY", "usdc").lower(),
        currency=_env("CURRENCY_LABEL", "usdc").upper(),
        currency_label=_env("CURRENCY_LABEL", "usdc").lower(),
        display_currencies=_list("DISPLAY_CURRENCIES", ("USDC", "USD", "EUR", "GBP", "CHF", "BTC", "ETH")),
        platform_tx_cap_cents=_int("PLATFORM_TX_CAP_CENTS", 100_000_000),
        platform_min_cents=_int("PLATFORM_MIN_CENTS", 100_000),
        max_usd_per_invoice_cents=_int("MAX_USD_PER_INVOICE_CENTS", 0),
        paid_statuses=_list("PAID_STATUSES", ("finished",)),
        rq_activation_cents=_int("RQ_ACTIVATION_CENTS", 100_000_000),
        rq_min_total_cents=_int("RQ_MIN_TOTAL_CENTS", 100_000_000),
        rq_session_hours=_int("RQ_SESSION_HOURS", 24),
        rq_unit_expiry_days=_int("RQ_UNIT_EXPIRY_DAYS", 56),
        rq_invoice_ttl_hours=_int("RQ_INVOICE_TTL_HOURS", 48),
        rq_processing_pct=_int("RQ_PROCESSING_PCT", 15),
        rq_request_fee_cents=_int("RQ_REQUEST_FEE_CENTS", 20_000_000),
        rq_offhours_pct=_int("RQ_OFFHOURS_PCT", 25),
        rq_offhours_start=_int("RQ_OFFHOURS_START", 22),
        rq_offhours_end=_int("RQ_OFFHOURS_END", 8),
        rq_weekend_pct=_int("RQ_WEEKEND_PCT", 25),
        rq_rounding_cents=_int("RQ_ROUNDING_CENTS", 1_000_000),
        rq_contribution_min_cents=_int("RQ_CONTRIBUTION_MIN_CENTS", 1),
        rq_contribution_max_cents=_int("RQ_CONTRIBUTION_MAX_CENTS", 10 ** 15),
        rq_terms_version=_env("RQ_TERMS_VERSION", "2026-10-21"),
        rq_start_confirm_restart=_bool("RQ_START_CONFIRM_RESTART", True),
        public_mult=_float("PUBLIC_PRICE_MULT", 3.0),
        follower_mult=_float("FOLLOWER_PRICE_MULT", 2.0),
        preview_pass_hours=_int("PREVIEW_PASS_HOURS", 24),
        preview_pass_cents=_int("PREVIEW_PASS_CENTS", 100_000),
        public_question_cents=_int("PUBLIC_QUESTION_CENTS", 100_000),
        follower_badge_cents=_int("FOLLOWER_BADGE_CENTS", 100_000),
        priority_dm_cents=_int("PRIORITY_DM_CENTS", 100_000),
        kyc_threshold_cents=_int("KYC_THRESHOLD_CENTS", 10_000_000),
        tip_presets_cents=tuple(int(x) for x in _list("TIP_PRESETS_CENTS", ("100000", "250000", "500000", "1000000", "2500000"))),
        smtp_host=_env("SMTP_HOST"), smtp_port=_int("SMTP_PORT", 587), smtp_user=_env("SMTP_USER"),
        smtp_password=_env("SMTP_PASSWORD"), smtp_from=_env("SMTP_FROM"), smtp_tls=_bool("SMTP_TLS", True),
        google_client_id=_env("GOOGLE_CLIENT_ID"), google_client_secret=_env("GOOGLE_CLIENT_SECRET"),
        apple_client_id=_env("APPLE_CLIENT_ID"),
        twilio_sid=_env("TWILIO_SID"), twilio_token=_env("TWILIO_TOKEN"), twilio_from=_env("TWILIO_FROM"),
        kyc_provider=_env("KYC_PROVIDER"), kyc_webhook_secret=_env("KYC_WEBHOOK_SECRET"),
        moderation_provider=_env("MODERATION_PROVIDER"), moderation_api_key=_env("MODERATION_API_KEY"),
        livestream_provider=_env("LIVESTREAM_PROVIDER", "embed"), livestream_api_key=_env("LIVESTREAM_API_KEY"),
        call_provider=_env("CALL_PROVIDER", "link"), jitsi_base=_env("JITSI_BASE", "https://meet.jit.si"),
        shopify_store=_env("SHOPIFY_STORE"), shopify_token=_env("SHOPIFY_TOKEN"),
        openai_api_key=_env("OPENAI_API_KEY"),
        fx_provider=_env("FX_PROVIDER", "static"), fx_rates=fx or {"USD": 1.0, "EUR": 0.92, "GBP": 0.78, "CHF": 0.88},
        ffmpeg_path=_env("FFMPEG_PATH", "ffmpeg"),
        tg_bot_token=_env("TELEGRAM_BOT_TOKEN"), tg_admin_chat_id=_env("TELEGRAM_ADMIN_CHAT_ID"),
        tg_data_chat_id=_env("TELEGRAM_DATA_CHAT_ID"),
        port=_int("PORT", 8080),
        backup_hour_local=_int("BACKUP_HOUR_LOCAL", 3),
        report_hour_local=_int("REPORT_HOUR_LOCAL", 9),
        log_level=_env("LOG_LEVEL", "INFO").upper(),
        debug=_bool("DEBUG", False),
    )
