"""SQLite persistence: schema, connection, generic helpers, audit log, backups.

One file, WAL mode, on a persistent volume. Every table used by the platform
is declared here so the admin "resources" layer can introspect them.
Money is stored as integer USD cents.
"""
from __future__ import annotations

import csv
import io
import json
import os
import sqlite3
import threading
from typing import Any, Iterable

from .util import now_ts, token_hex

SCHEMA = r"""
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=OFF;
PRAGMA synchronous=NORMAL;

-- ------------------------------------------------------------------ core
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE, email_verified_at INTEGER,
  phone TEXT, phone_verified_at INTEGER,
  password_hash TEXT,
  username TEXT UNIQUE, display_name TEXT,
  avatar_media_id INTEGER, banner_media_id INTEGER, bio TEXT,
  dob TEXT, age_confirmed_at INTEGER, age_verified_at INTEGER,
  kyc_status TEXT NOT NULL DEFAULT 'none', kyc_note TEXT,
  totp_secret TEXT, totp_enabled_at INTEGER, recovery_codes_json TEXT,
  role TEXT NOT NULL DEFAULT 'user',
  is_follower INTEGER NOT NULL DEFAULT 0, followed_at INTEGER, follower_badge INTEGER NOT NULL DEFAULT 0,
  blocked INTEGER NOT NULL DEFAULT 0, blocked_reason TEXT, muted_until INTEGER,
  priority_status TEXT NOT NULL DEFAULT 'none', priority_at INTEGER,
  referral_code TEXT UNIQUE, referred_by INTEGER,
  country TEXT, timezone TEXT, locale TEXT NOT NULL DEFAULT 'en-US',
  marketing_opt_in INTEGER NOT NULL DEFAULT 0, notif_prefs_json TEXT,
  custom_fields_json TEXT, admin_note TEXT,
  total_spent_cents INTEGER NOT NULL DEFAULT 0, purchases_count INTEGER NOT NULL DEFAULT 0,
  wallet_cents INTEGER NOT NULL DEFAULT 0,
  oauth_google_sub TEXT, oauth_apple_sub TEXT,
  created_at INTEGER NOT NULL, last_seen_at INTEGER, last_ip TEXT, deleted_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_users_spent ON users(total_spent_cents);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL,
  last_seen_at INTEGER, ip TEXT, user_agent TEXT, twofa_ok INTEGER NOT NULL DEFAULT 0, revoked_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

CREATE TABLE IF NOT EXISTS email_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, email TEXT, kind TEXT NOT NULL,
  token_hash TEXT, code TEXT, expires_at INTEGER NOT NULL, used_at INTEGER, created_at INTEGER NOT NULL, meta_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_email_tokens_hash ON email_tokens(token_hash);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, actor_user_id INTEGER, actor_role TEXT,
  action TEXT NOT NULL, entity_type TEXT, entity_id TEXT, ip TEXT, data_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(ts);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_log(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_log(actor_user_id);

CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value_json TEXT NOT NULL, updated_at INTEGER, updated_by INTEGER);
CREATE TABLE IF NOT EXISTS counters (name TEXT PRIMARY KEY, value INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS rate_limit (key TEXT PRIMARY KEY, window_start INTEGER NOT NULL, count INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, kind TEXT NOT NULL, title TEXT, body TEXT, url TEXT,
  read_at INTEGER, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, read_at);

-- ------------------------------------------------------------------ media
CREATE TABLE IF NOT EXISTS media (
  id INTEGER PRIMARY KEY AUTOINCREMENT, owner_user_id INTEGER, kind TEXT NOT NULL, filename TEXT, path TEXT NOT NULL,
  mime TEXT, size INTEGER, width INTEGER, height INTEGER, duration REAL, sha256 TEXT,
  thumb_path TEXT, blur_path TEXT, poster_path TEXT, tags_json TEXT, folder TEXT, title TEXT, caption TEXT,
  alt TEXT, exif_stripped INTEGER NOT NULL DEFAULT 0, source TEXT NOT NULL DEFAULT 'upload', is_public INTEGER NOT NULL DEFAULT 0,
  usage_count INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, expires_at INTEGER, archived_at INTEGER, deleted_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_media_owner ON media(owner_user_id, id);
CREATE INDEX IF NOT EXISTS idx_media_folder ON media(folder);
CREATE VIRTUAL TABLE IF NOT EXISTS media_fts USING fts5(title, caption, tags, filename, content='');

CREATE TABLE IF NOT EXISTS download_tokens (
  token TEXT PRIMARY KEY, media_id INTEGER NOT NULL, user_id INTEGER, purpose TEXT, expires_at INTEGER NOT NULL,
  max_uses INTEGER NOT NULL DEFAULT 3, uses INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL
);

-- ------------------------------------------------------------------ content
CREATE TABLE IF NOT EXISTS collections (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, slug TEXT UNIQUE, description TEXT, kind TEXT NOT NULL DEFAULT 'collection',
  price_cents INTEGER, public_price_cents INTEGER, follower_price_cents INTEGER, min_tier_rank INTEGER NOT NULL DEFAULT 0,
  cover_media_id INTEGER, is_active INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, title TEXT, body_md TEXT,
  visibility TEXT NOT NULL DEFAULT 'member', min_tier_rank INTEGER NOT NULL DEFAULT 0,
  ppv_price_cents INTEGER, public_price_cents INTEGER, follower_price_cents INTEGER,
  is_pinned INTEGER NOT NULL DEFAULT 0, pin_order INTEGER, published_at INTEGER, scheduled_at INTEGER, expires_at INTEGER,
  is_archived INTEGER NOT NULL DEFAULT 0, collection_id INTEGER, series_order INTEGER,
  allow_comments INTEGER NOT NULL DEFAULT 1, comments_price_cents INTEGER,
  likes_count INTEGER NOT NULL DEFAULT 0, comments_count INTEGER NOT NULL DEFAULT 0, views_count INTEGER NOT NULL DEFAULT 0,
  unlocks_count INTEGER NOT NULL DEFAULT 0, revenue_cents INTEGER NOT NULL DEFAULT 0,
  watermark INTEGER NOT NULL DEFAULT 1, teaser_text TEXT, tags_json TEXT,
  created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, deleted_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_posts_pub ON posts(published_at);
CREATE INDEX IF NOT EXISTS idx_posts_coll ON posts(collection_id);

CREATE TABLE IF NOT EXISTS post_media (post_id INTEGER NOT NULL, media_id INTEGER NOT NULL, position INTEGER NOT NULL DEFAULT 0, is_preview INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(post_id, media_id));
CREATE TABLE IF NOT EXISTS polls (id INTEGER PRIMARY KEY AUTOINCREMENT, post_id INTEGER NOT NULL, question TEXT NOT NULL, options_json TEXT NOT NULL, multiple INTEGER NOT NULL DEFAULT 0, anonymous INTEGER NOT NULL DEFAULT 1, closes_at INTEGER, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS poll_votes (poll_id INTEGER NOT NULL, user_id INTEGER NOT NULL, option_idx INTEGER NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY(poll_id, user_id, option_idx));
CREATE TABLE IF NOT EXISTS post_likes (post_id INTEGER NOT NULL, user_id INTEGER NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY(post_id, user_id));
CREATE TABLE IF NOT EXISTS post_reactions (post_id INTEGER NOT NULL, user_id INTEGER NOT NULL, emoji TEXT NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY(post_id, user_id, emoji));
CREATE TABLE IF NOT EXISTS comments (
  id INTEGER PRIMARY KEY AUTOINCREMENT, post_id INTEGER NOT NULL, user_id INTEGER NOT NULL, parent_id INTEGER, depth INTEGER NOT NULL DEFAULT 0,
  body TEXT NOT NULL, is_private INTEGER NOT NULL DEFAULT 0, pinned INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, deleted_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_comments_post ON comments(post_id, id);
CREATE TABLE IF NOT EXISTS post_views (post_id INTEGER NOT NULL, user_id INTEGER, ts INTEGER NOT NULL, ip TEXT);
CREATE INDEX IF NOT EXISTS idx_post_views ON post_views(post_id, ts);

CREATE TABLE IF NOT EXISTS unlocks (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL,
  purchase_id INTEGER, created_at INTEGER NOT NULL, expires_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_unlocks_user ON unlocks(user_id, entity_type, entity_id);

-- ------------------------------------------------------------------ memberships
CREATE TABLE IF NOT EXISTS tiers (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, slug TEXT UNIQUE, description TEXT, icon TEXT,
  price_month_cents INTEGER NOT NULL, price_year_cents INTEGER, intro_price_cents INTEGER, intro_periods INTEGER NOT NULL DEFAULT 0,
  rank INTEGER NOT NULL DEFAULT 1, perks_json TEXT, max_members INTEGER, is_active INTEGER NOT NULL DEFAULT 1,
  welcome_template TEXT, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS bundles (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, tier_id INTEGER NOT NULL, months INTEGER NOT NULL, price_cents INTEGER NOT NULL,
  kind TEXT NOT NULL DEFAULT 'months', includes_json TEXT, starts_at INTEGER, ends_at INTEGER, is_active INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS memberships (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, tier_id INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'active',
  started_at INTEGER NOT NULL, current_period_end INTEGER NOT NULL, grace_until INTEGER, source TEXT, purchase_id INTEGER,
  created_at INTEGER NOT NULL, canceled_at INTEGER, renewal_reminded_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_memberships_user ON memberships(user_id, status);
CREATE TABLE IF NOT EXISTS membership_periods (id INTEGER PRIMARY KEY AUTOINCREMENT, membership_id INTEGER NOT NULL, start_at INTEGER NOT NULL, end_at INTEGER NOT NULL, price_cents INTEGER NOT NULL, purchase_id INTEGER, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS promo_codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, kind TEXT NOT NULL, value INTEGER NOT NULL, applies_to TEXT NOT NULL DEFAULT 'all',
  entity_id INTEGER, max_uses INTEGER, uses INTEGER NOT NULL DEFAULT 0, per_user_limit INTEGER NOT NULL DEFAULT 1, starts_at INTEGER, ends_at INTEGER,
  is_active INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS promo_redemptions (id INTEGER PRIMARY KEY AUTOINCREMENT, promo_id INTEGER NOT NULL, user_id INTEGER, purchase_id INTEGER, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS referrals (id INTEGER PRIMARY KEY AUTOINCREMENT, referrer_id INTEGER NOT NULL, referred_id INTEGER NOT NULL, reward_cents INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'pending', created_at INTEGER NOT NULL, rewarded_at INTEGER);
CREATE TABLE IF NOT EXISTS wallet_ledger (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, delta_cents INTEGER NOT NULL, balance_after INTEGER NOT NULL, reason TEXT, ref_type TEXT, ref_id TEXT, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS priority_applications (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, text TEXT, status TEXT NOT NULL DEFAULT 'pending', reviewer_note TEXT, reviewed_at INTEGER, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS segments (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, rules_json TEXT NOT NULL, is_dynamic INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS segment_members (segment_id INTEGER NOT NULL, user_id INTEGER NOT NULL, PRIMARY KEY(segment_id, user_id));

-- ------------------------------------------------------------------ purchases / payments
CREATE TABLE IF NOT EXISTS purchases (
  id INTEGER PRIMARY KEY AUTOINCREMENT, public_id TEXT UNIQUE NOT NULL, user_id INTEGER, guest_email TEXT,
  kind TEXT NOT NULL, entity_type TEXT, entity_id INTEGER, title TEXT NOT NULL, description TEXT,
  quantity INTEGER NOT NULL DEFAULT 1, unit_price_cents INTEGER NOT NULL DEFAULT 0, subtotal_cents INTEGER NOT NULL DEFAULT 0,
  discount_cents INTEGER NOT NULL DEFAULT 0, credit_used_cents INTEGER NOT NULL DEFAULT 0, total_cents INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD', status TEXT NOT NULL DEFAULT 'pending', audience TEXT, tier_rank_at INTEGER,
  promo_id INTEGER, meta_json TEXT, parts_total INTEGER NOT NULL DEFAULT 1, parts_paid INTEGER NOT NULL DEFAULT 0,
  paid_cents INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, paid_at INTEGER, expires_at INTEGER,
  fulfilled_at INTEGER, ip TEXT
);
CREATE INDEX IF NOT EXISTS idx_purchases_user ON purchases(user_id, id);
CREATE INDEX IF NOT EXISTS idx_purchases_status ON purchases(status);
CREATE INDEX IF NOT EXISTS idx_purchases_paid ON purchases(paid_at);
CREATE INDEX IF NOT EXISTS idx_purchases_kind ON purchases(kind);

CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_id INTEGER NOT NULL, part_no INTEGER NOT NULL, amount_cents INTEGER NOT NULL,
  order_ref TEXT UNIQUE NOT NULL, np_invoice_id TEXT, np_invoice_url TEXT, np_payment_id TEXT, np_status TEXT NOT NULL DEFAULT 'created',
  pay_currency TEXT, pay_amount TEXT, actually_paid TEXT, outcome_amount TEXT, outcome_currency TEXT, payin_hash TEXT,
  status TEXT NOT NULL DEFAULT 'pending', created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, paid_at INTEGER, expires_at INTEGER, raw_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_invoices_purchase ON invoices(purchase_id, part_no);
CREATE INDEX IF NOT EXISTS idx_invoices_np ON invoices(np_payment_id);

CREATE TABLE IF NOT EXISTS payment_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER, np_payment_id TEXT, np_invoice_id TEXT, status TEXT, source TEXT NOT NULL,
  sig_ok INTEGER, received_at INTEGER NOT NULL, raw_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_payevents_invoice ON payment_events(invoice_id);

CREATE TABLE IF NOT EXISTS contact_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, email TEXT, subject TEXT, body TEXT, amount_cents INTEGER, kind TEXT NOT NULL DEFAULT 'manual_payment',
  status TEXT NOT NULL DEFAULT 'new', admin_note TEXT, created_at INTEGER NOT NULL, updated_at INTEGER
);

-- ------------------------------------------------------------------ messaging
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT, thread_user_id INTEGER NOT NULL, sender_role TEXT NOT NULL, body TEXT, media_id INTEGER,
  is_voice INTEGER NOT NULL DEFAULT 0, price_cents INTEGER, is_locked INTEGER NOT NULL DEFAULT 0, unlocked_at INTEGER, purchase_id INTEGER,
  mass_id INTEGER, read_at INTEGER, reactions_json TEXT, priority INTEGER NOT NULL DEFAULT 0, scheduled_at INTEGER,
  created_at INTEGER NOT NULL, deleted_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_messages_thread ON messages(thread_user_id, id);
CREATE TABLE IF NOT EXISTS message_packs (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, count INTEGER NOT NULL, price_cents INTEGER NOT NULL, days_valid INTEGER NOT NULL DEFAULT 30, is_active INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS message_credits (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, remaining INTEGER NOT NULL, expires_at INTEGER, purchase_id INTEGER, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS mass_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, body_template TEXT NOT NULL, media_id INTEGER, price_cents INTEGER, segment_json TEXT,
  scheduled_at INTEGER, sent_at INTEGER, recipients INTEGER NOT NULL DEFAULT 0, opened INTEGER NOT NULL DEFAULT 0, unlocked INTEGER NOT NULL DEFAULT 0,
  variant TEXT, created_at INTEGER NOT NULL
);

-- ------------------------------------------------------------------ live
CREATE TABLE IF NOT EXISTS streams (
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT, access_mode TEXT NOT NULL DEFAULT 'members', min_tier_rank INTEGER NOT NULL DEFAULT 0,
  ticket_price_cents INTEGER, public_ticket_price_cents INTEGER, scheduled_at INTEGER, started_at INTEGER, ended_at INTEGER,
  status TEXT NOT NULL DEFAULT 'scheduled', embed_url TEXT, playback_url TEXT, stream_key_note TEXT, recording_media_id INTEGER,
  chat_enabled INTEGER NOT NULL DEFAULT 1, tip_goal_cents INTEGER, tips_total_cents INTEGER NOT NULL DEFAULT 0, milestones_json TEXT, offers_json TEXT,
  pinned_price_cents INTEGER, highlight_price_cents INTEGER, viewer_cap INTEGER, waiting_room INTEGER NOT NULL DEFAULT 1,
  channel_id INTEGER, series_id INTEGER, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS stream_chat (id INTEGER PRIMARY KEY AUTOINCREMENT, stream_id INTEGER NOT NULL, user_id INTEGER, body TEXT, kind TEXT NOT NULL DEFAULT 'chat', amount_cents INTEGER, pinned_until INTEGER, hidden INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_stream_chat ON stream_chat(stream_id, id);
CREATE TABLE IF NOT EXISTS stream_tickets (stream_id INTEGER NOT NULL, user_id INTEGER NOT NULL, purchase_id INTEGER, created_at INTEGER NOT NULL, PRIMARY KEY(stream_id, user_id));
CREATE TABLE IF NOT EXISTS stream_rsvps (stream_id INTEGER NOT NULL, user_id INTEGER NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY(stream_id, user_id));
CREATE TABLE IF NOT EXISTS stream_viewers (stream_id INTEGER NOT NULL, user_id INTEGER NOT NULL, joined_at INTEGER NOT NULL, last_seen_at INTEGER NOT NULL, PRIMARY KEY(stream_id, user_id));

-- ------------------------------------------------------------------ calls
CREATE TABLE IF NOT EXISTS call_slots (
  id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, start_at INTEGER NOT NULL, end_at INTEGER NOT NULL, duration_min INTEGER NOT NULL,
  price_cents INTEGER, per_minute_cents INTEGER, min_tier_rank INTEGER NOT NULL DEFAULT 0, priority_only INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open', buffer_min INTEGER NOT NULL DEFAULT 10, notes TEXT, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS call_bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT, slot_id INTEGER NOT NULL, user_id INTEGER NOT NULL, kind TEXT NOT NULL, purchase_id INTEGER,
  status TEXT NOT NULL DEFAULT 'pending_payment', join_url TEXT, record INTEGER NOT NULL DEFAULT 0, user_notes TEXT, admin_notes TEXT,
  reminders_json TEXT, recording_media_id INTEGER, created_at INTEGER NOT NULL, updated_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_call_bookings_user ON call_bookings(user_id);

-- ------------------------------------------------------------------ custom orders (marketplace)
CREATE TABLE IF NOT EXISTS custom_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT, public_id TEXT UNIQUE NOT NULL, user_id INTEGER NOT NULL, type TEXT NOT NULL DEFAULT 'custom', title TEXT NOT NULL,
  specs_json TEXT, brief TEXT, attachments_json TEXT, status TEXT NOT NULL DEFAULT 'pending', quote_cents INTEGER, counter_offer_cents INTEGER,
  deposit_pct INTEGER NOT NULL DEFAULT 50, deposit_purchase_id INTEGER, balance_purchase_id INTEGER, deadline_at INTEGER,
  delivery_media_json TEXT, delivery_note TEXT, delivered_at INTEGER, revisions_allowed INTEGER NOT NULL DEFAULT 1, revisions_used INTEGER NOT NULL DEFAULT 0,
  priority_level TEXT NOT NULL DEFAULT 'none', priority_purchase_id INTEGER, creator_notes TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS custom_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, sender_role TEXT NOT NULL, body TEXT NOT NULL, created_at INTEGER NOT NULL);

-- ------------------------------------------------------------------ tips / fundraising
CREATE TABLE IF NOT EXISTS tips (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, amount_cents INTEGER NOT NULL, purchase_id INTEGER, context_type TEXT, context_id INTEGER,
  message TEXT, anonymous INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tips_user ON tips(user_id);
CREATE TABLE IF NOT EXISTS campaigns (
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, slug TEXT UNIQUE, description TEXT, goal_cents INTEGER NOT NULL, raised_cents INTEGER NOT NULL DEFAULT 0,
  starts_at INTEGER, ends_at INTEGER, milestones_json TEXT, status TEXT NOT NULL DEFAULT 'active', donor_list_public INTEGER NOT NULL DEFAULT 1,
  reward_media_json TEXT, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS campaign_contributions (id INTEGER PRIMARY KEY AUTOINCREMENT, campaign_id INTEGER NOT NULL, user_id INTEGER, amount_cents INTEGER NOT NULL, purchase_id INTEGER, is_public INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);

-- ------------------------------------------------------------------ channels
CREATE TABLE IF NOT EXISTS channels (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, slug TEXT UNIQUE, description TEXT, kind TEXT NOT NULL DEFAULT 'tier', min_tier_rank INTEGER NOT NULL DEFAULT 0,
  entry_price_cents INTEGER, upgrade_price_cents INTEGER, expires_at INTEGER, member_cap INTEGER, is_active INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS channel_members (channel_id INTEGER NOT NULL, user_id INTEGER NOT NULL, role TEXT NOT NULL DEFAULT 'member', purchase_id INTEGER, joined_at INTEGER NOT NULL, PRIMARY KEY(channel_id, user_id));
CREATE TABLE IF NOT EXISTS channel_posts (id INTEGER PRIMARY KEY AUTOINCREMENT, channel_id INTEGER NOT NULL, body TEXT, media_id INTEGER, price_cents INTEGER, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS channel_chat (id INTEGER PRIMARY KEY AUTOINCREMENT, channel_id INTEGER NOT NULL, user_id INTEGER, body TEXT, media_id INTEGER, hidden INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_channel_chat ON channel_chat(channel_id, id);

-- ------------------------------------------------------------------ drops
CREATE TABLE IF NOT EXISTS drops (
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, slug TEXT UNIQUE, description TEXT, kind TEXT NOT NULL DEFAULT 'content', media_ids_json TEXT, product_id INTEGER,
  price_cents INTEGER NOT NULL, public_price_cents INTEGER, follower_price_cents INTEGER, quantity_cap INTEGER, sold INTEGER NOT NULL DEFAULT 0,
  starts_at INTEGER, ends_at INTEGER, early_access_hours INTEGER NOT NULL DEFAULT 24, min_tier_rank INTEGER NOT NULL DEFAULT 0,
  included_tier_ranks_json TEXT, status TEXT NOT NULL DEFAULT 'scheduled', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS drop_waitlist (drop_id INTEGER NOT NULL, user_id INTEGER NOT NULL, created_at INTEGER NOT NULL, notified_at INTEGER, PRIMARY KEY(drop_id, user_id));

-- ------------------------------------------------------------------ shop
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, slug TEXT UNIQUE, description TEXT, kind TEXT NOT NULL DEFAULT 'physical',
  price_cents INTEGER NOT NULL, public_price_cents INTEGER, follower_price_cents INTEGER, compare_at_cents INTEGER, media_ids_json TEXT, digital_media_id INTEGER,
  variants_json TEXT, inventory INTEGER, low_stock_at INTEGER NOT NULL DEFAULT 3, signed INTEGER NOT NULL DEFAULT 0, personalization INTEGER NOT NULL DEFAULT 0,
  coa INTEGER NOT NULL DEFAULT 0, weight_g INTEGER, shipping_class TEXT NOT NULL DEFAULT 'standard', tax_class TEXT NOT NULL DEFAULT 'standard',
  min_tier_rank INTEGER NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1, shopify_id TEXT, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS carts (id TEXT PRIMARY KEY, user_id INTEGER, items_json TEXT NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS shop_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT, public_id TEXT UNIQUE NOT NULL, purchase_id INTEGER, user_id INTEGER, email TEXT, items_json TEXT NOT NULL,
  subtotal_cents INTEGER NOT NULL, tax_cents INTEGER NOT NULL DEFAULT 0, shipping_cents INTEGER NOT NULL DEFAULT 0, total_cents INTEGER NOT NULL,
  shipping_json TEXT, status TEXT NOT NULL DEFAULT 'pending', carrier TEXT, tracking TEXT, coa_json TEXT, notes TEXT, created_at INTEGER NOT NULL, updated_at INTEGER
);
CREATE TABLE IF NOT EXISTS tax_rates (id INTEGER PRIMARY KEY AUTOINCREMENT, country TEXT NOT NULL, region TEXT, tax_class TEXT NOT NULL DEFAULT 'standard', rate_pct REAL NOT NULL, label TEXT);
CREATE TABLE IF NOT EXISTS shipping_rates (id INTEGER PRIMARY KEY AUTOINCREMENT, zone TEXT NOT NULL, countries_json TEXT, shipping_class TEXT NOT NULL DEFAULT 'standard', price_cents INTEGER NOT NULL, per_item_cents INTEGER NOT NULL DEFAULT 0, label TEXT);

-- ------------------------------------------------------------------ automation / calendar / misc
CREATE TABLE IF NOT EXISTS automation_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, name TEXT, tier_id INTEGER, delay_hours INTEGER NOT NULL DEFAULT 0, template TEXT, media_id INTEGER,
  conditions_json TEXT, is_active INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS automation_runs (id INTEGER PRIMARY KEY AUTOINCREMENT, rule_id INTEGER NOT NULL, user_id INTEGER NOT NULL, due_at INTEGER NOT NULL, run_at INTEGER, status TEXT NOT NULL DEFAULT 'queued', created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_auto_runs ON automation_runs(status, due_at);
CREATE TABLE IF NOT EXISTS calendar_events (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, ref_type TEXT, ref_id INTEGER, title TEXT NOT NULL, start_at INTEGER NOT NULL, end_at INTEGER, notes TEXT, is_public INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS link_hub (id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT NOT NULL, url TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0, clicks INTEGER NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS link_clicks (link_id INTEGER NOT NULL, user_id INTEGER, ts INTEGER NOT NULL, ip TEXT);
CREATE TABLE IF NOT EXISTS social_counters (id INTEGER PRIMARY KEY AUTOINCREMENT, platform TEXT NOT NULL, label TEXT, value TEXT, url TEXT, position INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS dmca_notices (id INTEGER PRIMARY KEY AUTOINCREMENT, reporter_name TEXT, email TEXT, urls TEXT, description TEXT, kind TEXT NOT NULL DEFAULT 'notice', status TEXT NOT NULL DEFAULT 'new', admin_note TEXT, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS leak_alerts (id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT, url TEXT, media_id INTEGER, fingerprint TEXT, status TEXT NOT NULL DEFAULT 'new', created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS kyc_checks (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, provider TEXT, status TEXT NOT NULL DEFAULT 'pending', reference TEXT, raw_json TEXT, created_at INTEGER NOT NULL, updated_at INTEGER);
CREATE TABLE IF NOT EXISTS moderation_flags (id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL, provider TEXT, scores_json TEXT, status TEXT NOT NULL DEFAULT 'review', created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS watermark_log (id INTEGER PRIMARY KEY AUTOINCREMENT, media_id INTEGER NOT NULL, user_id INTEGER, fingerprint TEXT NOT NULL, ts INTEGER NOT NULL, ip TEXT);
CREATE INDEX IF NOT EXISTS idx_wm_fp ON watermark_log(fingerprint);
CREATE TABLE IF NOT EXISTS ai_notes (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, note TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'summary', created_at INTEGER NOT NULL);

-- ------------------------------------------------------------------ request system (USD 1M minimum)
CREATE TABLE IF NOT EXISTS rq_terms (user_id INTEGER NOT NULL, version TEXT NOT NULL, accepted_at INTEGER NOT NULL, ip TEXT, PRIMARY KEY(user_id, version));
CREATE TABLE IF NOT EXISTS rq_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, status TEXT NOT NULL, started_at INTEGER NOT NULL, activated_at INTEGER, expires_at INTEGER,
  activation_order_id INTEGER, ended_at INTEGER, ended_reason TEXT
);
CREATE INDEX IF NOT EXISTS idx_rq_sessions_user ON rq_sessions(user_id, id);
CREATE TABLE IF NOT EXISTS rq_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT, public_id TEXT UNIQUE NOT NULL, user_id INTEGER NOT NULL, session_id INTEGER,
  offer_key TEXT NOT NULL, offer_name TEXT NOT NULL, category TEXT NOT NULL, kind TEXT NOT NULL, units INTEGER NOT NULL, unit_label TEXT NOT NULL,
  priority TEXT NOT NULL DEFAULT 'none', quote_json TEXT NOT NULL, total_cents INTEGER NOT NULL, status TEXT NOT NULL, admin_status TEXT NOT NULL DEFAULT 'new',
  purchase_id INTEGER, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, paid_at INTEGER, expires_at INTEGER,
  details_status TEXT NOT NULL DEFAULT 'none', details_count INTEGER NOT NULL DEFAULT 0, attached_to TEXT, admin_note TEXT, invoice_no TEXT
);
CREATE INDEX IF NOT EXISTS idx_rq_orders_user ON rq_orders(user_id, id);
CREATE INDEX IF NOT EXISTS idx_rq_orders_status ON rq_orders(status);
CREATE TABLE IF NOT EXISTS rq_details (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, user_id INTEGER NOT NULL, kind TEXT NOT NULL, text TEXT, media_id INTEGER, created_at INTEGER NOT NULL);
"""

EXPORT_TABLES = (
    "users", "sessions", "audit_log", "settings", "counters", "notifications", "media", "download_tokens", "collections", "posts",
    "post_media", "polls", "poll_votes", "post_likes", "post_reactions", "comments", "post_views", "unlocks", "tiers", "bundles",
    "memberships", "membership_periods", "promo_codes", "promo_redemptions", "referrals", "wallet_ledger", "priority_applications",
    "segments", "segment_members", "purchases", "invoices", "payment_events", "contact_requests", "messages", "message_packs",
    "message_credits", "mass_messages", "streams", "stream_chat", "stream_tickets", "stream_rsvps", "stream_viewers", "call_slots",
    "call_bookings", "custom_orders", "custom_messages", "tips", "campaigns", "campaign_contributions", "channels", "channel_members",
    "channel_posts", "channel_chat", "drops", "drop_waitlist", "products", "carts", "shop_orders", "tax_rates", "shipping_rates",
    "automation_rules", "automation_runs", "calendar_events", "link_hub", "link_clicks", "social_counters", "dmca_notices",
    "leak_alerts", "kyc_checks", "moderation_flags", "watermark_log", "ai_notes", "rq_terms", "rq_sessions", "rq_orders", "rq_details",
)


class Database:
    def __init__(self, path: str):
        self.path = path
        if path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self._columns_cache: dict[str, list[str]] = {}

    # --------------------------------------------------------------- basics
    def execute(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Cursor:
        with self._lock:
            return self.conn.execute(sql, tuple(params))

    def executemany(self, sql: str, rows: Iterable[Iterable[Any]]) -> None:
        with self._lock:
            self.conn.executemany(sql, [tuple(r) for r in rows])

    def one(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
        return self.execute(sql, params).fetchone()

    def all(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        return self.execute(sql, params).fetchall()

    def scalar(self, sql: str, params: Iterable[Any] = (), default: Any = 0) -> Any:
        row = self.one(sql, params)
        return default if row is None or row[0] is None else row[0]

    def transaction(self):
        return _Tx(self)

    def close(self) -> None:
        with self._lock:
            self.conn.close()

    def columns(self, table: str) -> list[str]:
        if table not in self._columns_cache:
            self._columns_cache[table] = [r[1] for r in self.all(f"PRAGMA table_info({table})")]
        return self._columns_cache[table]

    # --------------------------------------------------------------- CRUD
    def insert(self, table: str, **fields: Any) -> int:
        cols = list(fields)
        sql = f"INSERT INTO {table}({','.join(cols)}) VALUES ({','.join('?' for _ in cols)})"
        cur = self.execute(sql, [fields[c] for c in cols])
        return int(cur.lastrowid)

    def update(self, table: str, row_id: Any, id_col: str = "id", **fields: Any) -> None:
        if not fields:
            return
        sql = f"UPDATE {table} SET {', '.join(f'{k}=?' for k in fields)} WHERE {id_col}=?"
        self.execute(sql, [*fields.values(), row_id])

    def get(self, table: str, row_id: Any, id_col: str = "id") -> sqlite3.Row | None:
        return self.one(f"SELECT * FROM {table} WHERE {id_col}=?", (row_id,))

    def delete(self, table: str, row_id: Any, id_col: str = "id") -> None:
        self.execute(f"DELETE FROM {table} WHERE {id_col}=?", (row_id,))

    def count(self, table: str, where: str = "1=1", params: Iterable[Any] = ()) -> int:
        return int(self.scalar(f"SELECT COUNT(*) FROM {table} WHERE {where}", params))

    # --------------------------------------------------------------- helpers
    def next_counter(self, name: str) -> int:
        with self._lock:
            self.execute("INSERT INTO counters(name, value) VALUES (?, 0) ON CONFLICT(name) DO NOTHING", (name,))
            self.execute("UPDATE counters SET value=value+1 WHERE name=?", (name,))
            return int(self.scalar("SELECT value FROM counters WHERE name=?", (name,)))

    def public_id(self, prefix: str, year: int) -> str:
        n = self.next_counter(f"{prefix}_{year}")
        return f"{prefix}-{year}-{n:06d}"

    def audit(self, action: str, actor_user_id: int | None = None, actor_role: str = "system", entity_type: str | None = None,
              entity_id: Any = None, ip: str | None = None, data: dict | None = None) -> int:
        return self.insert("audit_log", ts=now_ts(), actor_user_id=actor_user_id, actor_role=actor_role, action=action,
                           entity_type=entity_type, entity_id=str(entity_id) if entity_id is not None else None, ip=ip,
                           data_json=json.dumps(data or {}, default=str))

    def notify(self, user_id: int, kind: str, title: str, body: str = "", url: str = "") -> int:
        return self.insert("notifications", user_id=user_id, kind=kind, title=title, body=body, url=url, created_at=now_ts())

    def all_settings(self) -> dict[str, Any]:
        return {r["key"]: json.loads(r["value_json"]) for r in self.all("SELECT key, value_json FROM settings")}

    def set_setting(self, key: str, value: Any, actor: int | None = None) -> None:
        self.execute("INSERT INTO settings(key, value_json, updated_at, updated_by) VALUES (?,?,?,?)"
                     " ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json, updated_at=excluded.updated_at, updated_by=excluded.updated_by",
                     (key, json.dumps(value), now_ts(), actor))

    def delete_setting(self, key: str) -> None:
        self.execute("DELETE FROM settings WHERE key=?", (key,))

    def hit_rate_limit(self, key: str, per_minute: int) -> bool:
        ts = now_ts()
        window = ts - ts % 60
        with self._lock:
            row = self.one("SELECT window_start, count FROM rate_limit WHERE key=?", (key,))
            if row is None or row["window_start"] != window:
                self.execute("INSERT INTO rate_limit(key, window_start, count) VALUES (?,?,1)"
                             " ON CONFLICT(key) DO UPDATE SET window_start=excluded.window_start, count=1", (key, window))
                return False
            self.execute("UPDATE rate_limit SET count=count+1 WHERE key=?", (key,))
            return row["count"] + 1 > per_minute

    def wallet_apply(self, user_id: int, delta_cents: int, reason: str, ref_type: str = "", ref_id: Any = "") -> int:
        with self._lock:
            bal = int(self.scalar("SELECT wallet_cents FROM users WHERE id=?", (user_id,)))
            new_bal = bal + delta_cents
            if new_bal < 0:
                raise ValueError("Insufficient credit")
            self.execute("UPDATE users SET wallet_cents=? WHERE id=?", (new_bal, user_id))
            self.insert("wallet_ledger", user_id=user_id, delta_cents=delta_cents, balance_after=new_bal, reason=reason,
                        ref_type=ref_type, ref_id=str(ref_id), created_at=now_ts())
            return new_bal

    # --------------------------------------------------------------- export / backup
    def backup_to(self, path: str) -> None:
        with self._lock:
            if os.path.exists(path):
                os.remove(path)
            self.conn.execute("VACUUM INTO ?", (path,))

    def export_csv(self, table: str) -> str:
        if table not in EXPORT_TABLES:
            raise ValueError(table)
        rows = self.all(f"SELECT * FROM {table}")
        buf = io.StringIO()
        if not rows:
            csv.writer(buf).writerow(self.columns(table))
            return buf.getvalue()
        w = csv.DictWriter(buf, fieldnames=rows[0].keys())
        w.writeheader()
        for r in rows:
            w.writerow(dict(r))
        return buf.getvalue()

    def export_json(self) -> str:
        data = {t: [dict(r) for r in self.all(f"SELECT * FROM {t}")] for t in EXPORT_TABLES}
        return json.dumps({"exported_at": now_ts(), "tables": data}, ensure_ascii=False, default=str)

    def is_empty(self) -> bool:
        return self.count("users") == 0

    @staticmethod
    def new_token() -> str:
        return token_hex(32)


class _Tx:
    def __init__(self, db: Database):
        self.db = db

    def __enter__(self):
        self.db._lock.acquire()
        self.db.conn.execute("BEGIN IMMEDIATE")
        return self.db

    def __exit__(self, exc_type, exc, tb):
        try:
            if exc_type is None:
                self.db.conn.execute("COMMIT")
            else:
                self.db.conn.execute("ROLLBACK")
        finally:
            self.db._lock.release()
        return False
