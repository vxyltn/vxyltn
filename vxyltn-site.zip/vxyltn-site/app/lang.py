"""English (US) only gate for free text (request details, messages, custom briefs).

Heuristic: non-Latin script -> reject; Latin text with language-specific letters or
common non-English function words and no English function words -> reject.
Numbers, IDs, emoji, punctuation and URLs pass.
"""
from __future__ import annotations

import re
import unicodedata

_SPECIFIC = set("ğışİşÄäÖöÜüßçÇñÑåÅæÆøØ")
_NON_ENGLISH = {
    "merhaba", "selam", "nasılsın", "nasilsin", "teşekkür", "tesekkur", "lütfen", "lutfen", "evet", "hayır", "hayir", "istiyorum", "için", "icin",
    "değil", "degil", "nerede", "neden", "tamam", "ödeme", "odeme", "hola", "gracias", "por", "favor", "quiero", "necesito", "cuánto", "cuanto",
    "dónde", "donde", "buenos", "días", "hallo", "danke", "bitte", "ich", "nicht", "möchte", "wieviel", "kannst", "bonjour", "merci", "vous",
    "plaît", "voudrais", "combien", "pourquoi", "ciao", "grazie", "vorrei", "quanto", "olá", "obrigado", "obrigada", "preciso", "quero",
    "privet", "spasibo", "pozhaluysta", "skolko", "halo", "terima", "kasih", "saya", "mau", "berapa",
}
_ENGLISH = {
    "the", "a", "an", "and", "or", "to", "of", "in", "on", "for", "i", "you", "is", "are", "it", "this", "that", "with", "my", "me", "please",
    "want", "need", "how", "what", "when", "where", "can", "hello", "hi", "hey", "thanks", "thank", "yes", "no", "ok", "okay", "request",
    "order", "pay", "payment", "call", "video", "photo", "text", "audio", "message", "minutes", "minute", "month", "months", "time", "date",
    "at", "am", "pm", "utc", "done", "skip", "cancel", "send", "sent", "from", "by", "about", "would", "like", "as", "be", "have", "will",
}
_WORD = re.compile(r"[^\W\d_]+", re.UNICODE)
_URL = re.compile(r"https?://\S+|\b[\w.-]+\.(com|net|org|io|me|co)\b", re.IGNORECASE)


def _latin(ch: str) -> bool:
    try:
        return "LATIN" in unicodedata.name(ch)
    except ValueError:
        return False


def is_english(text: str | None) -> bool:
    if not text:
        return True
    text = _URL.sub(" ", text)
    letters = [ch for ch in text if ch.isalpha()]
    if not letters:
        return True
    non_latin = sum(1 for ch in letters if not _latin(ch))
    if non_latin and (non_latin >= 2 or non_latin / len(letters) > 0.2):
        return False
    words = [w.lower() for w in _WORD.findall(text)]
    if not words:
        return True
    specific = sum(1 for ch in letters if ch in _SPECIFIC)
    foreign = sum(1 for w in words if w in _NON_ENGLISH)
    english = sum(1 for w in words if w in _ENGLISH)
    if english > 0 and english >= foreign:
        return True
    if foreign >= 1 and english == 0:
        return False
    if specific >= 2 and english == 0:
        return False
    return True
