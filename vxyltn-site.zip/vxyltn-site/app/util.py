"""Small shared helpers."""
from __future__ import annotations

import hashlib
import html
import json
import re
import secrets
import time
import unicodedata
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

UTC = timezone.utc


def now_ts() -> int:
    return int(time.time())


def token_hex(n: int = 32) -> str:
    return secrets.token_hex(n)


def token_urlsafe(n: int = 32) -> str:
    return secrets.token_urlsafe(n)


def sha256(data: bytes | str) -> str:
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def ts_to_dt(ts) -> datetime | None:
    if ts is None:
        return None
    return datetime.fromtimestamp(float(ts), UTC)


def fmt_local(ts, tz: ZoneInfo, with_tz: bool = True, fmt: str = "%Y-%m-%d %H:%M") -> str:
    dt = ts_to_dt(ts)
    if dt is None:
        return "-"
    local = dt.astimezone(tz)
    out = local.strftime(fmt)
    return f"{out} {local.tzname()}" if with_tz else out


def fmt_utc(ts) -> str:
    dt = ts_to_dt(ts)
    return "-" if dt is None else dt.strftime("%Y-%m-%d %H:%M:%S UTC")


def fmt_date(ts, tz: ZoneInfo) -> str:
    dt = ts_to_dt(ts)
    return "-" if dt is None else dt.astimezone(tz).strftime("%Y-%m-%d")


def local_day_bounds(tz: ZoneInfo, days_ago: int = 0) -> tuple[int, int]:
    now_local = datetime.now(tz)
    day = (now_local - timedelta(days=days_ago)).date()
    start = datetime(day.year, day.month, day.day, tzinfo=tz)
    return int(start.timestamp()), int((start + timedelta(days=1)).timestamp())


def parse_dt_local(value: str | None, tz: ZoneInfo) -> int | None:
    """Parse 'YYYY-MM-DDTHH:MM' or 'YYYY-MM-DD HH:MM' or 'YYYY-MM-DD' in local tz -> unix ts."""
    if not value:
        return None
    value = value.strip().replace("T", " ")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(value, fmt)
            return int(dt.replace(tzinfo=tz).timestamp())
        except ValueError:
            continue
    return None


def dt_input_value(ts, tz: ZoneInfo) -> str:
    dt = ts_to_dt(ts)
    return "" if dt is None else dt.astimezone(tz).strftime("%Y-%m-%dT%H:%M")


def esc(s: object) -> str:
    return html.escape("" if s is None else str(s), quote=True)


def slugify(text: str, max_len: int = 60) -> str:
    text = unicodedata.normalize("NFKD", text or "").encode("ascii", "ignore").decode("ascii").lower()
    text = re.sub(r"[^a-z0-9]+", "-", text).strip("-")
    return text[:max_len] or token_hex(4)


def parse_int(text: str | None) -> int | None:
    if text is None:
        return None
    t = str(text).strip().replace(",", "").replace(" ", "").replace("_", "")
    if not t.lstrip("-").isdigit():
        return None
    try:
        return int(t)
    except ValueError:
        return None


def parse_money_cents(text: str | None) -> int | None:
    """'1,000,000' or '12.50' or '$5' -> cents."""
    if text is None:
        return None
    t = str(text).strip().replace(",", "").replace("$", "").replace(" ", "").replace("_", "")
    if not t:
        return None
    try:
        from decimal import Decimal, ROUND_HALF_UP
        return int((Decimal(t) * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    except Exception:
        return None


def dumps(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, default=str, sort_keys=True)


def loads(raw, default=None):
    if raw in (None, ""):
        return default if default is not None else {}
    try:
        return json.loads(raw)
    except (TypeError, ValueError):
        return default if default is not None else {}


def chunk(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def pct(a, b) -> str:
    return "0%" if not b else f"{100.0 * a / b:.1f}%"


def client_ip(request, trusted_proxy: bool) -> str:
    if trusted_proxy:
        for header in ("cf-connecting-ip", "x-real-ip", "x-forwarded-for"):
            v = request.headers.get(header)
            if v:
                return v.split(",")[0].strip()
    return request.client.host if request.client else "0.0.0.0"


def country_of(request) -> str | None:
    for header in ("cf-ipcountry", "x-country-code", "cloudfront-viewer-country"):
        v = request.headers.get(header)
        if v and len(v) == 2:
            return v.upper()
    return None


EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def valid_email(s: str | None) -> bool:
    return bool(s and EMAIL_RE.match(s.strip()) and len(s) <= 254)


def mask_email(s: str | None) -> str:
    if not s or "@" not in s:
        return "-"
    name, dom = s.split("@", 1)
    return f"{name[:2]}***@{dom}"
