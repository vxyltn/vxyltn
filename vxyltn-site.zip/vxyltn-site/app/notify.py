"""Admin notifications: in-app (admin inbox), optional Telegram (Bot API over HTTPS, no library).

Telegram is optional and only used as a notification/mirror channel:
  TELEGRAM_BOT_TOKEN + TELEGRAM_ADMIN_CHAT_ID  -> paid requests, PDFs, alerts
  TELEGRAM_DATA_CHAT_ID                        -> JSON mirror of records + daily backups
"""
from __future__ import annotations

import logging

import httpx

from .config import Config
from .util import dumps

log = logging.getLogger(__name__)


class Notifier:
    def __init__(self, cfg: Config, db):
        self.cfg = cfg
        self.db = db
        self._client: httpx.AsyncClient | None = None

    @property
    def tg_enabled(self) -> bool:
        return bool(self.cfg.tg_bot_token and self.cfg.tg_admin_chat_id)

    async def _tg(self, method: str, data: dict | None = None, files: dict | None = None) -> dict | None:
        if not self.cfg.tg_bot_token:
            return None
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60)
        url = f"https://api.telegram.org/bot{self.cfg.tg_bot_token}/{method}"
        try:
            resp = await self._client.post(url, data=data, files=files)
            out = resp.json()
            if not out.get("ok"):
                log.warning("telegram %s failed: %s", method, out)
            return out
        except Exception as exc:  # pragma: no cover - network
            log.warning("telegram %s error: %s", method, exc)
            return None

    async def admin(self, text: str, document: tuple[bytes, str] | None = None) -> None:
        """Notify the admin: in-app notification for all admins + Telegram if configured."""
        for row in self.db.all("SELECT id FROM users WHERE role='admin'"):
            self.db.notify(row["id"], "admin", text[:200], text[:2000], "/admin")
        if not self.tg_enabled:
            return
        if document:
            blob, name = document
            await self._tg("sendDocument", data={"chat_id": self.cfg.tg_admin_chat_id, "caption": text[:1000], "parse_mode": "HTML"},
                           files={"document": (name, blob)})
        else:
            await self._tg("sendMessage", data={"chat_id": self.cfg.tg_admin_chat_id, "text": text[:4000], "parse_mode": "HTML",
                                                "disable_web_page_preview": "true"})

    async def mirror(self, record_type: str, record_id: str, title: str, data: dict, document: tuple[bytes, str] | None = None) -> None:
        if not (self.cfg.tg_bot_token and self.cfg.tg_data_chat_id):
            return
        tags = f"#{record_type} #{str(record_id).replace('-', '_')}"
        payload = dumps(data)
        if document is None and len(payload) <= 3000:
            text = f"{tags}\n<b>{_esc(title)}</b>\n<pre>{_esc(payload)}</pre>"
            await self._tg("sendMessage", data={"chat_id": self.cfg.tg_data_chat_id, "text": text, "parse_mode": "HTML", "disable_notification": "true"})
        else:
            blob, name = document or (payload.encode("utf-8"), f"{record_type}_{record_id}.json")
            await self._tg("sendDocument", data={"chat_id": self.cfg.tg_data_chat_id, "caption": f"{tags}\n{title}"[:1000], "disable_notification": "true"},
                           files={"document": (name, blob)})

    async def backup_document(self, blob: bytes, name: str, caption: str) -> None:
        chat = self.cfg.tg_data_chat_id or self.cfg.tg_admin_chat_id
        if not (self.cfg.tg_bot_token and chat):
            return
        out = await self._tg("sendDocument", data={"chat_id": chat, "caption": caption[:1000], "disable_notification": "true"},
                             files={"document": (name, blob)})
        if out and out.get("ok") and name.endswith(".sqlite3"):
            msg_id = out["result"]["message_id"]
            await self._tg("pinChatMessage", data={"chat_id": chat, "message_id": msg_id, "disable_notification": "true"})

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()


def _esc(s: object) -> str:
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def user_notify(db, user_id: int, kind: str, title: str, body: str = "", url: str = "") -> None:
    db.notify(user_id, kind, title, body, url)
