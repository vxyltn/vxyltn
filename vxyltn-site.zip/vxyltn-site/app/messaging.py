"""Direct messages (user <-> VXYLTN), paid messaging, PPV messages, message packs, mass messages, SSE feeds."""
from __future__ import annotations

import asyncio
import json
import sqlite3
from collections import defaultdict

from .members import render_template, segment_user_ids
from .money import usd
from .util import loads, now_ts

# in-process pub/sub for SSE (single instance deployment)
_subscribers: dict[str, set[asyncio.Queue]] = defaultdict(set)


def publish(channel: str, event: dict) -> None:
    for q in list(_subscribers.get(channel, ())):
        try:
            q.put_nowait(event)
        except asyncio.QueueFull:
            pass


async def subscribe(channel: str):
    q: asyncio.Queue = asyncio.Queue(maxsize=100)
    _subscribers[channel].add(q)
    try:
        while True:
            try:
                event = await asyncio.wait_for(q.get(), timeout=25)
                yield f"event: {event.get('type', 'message')}\ndata: {json.dumps(event, default=str)}\n\n"
            except asyncio.TimeoutError:
                yield ": keepalive\n\n"
    finally:
        _subscribers[channel].discard(q)


# ----------------------------------------------------------------- threads
def thread(db, user_id: int, limit: int = 100, before_id: int | None = None) -> list[sqlite3.Row]:
    where, params = ["m.thread_user_id=?", "m.deleted_at IS NULL", "(m.scheduled_at IS NULL OR m.scheduled_at<=?)"], [user_id, now_ts()]
    if before_id:
        where.append("m.id<?"); params.append(before_id)
    params.append(limit)
    rows = db.all(f"SELECT m.*, md.kind AS media_kind, md.filename FROM messages m LEFT JOIN media md ON md.id=m.media_id WHERE {' AND '.join(where)} ORDER BY m.id DESC LIMIT ?", params)
    return list(reversed(rows))


def inbox(db, limit: int = 50, offset: int = 0, unread_only: bool = False) -> list[sqlite3.Row]:
    having = "HAVING unread>0" if unread_only else ""
    return db.all(
        "SELECT u.id AS user_id, u.username, u.display_name, u.email, u.priority_status, u.total_spent_cents,"
        " MAX(m.id) AS last_id, MAX(m.created_at) AS last_at,"
        " SUM(CASE WHEN m.sender_role='user' AND m.read_at IS NULL THEN 1 ELSE 0 END) AS unread,"
        " SUM(CASE WHEN m.priority=1 AND m.sender_role='user' AND m.read_at IS NULL THEN 1 ELSE 0 END) AS priority_unread"
        f" FROM messages m JOIN users u ON u.id=m.thread_user_id WHERE m.deleted_at IS NULL GROUP BY u.id {having}"
        " ORDER BY priority_unread DESC, unread DESC, last_id DESC LIMIT ? OFFSET ?", (limit, offset))


def mark_read(db, user_id: int, by_role: str) -> None:
    other = "user" if by_role == "creator" else "creator"
    db.execute("UPDATE messages SET read_at=? WHERE thread_user_id=? AND sender_role=? AND read_at IS NULL", (now_ts(), user_id, other))


def send(db, user_id: int, sender_role: str, body: str | None, media_id: int | None = None, is_voice: bool = False,
         price_cents: int | None = None, priority: bool = False, purchase_id: int | None = None, mass_id: int | None = None,
         scheduled_at: int | None = None) -> int:
    ts = now_ts()
    locked = 1 if (sender_role == "creator" and price_cents) else 0
    mid = db.insert("messages", thread_user_id=user_id, sender_role=sender_role, body=(body or "")[:8000], media_id=media_id,
                    is_voice=1 if is_voice else 0, price_cents=price_cents, is_locked=locked, purchase_id=purchase_id, mass_id=mass_id,
                    priority=1 if priority else 0, scheduled_at=scheduled_at, created_at=ts)
    if sender_role == "creator":
        db.notify(user_id, "message", "New message", (body or "Media")[:120], "/messages")
    publish(f"dm:{user_id}", {"type": "message", "id": mid, "sender_role": sender_role})
    publish("admin:inbox", {"type": "message", "user_id": user_id, "id": mid})
    return mid


def consume_message_credit(db, user_id: int) -> bool:
    row = db.one("SELECT * FROM message_credits WHERE user_id=? AND remaining>0 AND (expires_at IS NULL OR expires_at>?) ORDER BY expires_at LIMIT 1", (user_id, now_ts()))
    if row is None:
        return False
    db.execute("UPDATE message_credits SET remaining=remaining-1 WHERE id=?", (row["id"],))
    return True


def credits_remaining(db, user_id: int) -> int:
    return int(db.scalar("SELECT COALESCE(SUM(remaining),0) FROM message_credits WHERE user_id=? AND (expires_at IS NULL OR expires_at>?)", (user_id, now_ts())))


def react(db, message_id: int, user_id: int, emoji: str) -> None:
    m = db.get("messages", message_id)
    if m is None or m["thread_user_id"] != user_id:
        return
    reactions = loads(m["reactions_json"], {})
    reactions[str(user_id)] = emoji
    db.update("messages", message_id, reactions_json=json.dumps(reactions))


def unlock_message(db, message_id: int, purchase_id: int | None) -> None:
    db.update("messages", message_id, is_locked=0, unlocked_at=now_ts(), purchase_id=purchase_id)
    m = db.get("messages", message_id)
    if m and m["mass_id"]:
        db.execute("UPDATE mass_messages SET unlocked=unlocked+1 WHERE id=?", (m["mass_id"],))


# ----------------------------------------------------------------- mass messaging
def send_mass(db, mass_id: int) -> int:
    mm = db.get("mass_messages", mass_id)
    if mm is None or mm["sent_at"]:
        return 0
    rules = loads(mm["segment_json"], {})
    user_ids = segment_user_ids(db, rules)
    n = 0
    for uid in user_ids:
        user = db.get("users", uid)
        body = render_template(mm["body_template"], user)
        send(db, uid, "creator", body, media_id=mm["media_id"], price_cents=mm["price_cents"], mass_id=mass_id)
        n += 1
    db.update("mass_messages", mass_id, sent_at=now_ts(), recipients=n)
    return n


def due_mass_messages(db) -> int:
    n = 0
    for mm in db.all("SELECT * FROM mass_messages WHERE sent_at IS NULL AND scheduled_at IS NOT NULL AND scheduled_at<=?", (now_ts(),)):
        n += send_mass(db, mm["id"])
    return n


def thread_summary(db, user_id: int) -> dict:
    return {
        "count": db.count("messages", "thread_user_id=? AND deleted_at IS NULL", (user_id,)),
        "spent_cents": int(db.scalar("SELECT COALESCE(SUM(total_cents),0) FROM purchases WHERE user_id=? AND status='paid' AND kind IN ('dm','message_unlock','message_pack','priority_dm','public_question')", (user_id,))),
        "credits": credits_remaining(db, user_id),
    }


def describe_price(cents: int) -> str:
    return "included" if cents == 0 else usd(cents)
