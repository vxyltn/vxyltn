"""Media pipeline: uploads, EXIF strip, thumbnails, blurred locked previews, per-viewer watermarks,
video posters (ffmpeg when available), download tokens, vault export.

Files live under ``uploads_dir/<yy>/<mm>/<sha-prefix>/<name>`` and are never served
statically; every delivery goes through an access-checked route.
"""
from __future__ import annotations

import asyncio
import hashlib
import io
import json
import mimetypes
import os
import shutil
import subprocess
import zipfile
from datetime import datetime, timezone

from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps, PngImagePlugin

from .config import Config
from .util import now_ts, token_urlsafe

IMAGE_MIMES = {"image/jpeg", "image/png", "image/webp", "image/gif"}
VIDEO_MIMES = {"video/mp4", "video/quicktime", "video/webm", "video/x-matroska"}
AUDIO_MIMES = {"audio/mpeg", "audio/mp4", "audio/x-m4a", "audio/ogg", "audio/wav", "audio/x-wav", "audio/webm", "audio/aac"}
DOC_MIMES = {"application/pdf", "text/plain", "application/zip"}
THUMB_SIZE = (640, 640)
BLUR_SIZE = (480, 480)


def kind_for(mime: str | None, filename: str | None) -> str:
    mime = (mime or "").lower()
    if not mime or mime == "application/octet-stream":
        guess, _ = mimetypes.guess_type(filename or "")
        mime = (guess or "").lower()
    if mime in IMAGE_MIMES or mime.startswith("image/"):
        return "image"
    if mime in VIDEO_MIMES or mime.startswith("video/"):
        return "video"
    if mime in AUDIO_MIMES or mime.startswith("audio/"):
        return "audio"
    if mime == "application/pdf":
        return "document"
    return "other"


class MediaStore:
    def __init__(self, cfg: Config, db):
        self.cfg = cfg
        self.db = db
        os.makedirs(cfg.uploads_dir, exist_ok=True)

    # ------------------------------------------------------------ paths
    def abs_path(self, rel: str) -> str:
        return os.path.join(self.cfg.uploads_dir, rel)

    def _dest(self, digest: str, filename: str) -> str:
        now = datetime.now(timezone.utc)
        safe = "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in (filename or "file"))[:80] or "file"
        rel_dir = os.path.join(now.strftime("%y"), now.strftime("%m"), digest[:12])
        os.makedirs(self.abs_path(rel_dir), exist_ok=True)
        return os.path.join(rel_dir, safe)

    # ------------------------------------------------------------ ingest
    async def save_upload(self, upload, owner_user_id: int | None, folder: str | None = None, title: str | None = None,
                          caption: str | None = None, tags: list[str] | None = None, source: str = "upload",
                          max_bytes: int | None = None) -> int:
        """Stream an UploadFile to disk, hash it, strip EXIF for images, build derivatives. Returns media id."""
        max_bytes = max_bytes or self.cfg.max_upload_mb * 1024 * 1024
        hasher = hashlib.sha256()
        tmp_rel = os.path.join("tmp", token_urlsafe(12))
        tmp_abs = self.abs_path(tmp_rel)
        os.makedirs(os.path.dirname(tmp_abs), exist_ok=True)
        size = 0
        with open(tmp_abs, "wb") as fh:
            while True:
                chunk = await upload.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > max_bytes:
                    fh.close()
                    os.remove(tmp_abs)
                    raise ValueError("File too large")
                hasher.update(chunk)
                fh.write(chunk)
        digest = hasher.hexdigest()
        try:
            await upload.close()
        except Exception:  # pragma: no cover
            pass
        filename = upload.filename or "file"
        mime = upload.content_type or mimetypes.guess_type(filename)[0] or "application/octet-stream"
        kind = kind_for(mime, filename)
        rel = self._dest(digest, filename)
        shutil.move(tmp_abs, self.abs_path(rel))
        return await asyncio.to_thread(self._finish_ingest, rel, filename, mime, kind, size, digest, owner_user_id,
                                       folder, title, caption, tags, source)

    def ingest_bytes(self, data: bytes, filename: str, mime: str, owner_user_id: int | None, folder: str | None = None,
                     title: str | None = None, source: str = "generated") -> int:
        digest = hashlib.sha256(data).hexdigest()
        rel = self._dest(digest, filename)
        with open(self.abs_path(rel), "wb") as fh:
            fh.write(data)
        return self._finish_ingest(rel, filename, mime, kind_for(mime, filename), len(data), digest, owner_user_id,
                                   folder, title, None, None, source)

    def _finish_ingest(self, rel, filename, mime, kind, size, digest, owner_user_id, folder, title, caption, tags, source) -> int:
        width = height = None
        duration = None
        thumb_rel = blur_rel = poster_rel = None
        exif_stripped = 0
        abs_path = self.abs_path(rel)
        if kind == "image":
            try:
                with Image.open(abs_path) as im:
                    im = ImageOps.exif_transpose(im)
                    width, height = im.size
                    fmt = im.format or "PNG"
                    # Strip metadata by re-saving pixels only (keeps GIF animation untouched).
                    if fmt in ("JPEG", "PNG", "WEBP"):
                        clean = Image.new(im.mode, im.size)
                        clean.putdata(list(im.getdata())) if im.mode in ("P",) else clean.paste(im)
                        save_kwargs = {"quality": 92} if fmt == "JPEG" else {}
                        clean.save(abs_path, fmt, **save_kwargs)
                        exif_stripped = 1
                    thumb_rel, blur_rel = self._derivatives(abs_path, rel, im)
            except Exception:
                kind = "other"
        elif kind == "video":
            poster_rel, duration, width, height = self._video_poster(abs_path, rel)
            if poster_rel:
                try:
                    with Image.open(self.abs_path(poster_rel)) as im:
                        thumb_rel, blur_rel = self._derivatives(self.abs_path(poster_rel), poster_rel, im)
                except Exception:
                    pass
        media_id = self.db.insert(
            "media", owner_user_id=owner_user_id, kind=kind, filename=filename, path=rel, mime=mime, size=size,
            width=width, height=height, duration=duration, sha256=digest, thumb_path=thumb_rel, blur_path=blur_rel,
            poster_path=poster_rel, tags_json=json.dumps(tags or []), folder=folder, title=title or filename, caption=caption,
            exif_stripped=exif_stripped, source=source, created_at=now_ts(),
        )
        self.db.execute("INSERT INTO media_fts(rowid, title, caption, tags, filename) VALUES (?,?,?,?,?)",
                        (media_id, title or filename, caption or "", " ".join(tags or []), filename))
        return media_id

    def _derivatives(self, abs_path: str, rel: str, im: Image.Image) -> tuple[str, str]:
        base, _ = os.path.splitext(rel)
        thumb_rel = f"{base}.thumb.jpg"
        blur_rel = f"{base}.blur.jpg"
        t = im.convert("RGB")
        t.thumbnail(THUMB_SIZE)
        t.save(self.abs_path(thumb_rel), "JPEG", quality=82)
        b = im.convert("RGB")
        b.thumbnail(BLUR_SIZE)
        b = b.filter(ImageFilter.GaussianBlur(radius=max(8, b.size[0] // 24)))
        b = ImageOps.autocontrast(b)
        b.save(self.abs_path(blur_rel), "JPEG", quality=40)
        return thumb_rel, blur_rel

    def _video_poster(self, abs_path: str, rel: str):
        ffmpeg = shutil.which(self.cfg.ffmpeg_path)
        if not ffmpeg:
            return None, None, None, None
        base, _ = os.path.splitext(rel)
        poster_rel = f"{base}.poster.jpg"
        try:
            subprocess.run([ffmpeg, "-y", "-loglevel", "error", "-ss", "00:00:01", "-i", abs_path, "-frames:v", "1",
                            "-vf", "scale='min(1280,iw)':-2", self.abs_path(poster_rel)], check=True, timeout=120,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            poster_rel = None
        duration = width = height = None
        ffprobe = shutil.which("ffprobe")
        if ffprobe:
            try:
                out = subprocess.run([ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries",
                                      "stream=width,height:format=duration", "-of", "json", abs_path],
                                     capture_output=True, text=True, timeout=60).stdout
                data = json.loads(out or "{}")
                st = (data.get("streams") or [{}])[0]
                width, height = st.get("width"), st.get("height")
                duration = float((data.get("format") or {}).get("duration") or 0) or None
            except Exception:
                pass
        return poster_rel, duration, width, height

    # ------------------------------------------------------------ delivery
    def watermarked(self, media_row, viewer_id: int | None, ip: str | None, text: str, opacity: int) -> bytes:
        """Visible diagonal watermark + hidden per-viewer fingerprint in PNG/JPEG metadata."""
        fingerprint = hashlib.sha256(f"{media_row['id']}:{viewer_id}:{now_ts() // 3600}".encode()).hexdigest()[:16]
        with Image.open(self.abs_path(media_row["path"])) as im:
            im = im.convert("RGBA")
            w, h = im.size
            layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
            draw = ImageDraw.Draw(layer)
            font_size = max(14, w // 28)
            font = _font(font_size)
            label = f"{text}  ·  {viewer_id or 'guest'}  ·  {fingerprint}"
            alpha = int(255 * max(0, min(100, opacity)) / 100)
            tw = draw.textlength(label, font=font)
            step_y = max(font_size * 6, h // 5)
            y = -h
            while y < h * 2:
                x = -w
                while x < w * 2:
                    draw.text((x, y), label, font=font, fill=(255, 255, 255, alpha))
                    x += tw + font_size * 4
                y += step_y
            layer = layer.rotate(27, expand=False, resample=Image.BICUBIC)
            out = Image.alpha_composite(im, layer).convert("RGB")
            buf = io.BytesIO()
            meta = PngImagePlugin.PngInfo()
            meta.add_text("vx-fp", fingerprint)
            if (media_row["mime"] or "").endswith("png"):
                out.save(buf, "PNG", pnginfo=meta)
            else:
                out.save(buf, "JPEG", quality=88, comment=f"vx-fp:{fingerprint}".encode())
        self.db.insert("watermark_log", media_id=media_row["id"], user_id=viewer_id, fingerprint=fingerprint, ts=now_ts(), ip=ip)
        return buf.getvalue()

    def download_token(self, media_id: int, user_id: int | None, purpose: str, ttl_seconds: int = 3600, max_uses: int = 3) -> str:
        token = token_urlsafe(24)
        self.db.insert("download_tokens", token=token, media_id=media_id, user_id=user_id, purpose=purpose,
                       expires_at=now_ts() + ttl_seconds, max_uses=max_uses, created_at=now_ts())
        return token

    def consume_download_token(self, token: str):
        row = self.db.one("SELECT * FROM download_tokens WHERE token=? AND expires_at>? AND uses<max_uses", (token, now_ts()))
        if row is None:
            return None
        self.db.execute("UPDATE download_tokens SET uses=uses+1 WHERE token=?", (token,))
        return self.db.get("media", row["media_id"])

    # ------------------------------------------------------------ vault ops
    def export_zip(self, media_ids: list[int]) -> bytes:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for mid in media_ids:
                row = self.db.get("media", mid)
                if row and os.path.exists(self.abs_path(row["path"])):
                    zf.write(self.abs_path(row["path"]), arcname=f"{mid}_{row['filename']}")
        return buf.getvalue()

    def delete_files(self, media_row) -> None:
        for key in ("path", "thumb_path", "blur_path", "poster_path"):
            rel = media_row[key]
            if rel:
                try:
                    os.remove(self.abs_path(rel))
                except OSError:
                    pass

    def search(self, q: str, kind: str | None = None, folder: str | None = None, limit: int = 50, offset: int = 0):
        where, params = ["m.deleted_at IS NULL"], []
        if q:
            where.append("m.id IN (SELECT rowid FROM media_fts WHERE media_fts MATCH ?)")
            params.append(_fts_query(q))
        if kind:
            where.append("m.kind=?"); params.append(kind)
        if folder:
            where.append("m.folder=?"); params.append(folder)
        params += [limit, offset]
        return self.db.all(f"SELECT m.* FROM media m WHERE {' AND '.join(where)} ORDER BY m.id DESC LIMIT ? OFFSET ?", params)


def _fts_query(q: str) -> str:
    terms = [t for t in "".join(ch if ch.isalnum() else " " for ch in q).split() if t]
    return " OR ".join(f'"{t}"*' for t in terms) if terms else '""'


_FONT_CACHE: dict[int, ImageFont.ImageFont] = {}


def _font(size: int):
    if size in _FONT_CACHE:
        return _FONT_CACHE[size]
    for cand in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                 "/usr/share/fonts/TTF/DejaVuSans.ttf"):
        if os.path.exists(cand):
            try:
                f = ImageFont.truetype(cand, size)
                _FONT_CACHE[size] = f
                return f
            except Exception:
                continue
    f = ImageFont.load_default()
    _FONT_CACHE[size] = f
    return f
