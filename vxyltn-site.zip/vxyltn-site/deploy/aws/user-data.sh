#!/bin/bash
# ec2 user-data for request.vxyltn.com (amazon linux 2023 or ubuntu 24.04, x86_64/arm64).
# installs docker + compose, fetches the app bundle, writes .env from ssm parameter store (or a
# placeholder), starts app + caddy, and schedules an s3 copy of the nightly sqlite backup.
#
# before launching:  put secrets in ssm parameter store under /vxyltn/ (SecureString) — see README.
# after launching:   point request.vxyltn.com (route 53 a/aaaa) at the elastic ip; caddy issues the certificate.
set -euxo pipefail

APP_DIR=/opt/vxyltn
BUNDLE_URL="${BUNDLE_URL:-}"          # optional: s3://bucket/vxyltn-site.zip or https url; otherwise git clone REPO_URL
REPO_URL="${REPO_URL:-}"
SSM_PREFIX="${SSM_PREFIX:-/vxyltn}"
REGION="$(curl -s http://169.254.169.254/latest/meta-data/placement/region || echo eu-central-1)"

# ---- packages -----------------------------------------------------------------
if command -v dnf >/dev/null 2>&1; then
  dnf -y update
  dnf -y install docker git unzip awscli
  systemctl enable --now docker
  # compose v2 plugin
  mkdir -p /usr/local/lib/docker/cli-plugins
  ARCH=$(uname -m); [ "$ARCH" = "aarch64" ] && ARCH=aarch64 || ARCH=x86_64
  curl -fsSL "https://github.com/docker/compose/releases/latest/download/docker-compose-linux-${ARCH}" -o /usr/local/lib/docker/cli-plugins/docker-compose
  chmod +x /usr/local/lib/docker/cli-plugins/docker-compose
else
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y ca-certificates curl git unzip awscli docker.io docker-compose-v2
  systemctl enable --now docker
fi

# ---- fetch application --------------------------------------------------------
mkdir -p "$APP_DIR"
if [ -n "$BUNDLE_URL" ]; then
  case "$BUNDLE_URL" in
    s3://*) aws s3 cp "$BUNDLE_URL" /tmp/vxyltn.zip --region "$REGION" ;;
    *)      curl -fsSL "$BUNDLE_URL" -o /tmp/vxyltn.zip ;;
  esac
  unzip -oq /tmp/vxyltn.zip -d /tmp/vxyltn-src
  SRC=$(find /tmp/vxyltn-src -maxdepth 2 -name docker-compose.yml -printf '%h\n' | head -1)
  cp -r "$SRC"/. "$APP_DIR"/
elif [ -n "$REPO_URL" ]; then
  git clone --depth 1 "$REPO_URL" "$APP_DIR"
fi
cd "$APP_DIR"

# ---- .env from ssm parameter store ------------------------------------------------
# every parameter under $SSM_PREFIX/ becomes KEY=value (name after the prefix, uppercased).
if [ ! -f .env ]; then
  cp .env.example .env
  PARAMS=$(aws ssm get-parameters-by-path --path "$SSM_PREFIX/" --with-decryption --recursive --region "$REGION" \
           --query 'Parameters[].[Name,Value]' --output text 2>/dev/null || true)
  if [ -n "$PARAMS" ]; then
    while IFS=$'\t' read -r name value; do
      key=$(basename "$name" | tr '[:lower:]' '[:upper:]')
      esc=$(printf '%s' "$value" | sed -e 's/[&|\\]/\\&/g')
      if grep -q "^${key}=" .env; then
        sed -i "s|^${key}=.*|${key}=${esc}|" .env
      else
        echo "${key}=${value}" >> .env
      fi
    done <<< "$PARAMS"
  fi
  # a secret key must exist even without ssm
  if grep -q '^SECRET_KEY=change-me' .env; then
    sed -i "s|^SECRET_KEY=.*|SECRET_KEY=$(openssl rand -hex 32)|" .env
  fi
  chmod 600 .env
fi

# ---- run ----------------------------------------------------------------------------
docker compose pull caddy || true
docker compose build --pull
docker compose up -d

# ---- nightly s3 copy of local backups (app also uploads directly when BACKUP_S3_BUCKET is set) ----
BUCKET=$(grep '^BACKUP_S3_BUCKET=' .env | cut -d= -f2 | cut -d' ' -f1 || true)
if [ -n "$BUCKET" ]; then
  cat > /etc/cron.daily/vxyltn-backup-sync <<EOF
#!/bin/bash
VOL=\$(docker volume inspect vxyltn_vxdata -f '{{.Mountpoint}}' 2>/dev/null || true)
[ -n "\$VOL" ] && aws s3 sync "\$VOL/backups" "s3://$BUCKET/backups" --region $REGION --storage-class STANDARD_IA
[ -n "\$VOL" ] && aws s3 sync "\$VOL/uploads" "s3://$BUCKET/uploads" --region $REGION --storage-class STANDARD_IA
EOF
  chmod +x /etc/cron.daily/vxyltn-backup-sync
fi

# ---- unattended security updates + log rotation are distro defaults; reboot-safe via restart policies ----
echo "vxyltn: deployed. point request.vxyltn.com at this instance's elastic ip." | tee /var/log/vxyltn-deploy.done
